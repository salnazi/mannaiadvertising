<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<?php include("title.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script> 
<!-- <script type="text/javascript" src="scripts/jquery-dis.js"></script>  -->
</head>



<body id="top">
<div class="wrapper col0">
  <div id="topline">
<?php include("top_menu.php"); ?>
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="header">
    <div class="fl_left">
   <?php include("company_name.php"); ?>
    </div>
    <div class="fl_right">
	<?php include("top_banner.php"); ?>
	
	</div>
	
    <br class="clear" />
	
  </div>
</div>
<!-- ####################################################################################################### -->
<!-- <div class="wrapper col2">
  <div id="topbar">
  <div id="topnav">
    <?php include("center_menu.php"); ?>
    </div> 
    <div id="search">
     <?php include("search.php"); ?>
    </div> -->
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="featured_slide">
       <?php include("top_slide.php"); ?>
      </div>
    </div>
    <div class="column">
     <?php include("right_col.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper" >
  <div id="adblock">
    <?php include("topad468_60ad.php"); ?>
  </div>
  <div id="hpage_cats" >
<br><br>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&appId=1437054166542996&version=v2.0";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-comments" data-href="http://ads.mannaiadvertising.com/Feedback.php" data-numposts="30" data-colorscheme="light"></div>
    </div>
    <br class="clear" />

  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="hpage_latest">
       <?php include("content_3col.php"); ?>
        <br class="clear" />
      </div>
    </div>
    <div class="column">
      <?php include("rightad300_250.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
   <?php include("footer_menu.php"); ?>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="socialise">
    <?php include("footer_2.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col8">
  <div id="copyright">
    <?php include("copyrights.php"); ?>
    <br class="clear" />
  </div>
</div>
</body>
</html>

<?php
//newsletter subscription
error_reporting(0);
$to = "Mannaiadvertising.com <mannaiadvertising@gmail.com>";
$from= $_POST['emailid'];
$subject="Newsletter - Mannaiadvertising";
$name=$_POST['fullname'];
$body1= "Newsletter";


$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

$body="<table border=0 cellpadding=0 cellspaing=0 width='100%' style='background:white;border: solid black 1px;'><tr><td style='font-weight:bold;'>Hi,</td></tr><tr><td style='padding-left:0px;'>Sender Name :  $name.</td><tr><tr><td>Sender Email: $from, </td><tr><tr><td><br><b>Message:</b><br><br></td></tr><tr><td style='padding-left:10px;'>$body1</td><tr><tr><td><br><br></td></tr><tr><td style='font-weight:bold;'> Thanks,     </td><tr><tr><td style='font-weight:bold; font-size;13px; color:#084B8A; text-transform:capitalize;'> $name </td><tr></table>";

if($_POST['submit'])
{
if(ereg("^[^@]{1,64}@[^@]{1,200}\.[a-zA-Z]{2,3}$",$_POST['emailid'])){
mail($to, $subject, $body,  $headers);
include("config/host.php");
include("webadmin/rand_id.php");
mysqli_query($_Conn, "insert into sal_newsletters (sname, email, rand_id) values ('$name', '$from', '$rand_id')");
echo "<script type='text/javascript'> alert ('Thank you for your subscription!');  </script>";
}
else
{
echo "<script type='text/javascript'> alert ('Subscription sending Failed!'); </script>";
}
}
?>

<?php include("pure_chat.php"); ?>