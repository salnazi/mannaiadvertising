<span style='color:#B4045F;font-size:20px;'><b>Train services between Mannargudi and Chennai </b></span>

<br><br>
The broad gauge line between Nidamagalam and Mannargudi will be opened for passenger traffic on September 27.
<br><br>
Southern Railway will operate daily train services between Chennai Egmore and Mannargudi with effect from September 27 in both directions.
<br><br>
Train No. 16179 Chennai Egmore-Mannargudi Mannai express will leave Chennai Egmore at 10 p.m. and arrive Mannargudi at 6.25 a.m., the next day.
<br><br>
Train No. 16180 Mannargudi-Chennai Egmore Mannai express will leave Mannargudi at 9.15 p.m. and arrive in Chennai Egmore at 5.50 a.m., the next day.
<br><br>
The composition of the trains will be one first AC-cum -AC two tier, two AC two tiers, one AC three tier, seven sleeper class, six general second class and two luggage cum brake van coaches. The train will stop at Tambaram, Chengalpattu, Thiruppadiripuliyur, Chidambaram,
<br><br>
Sirkali, Mayiladuthurai, Kumbakonam, Thanjavur and Nidamangalam.
<br><br>
Train number 16180
<br><br>
Train number 16180 will stop at Mambalam also, a Southern Railway press release said.
<br><br>
The reservation for the new train commenced today and T.R.Baalu, was the first person to purchase a ticket at Mannargudi railway station ticket counter to travel from Mannargudi to Chennai Egmore on Tuesday.
<br><br>
The train, first one after a new broad gauge line has been laid between Mannargudi and Nidamangalam, will leave Mannargudi at 9.15 p.m. on Tuesday.
<br><br>
Baalu was instrumental in the laying of the railway line and introduction of train service from Mannargudi to Chennai Egmore.
<br><br>
Selling of tickets started by noon and ended at 7 p.m. According to Railway sources, one ticket was sold out of eight in the first AC, five out of 43 in the second AC, one out of 35 in the third AC and 32 out of 262 in the sleeper coaches in the train for the first day.
<br><br>
T.R.B.Raja, MLA, son of Mr. Baalu said that he has requested the Southern Railway to introduce online booking of tickets soon.
<br><br>
People welcome the train service
<br><br>
S.Ranganathan, secretary, Cauvery Delta Farmers Welfare Association, welcomed the introduction of train service to Mannargudi.
<br><br>
In a press release he said that consistent effort taken by T.R.Baalu, former Union Minister and Chairman of Standing Committee for Railways for the last one year had paid dividends and resulted in Mannargudi being connected by rail with other states.
<br><br>
Though there was service to Mannargudi in the past, it was snapped in 1964. Nearly after 47 years the train service has been revived. Besides passenger trains, goods trains should also be operated from Bamini near Mannargudi where a Central Ware Housing Corporation is storing paddy and a fertiliser plant is producing fertilisers.
<br><br>
The rail service should be utilised for movement of paddy and fertilisers.


