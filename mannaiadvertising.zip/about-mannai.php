<span style='color:#B4045F;font-size:20px;'><b>Mannargudi Township</b></span>
<br><br>
Mannargudi is a town in the Tiruvarur district of Tamil Nadu, India. Situated at a distance of 20 kilometres from the district capital Tiruvarur and 310 kilometres from the city of Chennai, Mannargudi is the largest town in the district. Apart from being a rice-production centre, Mannargudi is known for the Rajagopalaswamy Temple, which is an important Hindu pilgrimage site.
<br><br>
Mannargudi was founded as an agraharam village by the Medieval Cholas. Mannargudi was a part of Tanjore district till 1991, when it was transferred to the newly formed Tiruvarur district. The town is located on a elevated highland and is drained by the rivers . The town is known for metal working and weaving. The region around Mannargudi also has considerable mineral deposits (lacking valid ref.).
<br><br>
Mannargudi is administered by the Mannargudi municipality which was established in 1866. Mannargudi is a part of the Mannargudi Tamil Nadu assembly constituency which is a part of the Thanjavur( Lok Sabha constituency. The town is well-connected by road and rail with other towns and cities in Tamil Nadu. The nearest seaport is at Nagapattinam while the nearest airport is at Tiruchirappalli.

<br><br>

<span style='color:#045FB4;font-size:17px;'><b>History</b></span>
<br><br>
Mannargudi was founded as an agraharam 'Village', Rajadhiraja chaturvedimangalam, by the Medieval Cholas. The Medieval Cholas, Pandyas and the Hoysalas constructed a lot of temples in Mannargudi.The Rajagopalaswami Temple was constructed by Kulothunga Chola I in the 11th century AD.There are also the remains of a fort constructed by the Hoysalas.
<br><br>
Mannargudi was conquered by the Delhi Sultanate in 1311. Following brief periods of occupation by the Madurai Sultanate and the Hoysalas, Mannargudi became a part of the Vijayanagar Empire. On the decline of the Vijayanagar Empire, Mannargudi was ruled by the Thanjavur Nayaks and the Thanjavur Marathas till its annexation by the British East India Company in 1799. Mannargudi was a part of Tanjore district from 1799 till 1991, when it was included in the newly created Tiruvarur District.
<br><br>
Present-day Mannargudi dates from the time of the Thanjavur Nayak king, Vijaya Raghava Nayak (1633-1673), also called "Mannaru dasan" who carried out extensive renovations of the Rajagopalaswami temple complex and is credited by some with having reclaimed the land from the surrounding forest.