<p style='text-align:justify;'><span style='color:#B4045F;font-size:20px;'><b>Mannargudi Temple</b></span>
<br><br>
Mannargudi Temple, Visit Mannargudi Temple of Tamilnadu, Temple tour of Mannargudi Temple, Religious place of Tamilnadu.
<br><br>
<span style='color:#045FB4;font-size:17px;'><b>Location : </span>Mannargudi Near Thanjavur, Tamil Nadu</b>
<br><br>
<span style='color:#045FB4;font-size:17px;'><b>Dedicated To :</span> Sri Rajagopalaswami</b>
<br><br>
<span style='color:#045FB4;font-size:17px;'><b>Built By :</span> Chola King Kulottunga</b>
<br><br>
<span style='color:#045FB4;font-size:17px;'><b>About The Temple</b></span>
<br><br>
The famous Vishnu temple at Mannargudi dedicated to Sri Rajagopalaswami was built by the Chola king Kulottunga (1070-1120 AD). The temple is situated over an area of 6 acres of land that commands an imposing view and provides accommodation for thousands of devotees. After the Chola kings the Nayak kings of Tanjore took interest in the renovation of temples built earlier and as a result the temple at Mannargudi was improved with many Gopurams and outer Prakarams.
<br><br>
<span style='color:#045FB4;font-size:17px;'><b>Festivals Celebrated</b></span>
<br><br>
Bhramotsavam in Pankuni (March -April), Float Festival in Aani (June-July) And Aadi Pooram During July-August Mannargudi is a place of religious antiquity and legendary importance. In ancient times, Mannargudi was known by many names namely, Senbagaranyam, Vasudevapuri, Dakshina Dwaraka, Vanduvarapati and Swayambhu Sthalam, each name having a religious significance.
<br><br>
<span style='color:#045FB4;font-size:17px;'><b>Temple Architecture</b></span>
<br><br>
This is a massive temple with as many as seven Prakarams or circumambulatory paths surrounding the central sanctum. A 154 feet high RajaGopuram adorns the entrance to the outermost Prakaram. There are several beautiful pillared halls in the temple - such as the Thousand-pillared hall, the Vallala Maharaja Mandapam, the Yaanai Vaahana Mandapam, Garudavaahana Mandapam, Vennaithaazhi Mandapam and Punnai Vaahana Mandapam. The Shrine to Garuda on top of a 50 feet high monolithic pillar in front of the temple deserves mention. The saying 'Mannaargudi Madhil Azhagu' (the walls of the temple of Mannargudi are of great beauty) in Tamil, testifies to the grandeur of this temple.
<br><br>
Several teerthas (temple tanks) adorn this shrine. The Haridra Nadhi tank is located located near the temple, and popular belief has it, that a river was transformed into a big tank, and that Rajagopala performed the famed Rasa Leela in the tank.
<br><br>
<span style='color:#045FB4;font-size:17px;'><b>The Deities</b></span>
<br><br>
Mannargudi Temple, Visit Mannargudi Temple of Tamilnadu, Temple tour of Mannargudi Temple, Religious place of TamilnaduThe sanctum of this vast temple enshrines a 7 feet high image of Vaasudeva with his consorts Sri Devi and Bhoodevi on either side. Sri Rajagopalaswami is the processional deity with a commanding appearance standing in front of the cow, with Rukmini and Satyabhama. This idol is considered to be the most handsome and attractive among the images of Vishnu.
<br><br>
There is another idol of Lord Krishna as a boy lying on the serpent Adisesha, with his right toe in the mouth, known as "Santana Rajagopalan". This image is made of bronze and the workmanship is super-excellent. The worship of Santana Rajagopalan has got a special significance. Popular belief has it that cradling the image of Santanagopalakrishna in ones lap, would bless barren couple with progeny.
<br><br>
There is a shrine of Goddess Senbagavalli Tayar and on her sides are the shrines of Rajanayaki on the right and Dwaranayaki on the left. She has four arms. This shrine has separate Prakarams.
<br><br>
There are small shrines in the temple dedicated to Rama, Sita, Lakshmana, Garudalwar, etc. The Garuda Stambha placed in front of the Lord's shrine is 54 feet high and is made of a -single stone.
<br><br>
<span style='color:#045FB4;font-size:17px;'><b>The Vahanams In The Temple</b></span>
<br><br>
There are many Vahanams in the temple of which Panchamukha Hanuman (Hanuman with five faces) is worth mentioning. Garuda Vahanam and Horse Vahanam are plated with gold and are said to have been donated by a European officer who was cured of his colic on offering worship to the Lord.
<br><br>
<span style='color:#045FB4;font-size:17px;'><b>Worship Services And Festivals</b></span>
<br><br>
Seven worship services are offered during the course of a day, and this temple attracts pilgrims throughout the year. The annual festival (Bhramotsavam) is celebrated in the month of Pankuni (March 15-April 15) for a period of 18 days, when the deities are taken out in procession on decorated mounts. The float festival occurs in the month of Aani (June 15 - July 15). Aadi Pooram celebrated between July 15 and August 15 is another of the important festivals here.
<br><br>
<span style='color:#045FB4;font-size:17px;'><b>How to reach there</b></span>
<br><br>
<span style='color:#045FB4;font-size:17px;'><b>By Train : </b></span>The nearest railway station of Nidamangalam is at a distance of 12-km and Thanjavur is at a distance of 34-km.
<br><br>
<span style='color:#045FB4;font-size:17px;'><b>By Bus : </b></span>Mannargudi is well connected by road to Thanjavur, Kumbhakonam, Tiruvarur and other towns in the erstwhile Thanjavur district.
<br><br>
<span style='color:#045FB4;font-size:17px;'><b>Where to stay</b></span>
<br><br>
Accommodation is available at the dharmashalas in Mannargudi or at the economy class hotels, lodges and devasthanam cottages in Thanjavur.
</p>