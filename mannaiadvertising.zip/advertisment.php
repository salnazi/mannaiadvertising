<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<?php include("title.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" /> 
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>

<script type="text/javascript" language="javascript" src="js/behavior.js"></script>
<script type="text/javascript" language="javascript" src="js/rating.js"></script>
<script type="text/javascript" src="scripts/jquery-dis.js"></script> 
<link rel="stylesheet" type="text/css" href="css/rating.css" />
</head>
<body id="top">
<div class="wrapper col0">
  <div id="topline">
<?php include("top_menu.php"); ?>
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="header">
    <div class="fl_left">
   <?php include("company_name.php"); ?>
    </div>
    <div class="fl_right">
	<?php include("top_banner.php"); ?>
	</div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<!--<div class="wrapper col2">
  <div id="topbar">
    <div id="topnav">
    <?php include("center_menu.php"); ?>
    </div>
    <div id="search">
     <?php include("search.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div> -->
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="featured_slide">
       <?php include("top_slide.php"); ?>
      </div>
    </div>
    <div class="column">
     <?php include("right_col.php"); ?>
	
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="adblock">
    <?php include("topad468_60ad.php"); ?>
  </div>
  <div id="hpage_cats">
  
    </div>
    <br class="clear" />

  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="hpage_latest">
	<?php
	if($_GET['id'] == "Free Ads")
      include("free-ads.php");
	  if($_GET['id'] == "Premium Ads")
	   include("premium-ads.php"); 
	    if($_GET['id'] == "Flash Ads")
	   include("flash-ads.php"); 
	   ?>

    
        <br class="clear" />
      </div>
    </div>
    <div class="column">
	<?php
	//if($_GET['id'] == "Free Ads")
  //    include("free-ads.php");
	//  if($_GET['id'] == "Premium Ads")
	//   include("premium-ads.php"); 
	//    if($_GET['id'] == "Flash Ads")
	//   include("flash-ads.php"); 
	   ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
   <?php include("footer_menu.php"); ?>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="socialise">
    <?php include("footer_2.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col8">
  <div id="copyright">
    <?php include("copyrights.php"); ?>
    <br class="clear" />
  </div>
</div>
</body>
</html>