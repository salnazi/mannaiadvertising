 <div class="fl_left">
    <h2><a href="#">Schools &raquo;</a></h2>
      <img src="images/school.png" alt="schools" height=100 width=100 style='border:none;'/>
      <p><strong><a href="#">School Lists</a></strong></p>
      <p>National Higher Secondary School.<br><br>
Findlay Higher Secondary School.<br><br>
St. Joseph higher secondary school (for Girls).</p>
	  <br><p align=right><a href='category_listing.php?id=Schools'>More List>>></a></p>
    </div>
    <div class="fl_right">
      <h2><a href="#">Colleges &raquo;</a></h2>
      <img src="images/college.png" alt="colleges"  height=100 width=100 style='border:none;'/>
      <p><strong><a href="#">College Lists</a></strong></p>
      <p>ARJ College of Engineering and Technology<br><br>
	  MRG Government Arts College.<br><br>
SK College of Arts and Science, Melavasal. 
	  </p>
	  	 
		  <br><p align=right><a href='category_listing.php?id=Colleges'>More List>>></a></p>
    </div>
    <br class="clear" />
    <div class="fl_left">
      <h2><a href="#">Hospitals &raquo;</a></h2>
      <img src="images/hospital.png" alt="hospital"  height=100 width=100 style='border:none;'/>
      <p><strong><a href="#">Hospital Lists</a></strong></p>
      <p>
	  C.A.K Polyclinic<br><br>
	  Government Hospital<br><br>
	  Rangeshwara Clinic
	  </p>
	  	 <br><p align=right><a href='category_listing.php?id=Hospitals'>More List>>></a></p>  
    </div>
    <div class="fl_right">
	
      <h2><a href="#">Shops & Merchant &raquo;</a></h2>
      <img src="images/shop.png" alt="shops" height=100 width=100 style='border:none;'/>
      <p><strong><a href="#">Shops & Merchant List</a></strong></p>
      <p>Krishna Sweets<br><br>
	  Laxmi Department Store<br><br>
	  Veera Silks & Readymades<br><br>
	  </p>
	  	 <br><p align=right><a href='category_listing.php?id=Shops'>More List>>></a></p>