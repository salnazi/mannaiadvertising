 <?php

 include("config/host.php");
 //$sql = mysqli_query($_Conn, "select * from $sal_main_cat where id");
  $sql = mysqli_query($_Conn, "SELECT * FROM $sal_main_cat where id order by category limit 0,12");
 while($row = mysqli_fetch_object($sql))
{
 echo " <div class='fl_left' style='padding:4px;height:160px;overflow:hidden;'>";
  echo "<h2 style='height:20px;'><p align='left' style='padding:0px;margin-left:10px;'><a href='category_listing.php?id=$row->category'>$row->category &raquo;</a></h2></p><p align=right style='margin-top:-40px;'><a href='category_listing.php?id=$row->category'  style='color:brown;background:none;'>Read More>>></a></p><br>";
	
	if($row->category == "Business")
	{
	echo "<img src='images/business.gif' alt='Business' height=100 width=100 style='border:none;'/>";
	
	}
	if($row->category == "Automobiles")
	{
	echo "<img src='images/auto.gif' alt='Automobiles' height=100 width=100 style='border:none;'/>";
	
	}
	if($row->category == "Hotels, Lodges and Restaurants")
	{
	echo "<img src='images/hotel.gif' alt='Hotel' height=100 width=100 style='border:none;'/>";
	
	}
	if($row->category == "Education")
	{
	echo "<img src='images/education.gif' alt='Education' height=100 width=100 style='border:none;'/>";
	}
	if($row->category == "Entertainments")
	{
	echo "<img src='images/entertainments.gif' alt='Entertainments' height=100 width=100 style='border:none;'/>";
	}
	if($row->category == "Building Construction")
	{
	echo "<img src='images/realestate.gif' alt='Real Estate' height=100 width=100 style='border:none;'/>";
	}
	if($row->category == "Banks")
	{
	echo "<img src='images/bank.gif' alt='Banks' height=100 width=100 style='border:none;'/>";
	}
	if($row->category == "Employment")
	{
	echo "<img src='images/employment.png' alt='Employments' height=100 width=100 style='border:none;'/>";
	}
	if($row->category == "General Services")
	{
	echo "<img src='images/general.gif' alt='General Services' height=100 width=100 style='border:none;'/>";
	}
	if($row->category == "Travels")
	{
	echo "<img src='images/travels.png' alt='Travels' height=100 width=100 style='border:none;'/>";
	//echo "</p><p align=right style='margin-top:0px;'><a href='category_listing.php?id=$row->category' >Read More>>></a></p>";
	}
	if($row->category == "Agriculture")
	{
	echo "<img src='images/agri.gif' alt='Agriculture' height=100 width=100 style='border:none;'/>";
	}
	if($row->category == "Hospitals and Medicals")
	{
	echo "<img src='images/hospital.gif' alt='Hospitals & Medicals' height=100 width=100 style='border:none;'/>";
	
	}


//echo $row1->sub_category;

 $sql1 = mysqli_query($_Conn, "SELECT * FROM $sal_sub_cat where id order by rand()");

 while($row1 = mysqli_fetch_object($sql1))
{	

if($row->category == $row1->category) {
echo " <p><strong><a href='category_list_view.php?id=$row1->sub_category' style='color:gray;' title='$row1->sub_category'>$row1->sub_category</a></strong></p>";
//echo $row1->sub_category; 
}
}


echo "</p></p>";
	echo " </div>";
}


?>