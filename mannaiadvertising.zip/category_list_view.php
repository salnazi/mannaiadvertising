<?php session_start(); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<?php include("title.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>
<script type="text/javascript" src="scripts/jquery-dis.js"></script> 
</head>
<body id="top" >
<div class="wrapper col0" style='position:fixed;z-index:1;'>
  <div id="topline" >
<?php include("top_menu.php"); ?>
  </div>
</div><br><Br><br>
<!-- ####################################################################################################### -->

<!-- ####################################################################################################### -->
<!-- <div class="wrapper col2">
  <div id="topbar">
  <div id="topnav">
    <?php include("center_menu.php"); ?>
    </div> 
    <div id="search">
     <?php include("search.php"); ?>
    </div> -->
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<!--<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="featured_slide">
     
      </div>
    </div>
    <div class="column">
     <?php //include("right_col.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>-->
  <?php include("top_slide.php"); ?>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="adblock">
    <?php include("topad468_60ad.php"); ?>
  </div>
  <div id="hpage_cats">
  
    </div>
    <br class="clear" />

  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="hpage_latest">
	      <form action='place_your_address.php'>
<input type='submit' value='Click to Post your address'  id='submit' style='position:absolute;margin-left:429px;margin-top:20px;'> 
</form>
	  <?php
	
	 $id1 = $_SESSION['id1'];
	  
	  $c_id = $_GET['id'];
	   $_SESSION['id2'] = $_GET['id'];
	 
	  include("config/host.php"); 
  
	  $sql = mysqli_query($_Conn, "select * from $sal_add_com where id order by title asc");
	 
	   echo " <span id='salnazititle'><a href='index.php' id='bread'>Home</a> >> <a href='category_listing.php?id=$id1' id='bread'>$id1</a> >> <a id='breadempty'>$c_id</a> </span><br><Br>";
	  while($row = mysqli_fetch_object($sql))
	  {
	  $cat_cat = $row->sub_category;
	  //if($cat_cat == $c_id && $row->email_activation == "0")
    if($cat_cat == $c_id)
	  echo "<a href='category_profile.php?id=$row->title'>$row->title</a>" . "<br><br>";
   
	  }
	  echo "<br><br><br><br><br><br><Br><br><br><Br>";
	  include("content_3col.php");
	  ?>



<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&appId=1437054166542996&version=v2.0";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-comments" data-href="http://ads.mannaiadvertising.com/category_list_view.php?id=<?php echo $c_id; ?>" data-numposts="10" data-colorscheme="light"></div>
        <br class="clear" />
      </div>
    </div>
    <div class="column">
      <?php include("rightad300_250.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
   <?php include("footer_menu.php"); ?>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="socialise">
    <?php include("footer_2.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col8">
  <div id="copyright">
    <?php include("copyrights.php"); ?>
    <br class="clear" />
  </div>
</div>
</body>
</html>


