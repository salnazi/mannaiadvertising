<?php session_start(); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<?php include("title.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" /> 
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>

<script type="text/javascript" language="javascript" src="js/behavior.js"></script>
<script type="text/javascript" language="javascript" src="js/rating.js"></script>

<script type="text/javascript" src="scripts/jquery-dis.js"></script> 

<link rel="stylesheet" type="text/css" href="css/rating.css" />
</head>
<body id="top" >
<div class="wrapper col0" style='position:fixed;z-index:1;'>
  <div id="topline" >
<?php include("top_menu.php"); ?>
  </div>
</div><br><Br><br>
<!-- ####################################################################################################### -->

<!-- ####################################################################################################### -->
<!-- <div class="wrapper col2">
  <div id="topbar">
  <div id="topnav">
    <?php include("center_menu.php"); ?>
    </div> 
    <div id="search">
     <?php include("search.php"); ?>
    </div> -->
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<!--<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="featured_slide">
     
      </div>
    </div>
    <div class="column">
     <?php //include("right_col.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>-->
  <?php include("top_slide.php"); ?>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="adblock">
    <?php include("topad468_60ad.php"); ?>
  </div>
  <div id="hpage_cats">
  
    </div>
    <br class="clear" />

  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="hpage_latest">
	      <form action='place_your_address.php'>
<input type='submit' value='Click to Post your address'  id='submit' style='position:absolute;margin-left:429px;margin-top:60px;'> 
</form>
	  <?php
	  $id1 = $_SESSION['id1'];
	  $id2 = $_SESSION['id2'];
	  $c_id = $_GET['id'];
	    $_SESSION['fid'] = $c_id;
	  include("config/host.php"); 
	  $sql = mysqli_query($_Conn, "select * from $sal_add_com where title = '$c_id'");
	 
	   //echo " <span id='salnazititle'><a href='index.php'>Home</a> >> $id1 >> $id2 >> $c_id </span><br><Br>";
	   echo " <span id='salnazititle'><a href='index.php' id='bread'>Home</a> >> <a href='category_listing.php?id=$id1' id='bread'>$id1</a> >> <a href='category_list_view.php?id=$id2' id='bread'>$id2</a> >> <a id='breadempty'>$c_id</a> </span><br><Br>";
	  while($row = mysqli_fetch_object($sql))
	  {
	  $cat_cat = $row->category;
	  $add = nl2br($row->address);
	  $otherinfo = nl2br($row->otherinfo);
$ad_id = substr($row->rand_id, 14, -1);
	  	  if($cat_cat == $c_id)
	  
	  echo "<a href='category_listing.php?id=$row->title'>$row->title</a>" . "<br><br>";
	  echo "<table border=0 cellpadding=10 cellspacing=10 id='category_table'>";
	  echo "<tr><td colspan=2 align='right' ><a href='category_profile.php?id=$c_id' onclick='window.print();' ><img src='images/print.png' height=20 width=20 style='margin-top:-40px;'>Print </a> </td><td style='text-align:center;'>  <a href='profile_forward.php?id=Forward'><img src='images/forward.png' height=20 width=20 style='margin-top:-40px;margin-left:20px;'>Share</a>   </td></tr>";
	  echo "<tr><td>Ad ID</td><td>$ad_id</td></tr>";
	  echo "<tr><td>Name</td><td>$row->title</td></tr>";
	  if($row->phone != "")
	  echo "<tr><td>Phone</td><td>$row->phone</td></tr>";
	  if($row->address != "")
	  echo "<tr><td>Address</td><td>$add</td></tr>";
	  if($row->otherinfo != "")
	  echo "<tr><td>Additional Info</td><td>$otherinfo</td></tr>";
	  if($row->email != "")
	  echo "<tr><td>Email</td><td>$row->email</td></tr>";
	  if($row->website != "")
	  echo "<tr><td>Website</td><td>$row->website</td></tr>";
	  echo "<tr><td><br><br><br><br><br><br><Br></td></tr>";
	  echo "<tr><td>Mannargudi STD Code:</td><td> 04367</td></tr>";
	  echo "<tr><td>Mannargudi Postal Code:</td><td> 614001</td></tr>";
	  echo "<tr><td colspan=2><b>Tags : &nbsp;</b> " . "<a href='category_listing.php?id=$row->category' id='breadtags'>" . $row->category .",&nbsp;" ."<a href='category_list_view.php?id=$id2' id='breadtags'>$id2" . ",</a>&nbsp;" ;
	  	$ma=explode(",",$row->tags);
  for($i=0; $i< sizeof($ma); ++$i)
{

$pi = $ma[$i];
$cle = ucwords(trim($pi, " "));
echo "<a href='company_search.php?id=$cle' id='breadtags'> $cle"."";
if($cle !="")
echo ",</a>";

}
	 
	
	echo "</td></tr>";
	  echo "<tr><td colspan=2><!-- AddThis Button BEGIN -->
<div class='addthis_toolbox addthis_default_style '>
<a class='addthis_button_facebook_like' fb:like:layout='button_count'></a>
<a class='addthis_button_tweet'></a>
<a class='addthis_button_google_plusone' g:plusone:size='medium'></a>
<a class='addthis_counter addthis_pill_style'></a>
</div>
<script type='text/javascript' src='http://s7.addthis.com/js/250/addthis_widget.js#pubid=ra-4f98efb84a28bb47'></script>
<!-- AddThis Button END --></td></tr>";
	//  require('_drawrating.php'); 
    //  echo "<tr><td colspan=2>" . rating_bar('2id',5) . "</td></tr>";
	  echo "</table>";
	 
	  }
	  
	  ?>
    

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&appId=1437054166542996&version=v2.0";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-comments" data-href="http://ads.mannaiadvertising.com/category_profile.php?id=<?php echo $c_id; ?>" data-numposts="10" data-colorscheme="light"></div>

        <br class="clear" />
      </div>
    </div>
    <div class="column">
      <?php include("rightad300_250.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
   <?php include("footer_menu.php"); ?>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="socialise">
    <?php include("footer_2.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col8">
  <div id="copyright">
    <?php include("copyrights.php"); ?>
    <br class="clear" />
  </div>
</div>
</body>
</html>