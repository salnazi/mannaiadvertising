<table border=0 cellpadding=0 cellspacing=10  style='border:none;width:100%;'>
<tr ><td colspan=4 style='border:none;font-size:25px;color:deeppink;text-align:center;font-weight:bold;font-family:Hobo Std;'>Happy Birthday to You<br><img src='images/ballonborder.jpeg' style='margin-left:220px;'><br></td></tr>

<tr>


<td style='border:none;color:deeppink;font-size:15px;font-weight:bold;'>
Baby Name&nbsp;&nbsp;: Abisheik</br>
DOB&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: 13-5-2012<br>
Age&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: 1 Yr<br>
Mother &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Siva</br>
Father &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Roshini</br>
Place&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Mannargudi<br>
</td><td style='border:none;'><img src='images/celebration/baby.jpeg' height=130 width=130 style='border:solid 1px silver;padding:3px;-moz-box-shadow:2px 2px 2px silver;'></td>

<td style='border:none;color:deeppink;font-size:15px;font-weight:bold;'>
Baby Name&nbsp;&nbsp;: Rubina</br>
DOB&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: 6-12-2011<br>
Age&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: 1 Yr<br>
Mother &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Arafath Nisha</br>
Father &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Bathusa</br>
Place&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Mannargudi<br>
</td><td style='border:none;'><img src='images/celebration/baby2.jpeg' height=130 width=130 style='border:solid 1px silver;padding:3px;-moz-box-shadow:2px 2px 2px silver;'></td>


</tr>
<tr><td style='border:none;'><br><br></td></tr>
<tr><td colspan=4><span style='color:purple;'>Please celebrate your baby birthday with mannaiadvertising for free <br>Send your baby profile with photo to : </span><b ><span style='color:deeppink;'>info@mannaiadvertising.com</b></span></td></tr>
</table>
