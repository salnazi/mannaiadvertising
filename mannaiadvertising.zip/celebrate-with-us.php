Every wondered which famous people share the same birthday with you? While some radio and TV talk shows provide this information, if you can't wake up early enough for the morning banter, you can browse this information at www.mannaiadvertising.com
It is customary all over the world to send birthday greetings. Of course children's birthdays are celebrated with more gaiety and fun than that of adults. But even for adults and old people, it is ideal that we send Greetings on such occasions. Everyone wishes to be greeted on his/her birthday, and people do it to cement the mutual relations with the warmth of love, affection and cordiality.

Start the Sentence with an expression of happiness:

1. Thank you for your invitation to attend your birthday party/ function.

2. It was very nice of you to invite me/ us to your birthday party.

3. What a pleasant surprise to know that the coming Monday is your birthday!

4. How delightful/ interesting it is to learn that you are celebrating your birthday next week!

5. I am desperately/ eagerly waiting to join you in your birthday party, next week.

6. Thanks a lot for inviting me to your birthday party next week. I like to share your joy of the occasion.

7. It will be a matter of great pleasure for me to attend your birthday party.

8. I express my joy and happiness on the eve of your birthday celebrations.

9. Accept my heartiest greetings on the eve of your birthday celebrations.

10. Thank you thanks for your birthday invitation. It has given me immense pleasure.

11. Thank you for inviting me to your birthday party. I am looking forward to attending it. 12.1 convey my heartiest congratulations and wish you many happy returns of the day.

13. Please accept my best wishes on this happy occasion.

14. I join all your friends and family members in wishing you a very happy birthday.

After congratulations, convey Good Wishes for future happiness:

15.1 take this opportunity to wish you all success for the long life ahead.

16. May all happiness and prosperity be with you in the days to come.

17. May you live long to enjoy the fruits of all your labour.

18. I wish this birthday to be followed by many more such happy occasions in your life

19. May every day in future be like your birthday/ be as rosy as this happy day.

Expressing inability to join the birthday function:

20. It's really very kind of you to have invited me to your birthday party, but I'm sorry I won't be able to make it as I will be out of town that day.

21. It was very nice of you to invite me/ us to your Birthday party.

22. It was very kind of you to invite me/us to your birth-day celebrations.

23. it�s a pleasure being invited to your birthday party, but, I am sorry I can't make it as I'm ill.

24. I, of course, wanted to join your birthday party, but, I am badly tied up with business affairs.

25. As my sister is leaving for the US on that day, I regret, I won't be able to attend it/ make it.

26. Had I not to go out on tour, I would certainly have been amongst your guests/ with you on this happy occasion.

27. I wish I could participate in/ attend the function and meet you all but due to unavoidable official commitments, I regret, I will not be able to make it.

Inform about sending some gift:

28. Very shortly, you will receive through my brother I am sending a small gift from my side as a token of my love and affection for you.

29.1 hope you would like the small gift I have sent to you today by post.

30. I've bought a nice gift for you which I will give you when I come down to Delhi next month.

Closing by summarizing the message:

31. Wishing you all success,

32. With all my felicitations,

33. Congratulations and Best Wishes,

34. Wishing you the best of luck.

35. Hope to hearing from you soon,

36. Thank you very much for remembering me

Sample Letters

My dear ������,

What a pleasant surprise to know that the coming Monday is your birthday! It will be a matter of great pleasure for me to attend your birthday party.

Please accept my best wishes on this happy occasion. I wish this birthday to be followed by many more such happy occasions in your life. It is really very kind of you to invite me to your birthday party, but, I am sorry I won't be able to join as I will be out of town on that day.

Very shortly you will receive a small gift from my side as a token of my love and affection.

Wishing you the best of luck,

With regards,

Yours sincerely,

My dear ������,

What a pleasant surprise to know that the coming Sunday happens to be your birthday!

It is very kind of you to have invited me to your birthday party, but, I regret that I will not be able to join it as I will be out of town on that day.

I wish this birthday to be followed by many more such happy occasions in your life. My best wishes to you on this occasion. You will, very shortly, receive a small gift from my side as a token of my love and affection.

Warm personal regards,

Sincerely,

Your Name 