<!--<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="500" height="80" style='margin-left:-10px;@margin-left:0px;'>
  <param name="movie" value="images/mannainewlogo.swf" />
  <param name="quality" value="high" />
  <param name="allowScriptAccess" value="always" />
  <param name="wmode" value="transparent">
     <embed src="images/mannainewlogo.swf"
      quality="high"
      type="application/x-shockwave-flash"
      WMODE="transparent"
      width="500"
      height="80"
      pluginspage="http://www.macromedia.com/go/getflashplayer"
      allowScriptAccess="always" />
</object> -->

