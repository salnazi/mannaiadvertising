<?php
error_reporting(0);
global $_Conn;
$_Conn = mysqli_connect("localhost","root","","mannaiadvertising") or die ("Could not connect");

$sal_main_cat = "sal_main_category";
$sal_sub_cat = "sal_sub_category";
$sal_add_com = "sal_add_company";
$sal_admin = "sal_admin";
$sal_cinema_updates = "sal_cinema_updates";
$sal_banner_updates = "sal_banner_updates";
?>
