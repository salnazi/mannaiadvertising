 <h2>Advertise With Us</h2>
        <ul>
          <li><img src="images/advertisewithus.gif" alt="" width=190 height=130/>
    
          </li>
          <li><img src="images/ad1.jpg" alt="" width=190 height=130 alt="" />
      
          </li>
          <li class="last"><img src="images/ad2.jpeg" alt="" width=190 height=130 alt="" />
         
          </li>
		  
		  <li><p><img src="images/bottomad1.jpg" alt="" width=620 height=100 alt="" /></li>
        </ul>