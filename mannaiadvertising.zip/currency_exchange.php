<!-- Currency Converter Script - FX-EXCHANGE.COM -->
<!--<br><span style='font-size:12px;font-weight:bold;color:brown;text-align:center;line-height:15px;'>EXCHANGE RATES</span><script type="text/javascript" src="http://widget.fx-exchange.com/converter.php?fg=en&ff=INR&ft=AED,SAR,SGD,MYR,USD,EUR,&fa=100&cb=F0A543&fy=3" style='color:E3E9FF;'></script>-->
<!-- End of Currency Converter Script -->
	 	<div id="fb-root"></div>
<script>(function(d, s, id) {
 var js, fjs = d.getElementsByTagName(s)[0];
 if (d.getElementById(id)) return;
 js = d.createElement(s); js.id = id;
 js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=1437054166542996";
 fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>




<div class="fb-like-box" data-href="https://www.facebook.com/pages/Mannai-Advertising/358580500869000?ref=hl" data-width="250" data-height="350" data-colorscheme="light" data-show-faces="true" data-header="true" data-stream="false" data-show-border="true"></div>
	



