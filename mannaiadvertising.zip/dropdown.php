 <form action="" method="post" name='form'>
<?php
$selected = $_POST['category'];
?>
<tr><td colspan=1>Select Category <span id='star'>*</span></td><td>
<select name='category' id='drop' >
<option value='' selected>-- ---- --</option>

<?php
include("config/host.php");
$sql = mysqli_query($_Conn, "select DISTINCT category from $sal_main_cat where id order by category");
while($r = mysqli_fetch_object($sql))
{
if($r->category != "") {
?>

<option value='<?php echo $r->category; ?>' onClick='document.form.submit()' 
<?php 
if ($selected && $r->category == $selected) 
{ 
$category = $r->category;
echo "selected"; 
} }?>
>

<?php echo $r->category; ?></option>
<?php
}
?></select>
</td></tr>

<?php
$aselected = $_POST['sub_category'];
?>
<tr><td colspan=1>Select Sub Category <span id='star'>*</span></td><td>
<select name='sub_category' id='drop'>
<option value='' selected>-- ---- --</option>
<?php
$sql = mysqli_query($_Conn, "select DISTINCT sub_category from $sal_sub_cat where category='$selected'");
while($r = mysqli_fetch_object($sql))
{
$sub_category = $r->sub_category;
?>

<option value='<?php echo $r->sub_category; ?>' onClick='document.form.submit()' 
<?php 
if ($aselected && $r->sub_category == $aselected) 
{ 
$sub_category = $r->sub_category;
echo "selected"; }
 ?> 
 ><?php echo $r->sub_category; ?></option>
<?php
}
?>
</select>
</td></tr>
</form>