<?php
$title = $_GET['id'];
$verification = $_GET['verification'];
include("config/host.php"); 
$sql = mysqli_query($_Conn, "UPDATE $sal_add_com SET email_activation = '0' where rand_id = $verification");
if($sql)
echo "<script type='text/javascript'> alert ('Email Verified Successfully'); window.location.href='category_profile.php?id=$title'; </script>";
if(!$sql)
echo "<script type='text/javascript'> alert ('Email Activation Failed. Contact : info@mannaiadvertising.com'); window.location.href='index.php'; </script>";
?>
