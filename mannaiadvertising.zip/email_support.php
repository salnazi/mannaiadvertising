<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<?php include("title.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />

<!-- <script type="text/javascript" src="scripts/jquery-dis.js"></script>  -->
</head>



<body id="top" >
<div class="wrapper col0" style='position:fixed;z-index:1;'>
  <div id="topline" >
<?php include("top_menu.php"); ?>
  </div>
</div><br><Br><br>
<!-- ####################################################################################################### -->


<!-- ####################################################################################################### -->
<!-- <div class="wrapper col2">
  <div id="topbar">
  <div id="topnav">
    <?php include("center_menu.php"); ?>
    </div> 
    <div id="search">
     <?php include("search.php"); ?>
    </div> -->
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper" style='height:700px;'>
  <div class="container" style='height:700px;'>
    <div class="content" style='height:700px;'>
      <div id="featured_slide" style='height:700px;'>
       <?php //include("top_slide.php"); ?>
<head>


</head>
<body>
<?php
error_reporting(0);
session_start();

?>
<?php
//error_reporting(0);
ob_start();
session_start();

$title= $_POST['title'];
$email= $_POST['email'];
$website= $_POST['website'];
$phone= $_POST['phone'];
$content = $_POST['content'];
$date = date("d-M-Y");
include ("rand_id.php");


//Email Generate start


/* email activation start*/
$message = "<table border=0 cellpadding=5 cellspacing=5 align='center'>";
$message .= "<tr><Td>Posted Date</td><td>$date</td></tr>";
$message .= "<tr><Td>Full Name /td><td>$title</td></tr>";
$message .= "<tr><Td>Phone</td><td>$phone</td></tr>";
$message .= "<tr><Td>Email</td><td>$email</td></tr>";
$message .= "<tr><Td>Website </td><td>$website</td></tr>";
$message .= "<tr><Td>Message</td><td>$content</td></tr>";
$message .= "</table>";



$to = "salnazi@gmail.com";

$subject = 'Email Support - Mannaiadvertising.com';

$headers = "From: " . strip_tags($_POST['email']) . "\r\n";
$headers .= "Reply-To: ". strip_tags($_POST['email']) . "\r\n";
$headers .= "CC: mannaiadvertising@gmail.com\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";


if($_POST['submit'] == "Send" && $title != "" && $email != "")
{
if($_POST['cap'] != $_POST['cap_ver']) {
echo "<script type='text/javascript'> alert ('Invalid Captcha!'); window.history.back(); </script>";
}
else {
//if(ereg("^[^@]{1,64}@[^@]{1,200}\.[a-zA-Z]{2,3}$",$_POST['email']))
mail($to, $subject, $message, $headers);

echo "<script type='text/javascript'> alert('Mail has been sent!. We will reply you soon.'); window.location.href='index.php'; </script>";
}
}
if($_POST['submit'] == "Send" && $title == "" && $email == "")
{
echo "<span id='update' style='color:red;'>Please fill mandatory fields *</span>";
}
ob_end_flush();
?> 
<table border=0 cellpadding=10 cellspacing=10 id="circular">
 
  
  
  
  
  
  <form action="email_support.php" method="post" name='form'>
  
   <tr>
    <td colspan=4 align=left style='color:#6E6E6E;font-size:22px;font-weight:bold;'>Send an email</td>
	<br>
	  </tr>
	<tr><td colspan=4><hr></td></tr>
 
  <tr>
  
    <td >Full name <span style='color:red;'>*</span></td>
    <td><input type="text" name="title" id="inp" size=50>
	<br>
	</td>
  </tr>
     <tr>
  <td >Mobile No. <span style='color:red;'>*</span></td>
    <td><input type="text" name="phone" id='inp'  pattern="[789][0-9]{9}" title="Phone number with 7-9 and remaing 9 digit with 0-9" required size=40 maxlength=10><span style='font-size:9px;'> Enter valid phone number</span></td>
  </tr>


  <td >Email <span style='color:red;'>*</span></td>
    <td><input type="text" name="email" id='inp'  size=40 pattern="[^ @]*@[^ @]*" title='Please enter the valid email id' placeholder='example@gmail.com' size=40><span style='font-size:9px;'> Enter the valid email.</span></td>
  </tr>
  
    <tr>
  <td >Website</td>
    <td><input type="text" name="website" id='inp'  size=40 placeholder='http://www.example.com'></td>
  </tr>
  
   <tr><td>Message</td><td><textarea cols=50 rows=4 name="content" id='inp' style='height:100px;'></textarea></td></tr>
<script language="javascript1.2">
  generate_wysiwyg('textarea1');
</script>
  </tr>
  
  <tr>   
  <?php $ra = rand(1000,9999); ?>
<input type='hidden' name='cap' size=10 value='<?php echo $ra; ?>'>
<tr><Td>Captcha</td><td><input type='text' name='cap_ver' id='inp' maxlength=4 required pattern="[0-9][0-9][0-9][0-9]" title='Enter the captcha : <?php echo $ra; ?>' required style='color:black;width:80px;'>&nbsp;&nbsp;<span style='background:silver;border:solid 1px gray;padding-left:10px;padding-right:11px;padding:3px;font-size:20px;color:deeppink;'><?php echo $ra; ?> </span> &nbsp; <span style='font-size:9px;'> Enter the Captcha</span></td></tr>

     <td></td>
    <td><input type="submit" name="submit" value="Send" id="submit"> &nbsp;&nbsp;&nbsp; 
      <input type="submit" name="submit" value="Clear" id="submit"> </td>
  </tr>
  <tr>
  </form>
    <td></td>
  </tr>

</table>
<?php

?>
      </div>
    </div>
    <div class="column">
      <?php include("rightad300_250.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper" >
  <div id="adblock">
    <?php //include("topad468_60ad.php"); ?>
  </div>
  <div id="hpage_cats" >
   <?php //include("place_your_address_code.php"); ?>
    </div>
    <br class="clear" />

  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="hpage_latest">
       <?php //include("content_3col.php"); ?>
        <br class="clear" />
      </div>
    </div>
    <div class="column">
      <?php //include("rightad300_250.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
   <?php include("footer_menu.php"); ?>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="socialise">
    <?php include("footer_2.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col8">
  <div id="copyright">
    <?php include("copyrights.php"); ?>
    <br class="clear" />
  </div>
</div>
</body>
</html>

