<span style='color:deeppink;font-size:17px;font-weight:bold;'>Flash Advertisment</span><br><br><br>
Flash advertisment means that comes on top of website. It will generate only on random basis. <br><br>
This flash advertisments will appear on all web pages.<br><br>
To Visit Sample : See Above Flash Ads<br><br>

<b>Flash Ad Cost : INR 2000 Per Year (Including Design Charges).</b><br><br>
<span style='color:purple;'> <br>If you have own banner.<br> Send us with company profile to : </span><b ><span style='color:deeppink;'>info@mannaiadvertising.com</b></span>