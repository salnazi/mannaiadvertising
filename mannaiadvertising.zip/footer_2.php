<table border=0 cellpadding=10 cellspacing=0 align=center width=100%>
<tr><td style='width:290px;border:none;'>
<?php include("currency_exchange.php"); ?><br><br>
<?php //include("wheather.php"); ?>
</div></td><td style='width:300px;border:none;'><?php include("health_tips.php"); ?></td><td style='border:none;'>

<div id="newsletter" style='border:solid 1px silver;padding:5px;'>
      <h2>NewsLetter Sign Up !</h2>
      <p>Please enter your Name & Email to join.</p>
      <form action="index.php" method="post">
        <fieldset >
          <legend>Digital Newsletter</legend>
          <div class="fl_left">
            <input type="text" name='fullname' value="Enter name here&hellip;"  onfocus="this.value=(this.value=='Enter name here&hellip;')? '' : this.value ;" style='border-radius:3px;background:deeppink;'/>
            <input type="text" name='emailid' value="Enter email address&hellip;"  onfocus="this.value=(this.value=='Enter email address&hellip;')? '' : this.value ;" style='border-radius:3px;background:deeppink;'/>
          </div>
          <div class="fl_right">
            <input type="submit"  name="submit" id="newsletter_go" value="Go!" style='font-size:26px;background:orange;border-radius:3px;'/>
       <!--    </div> -->
        </fieldset>
      </form>
   

	   <?php include("counters.php"); ?>
	  </p>
</div>
	  </td></tr>
</table>


