
 <div class="footbox">
      <h2>Mannai Township</h2>
      <ul>
        <li><a href="about.php?name=Mannai">About Mannargudi</a></li>
        <li><a href="about.php?name=Temple">Mannai Temple</a></li>
        <li><a href="about.php?name=Development" class='last'>Mannai Development</a></li>
        
      </ul>
    </div>
    <div class="footbox">
      <h2>Advertisment Plan</h2>
      <ul>
        <li><a href="advertisement.php?id=Free Ads">Free Advertisment</a></li>
        <li><a href="advertisement.php?id=Premium Ads">Premium Advertisment</a></li>
        <li><a href="advertisement.php?id=Flash Ads" class='last'>Flash Advertisment</a></li>
        
      </ul>
    </div>
    <div class="footbox">
      <h2>About Us</h2>
      <ul>
        <li><a href="about.php?name=Mannai Advertising">Mannai Adverstising</a></li>
  <li><a href="about.php?name=Our Services" class='last'>Our Services</a></li>      
	  <li><a href="Feedback.php">Feedback</a></li>
      
       
      </ul>
    </div>
    <div class="footbox">
      <h2>Help & Support</h2>
      <ul>
        <li><a href="email_support.php">Email Support</a></li>
        <li><a href="#">Chat Support</a></li>
        <li><a href="report-abuse.php" class='last'>Report Absue</a></li>
        
      </ul>
    </div>
    <div class="footbox last">
      <h2>Follow Us</h2>
      <ul>
        <li><a href="https://www.facebook.com/pages/Mannai-Advertising/358580500869000?ref=hl">Facebook</a></li>
        <li><a href="https://twitter.com/mannaiads">Twitter</a></li>
        <li><a href="#" class='last'>Rss Feed</a></li>
        
      </ul>
    </div> 
    <br class="clear" />
  </div>