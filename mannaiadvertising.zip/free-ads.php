<span style='color:deeppink;font-size:17px;font-weight:bold;'>Free Advertisment for Birthdays, Wedding and any other Home Functions</span><br><br>
<span style='color:purple;font-size:17px;font-weight:bold;'>Birthday</span><br><br>
Everyone looks forward to birthdays, be it your own or your loved one's. Birthdays are special as we get wishes from family, friends and sweethearts. So go ahead and make your birthday celebrations with mannaiadvertising.com.
<br><br>
Mannaiadvertising.com Wishes good health and happiness.
<br><br>
To View Sample - Click Here : <a href='celebrity.php?celebration=Birthday'><b>Birthday Ad</b></a>
<br><br>
<span style='color:purple;font-size:17px;font-weight:bold;'>Wedding</span><br><br>
Wedding is one of the most special of occasions in one's life.
<bR><br>
Congratulations and warm wishes to both of you on your wedding day from Mannaiadvertising.com
<br><br>
To View Sample - Click Here : <a href='celebrity.php?celebration=Wedding'><b>Wedding Ad</b></a>
<br><br>
<span style='color:purple;'>Please celebrate your birthday & wedding occasion with mannaiadvertising for free <br>Send your profile with photo to : </span><b ><span style='color:deeppink;'>info@mannaiadvertising.com</b></span>
