<table border=0 cellpadding=0 cellspacing=0 width=100% style='font-size:12px;line-height:15px;color:rgb(5, 155, 216);background:red;border:solid 1.5px orange;'>
<tr><td colspan=2 style='background;deeppink;color:white;text-align:center;font-weight:bold'>HEALTH TIPS</td></tr>
<tr><td style='width:300px;background:red;'>
<span style='font-weight:bold;color:white;'>Parameters</span></td>

<td style='width:300px;background:red;'>

<span style='font-weight:bold;color:white;'>Recommended Values</span>
</td></tr>
<tr><td style='width:300px;background:#3399fe;'>

<p style=' padding:1.5px;color:black;'>Fasting Blood Sugar</p>
<p style=' padding:1.5px;color:white;'>Postprandial blood sugar</p>
<p style=' padding:1.5px;color:black;'>Glycoslyated heamoglobin (HbA1c)</p>
<p style=' padding:1.5px;color:white;'>LDL (Bad) cholestral </p>
<p style=' padding:1.5px;color:black;'>HDL (Good) cholestral </p><br><br><br>
<p style=' padding:1.5px;color:white;'>Blood pressure</p>
</td><td style='width:300px;background:#3399fe;'>
<p style=' padding:1.5px;color:black;'>80 to 100 mg/dl</p>
<p style=' padding:1.5px;color:white;height:30px;' >Less than 140 mg/dl</p>

<p style=' padding:1.5px;color:black;height:30px;'>Less than 7 per cent</p>

<p style=' padding:1.5px;color:white;'>Less than 100 mg/dl</p>
<p style=' padding:1.5px;color:black;'>More than 40 mg/dl in men</p>
<p style=' padding:1.5px;color:black;'>More than 50 mg/dl in women</p>
<p style=' padding:1.5px;color:white;'>Less than 130/80 mm Hg</p>
</td></tr></table>