function startText(srcfield,desfield) {   
query = srcfield.value;   
query = query.replace(/njau/g, "??");   
query = query.replace(/njai/g, "??");   
query = query.replace(/njee/g, "??");   
query = query.replace(/njoo/g, "??");   
query = query.replace(/njaa/g, "??");   
query = query.replace(/njuu/g, "??");   
query = query.replace(/njii/g, "??");   
query = query.replace(/nja/g, "?");   
query = query.replace(/nji/g, "??");   
query = query.replace(/njI/g, "??");   
query = query.replace(/njA/g, "??");   
query = query.replace(/nje/g, "??");   
query = query.replace(/njE/g, "??");   
query = query.replace(/njo/g, "??");   
query = query.replace(/njO/g, "??");   
query = query.replace(/nju/g, "??");   
query = query.replace(/njU/g, "??");   
   
query = query.replace(/nj/g, "??");   
   
   
query = query.replace(/ngau/g, "??");   
query = query.replace(/ngai/g, "??");   
query = query.replace(/ngee/g, "??");   
query = query.replace(/ngoo/g, "??");   
query = query.replace(/ngaa/g, "??");   
query = query.replace(/nguu/g, "??");   
query = query.replace(/ngii/g, "??");   
query = query.replace(/nga/g, "?");   
query = query.replace(/ngi/g, "??");   
query = query.replace(/ngI/g, "??");   
query = query.replace(/ngA/g, "??");   
query = query.replace(/nge/g, "??");   
query = query.replace(/ngE/g, "??");   
query = query.replace(/ngo/g, "??");   
query = query.replace(/ngO/g, "??");   
query = query.replace(/ngu/g, "??");   
query = query.replace(/ngU/g, "??");   
   
query = query.replace(/ng/g, "??");   
   
   
   
query = query.replace(/shau/g, "??");   
query = query.replace(/shai/g, "??");   
query = query.replace(/shee/g, "??");   
query = query.replace(/shoo/g, "??");   
query = query.replace(/shaa/g, "??");   
query = query.replace(/shuu/g, "??");   
query = query.replace(/shii/g, "??");   
query = query.replace(/sha/g, "?");   
query = query.replace(/shi/g, "??");   
query = query.replace(/shI/g, "??");   
query = query.replace(/shA/g, "??");   
query = query.replace(/she/g, "??");   
query = query.replace(/shE/g, "??");   
query = query.replace(/sho/g, "??");   
query = query.replace(/shO/g, "??");   
query = query.replace(/shu/g, "??");   
query = query.replace(/shU/g, "??");   
   
query = query.replace(/sh/g, "??");   
   
query = query.replace(/ nau/g, " ??");   
query = query.replace(/ nai/g, " ??");   
query = query.replace(/ nee/g, " ??");   
query = query.replace(/ noo/g, " ??");   
query = query.replace(/ naa/g, " ??");   
query = query.replace(/ nuu/g, " ??");   
query = query.replace(/ nii/g, " ??");   
query = query.replace(/ na/g, " ?");   
query = query.replace(/ ni/g, " ??");   
query = query.replace(/ nI/g, " ??");   
query = query.replace(/ nA/g, " ??");   
query = query.replace(/ ne/g, " ??");   
query = query.replace(/ nE/g, " ??");   
query = query.replace(/ no/g, " ??");   
query = query.replace(/ nO/g, " ??");   
query = query.replace(/ nu/g, " ??");   
query = query.replace(/ nU/g, " ??");   
   
query = query.replace(/ nth/g, " ??");   
   
query = query.replace(/-nau/g, "??");   
query = query.replace(/-nai/g, "??");   
query = query.replace(/-nee/g, "??");   
query = query.replace(/-noo/g, "??");   
query = query.replace(/-naa/g, "??");   
query = query.replace(/-nuu/g, "??");   
query = query.replace(/-nii/g, "??");   
query = query.replace(/-na/g, "?");   
query = query.replace(/-ni/g, "??");   
query = query.replace(/-nI/g, "??");   
query = query.replace(/-nA/g, "??");   
query = query.replace(/-ne/g, "??");   
query = query.replace(/-nE/g, "??");   
query = query.replace(/-no/g, "??");   
query = query.replace(/-nO/g, "??");   
query = query.replace(/-nu/g, "??");   
query = query.replace(/-nU/g, "??");   
   
query = query.replace(/n-au/g, "??");   
query = query.replace(/n-ai/g, "??");   
query = query.replace(/n-ee/g, "??");   
query = query.replace(/n-oo/g, "??");   
query = query.replace(/n-aa/g, "??");   
query = query.replace(/n-uu/g, "??");   
query = query.replace(/n-ii/g, "??");   
query = query.replace(/n-a/g, "?");   
query = query.replace(/n-i/g, "??");   
query = query.replace(/n-I/g, "??");   
query = query.replace(/n-A/g, "??");   
query = query.replace(/n-e/g, "??");   
query = query.replace(/n-E/g, "??");   
query = query.replace(/n-o/g, "??");   
query = query.replace(/n-O/g, "??");   
query = query.replace(/n-u/g, "??");   
query = query.replace(/n-U/g, "??");   
   
query = query.replace(/wau/g, "??");   
query = query.replace(/wai/g, "??");   
query = query.replace(/wee/g, "??");   
query = query.replace(/woo/g, "??");   
query = query.replace(/waa/g, "??");   
query = query.replace(/wuu/g, "??");   
query = query.replace(/wii/g, "??");   
query = query.replace(/wa/g, "?");   
query = query.replace(/wi/g, "??");   
query = query.replace(/wI/g, "??");   
query = query.replace(/wA/g, "??");   
query = query.replace(/we/g, "??");   
query = query.replace(/wE/g, "??");   
query = query.replace(/wo/g, "??");   
query = query.replace(/wO/g, "??");   
query = query.replace(/wu/g, "??");   
query = query.replace(/wU/g, "??");   
   
   
   
query = query.replace(/ n/g, " ??");   
query = query.replace(/n-/g, "??");   
query = query.replace(/-n/g, "??");   
query = query.replace(/w/g, "??");   
   
   
   
   
query = query.replace(/nthau/g, "????");   
query = query.replace(/nthai/g, "????");   
query = query.replace(/nthee/g, "????");   
query = query.replace(/nthoo/g, "????");   
query = query.replace(/nthaa/g, "????");   
query = query.replace(/nthuu/g, "????");   
query = query.replace(/nthii/g, "????");   
query = query.replace(/ntha/g, "???");   
query = query.replace(/nthi/g, "????");   
query = query.replace(/nthI/g, "????");   
query = query.replace(/nthA/g, "????");   
query = query.replace(/nthe/g, "????");   
query = query.replace(/nthE/g, "????");   
query = query.replace(/ntho/g, "????");   
query = query.replace(/nthO/g, "????");   
query = query.replace(/nthu/g, "????");   
query = query.replace(/nthU/g, "????");   
query = query.replace(/nth/g, "??");   
   
   
   
   
query = query.replace(/dhau/g, "??");   
query = query.replace(/dhai/g, "??");   
query = query.replace(/dhee/g, "??");   
query = query.replace(/dhoo/g, "??");   
query = query.replace(/dhaa/g, "??");   
query = query.replace(/dhuu/g, "??");   
query = query.replace(/dhii/g, "??");   
query = query.replace(/dha/g, "?");   
query = query.replace(/dhi/g, "??");   
query = query.replace(/dhI/g, "??");   
query = query.replace(/dhA/g, "??");   
query = query.replace(/dhe/g, "??");   
query = query.replace(/dhE/g, "??");   
query = query.replace(/dho/g, "??");   
query = query.replace(/dhO/g, "??");   
query = query.replace(/dhu/g, "??");   
query = query.replace(/dhU/g, "??");   
   
query = query.replace(/dh/g, "??");   
   
query = query.replace(/chau/g, "??");   
query = query.replace(/chai/g, "??");   
query = query.replace(/chee/g, "??");   
query = query.replace(/choo/g, "??");   
query = query.replace(/chaa/g, "??");   
query = query.replace(/chuu/g, "??");   
query = query.replace(/chii/g, "??");   
query = query.replace(/cha/g, "?");   
query = query.replace(/chi/g, "??");   
query = query.replace(/chI/g, "??");   
query = query.replace(/chA/g, "??");   
query = query.replace(/che/g, "??");   
query = query.replace(/chE/g, "??");   
query = query.replace(/cho/g, "??");   
query = query.replace(/chO/g, "??");   
query = query.replace(/chu/g, "??");   
query = query.replace(/chU/g, "??");   
   
query = query.replace(/ch/g, "??");   
   
query = query.replace(/zhau/g, "??");   
query = query.replace(/zhai/g, "??");   
query = query.replace(/zhee/g, "??");   
query = query.replace(/zhoo/g, "??");   
query = query.replace(/zhaa/g, "??");   
query = query.replace(/zhuu/g, "??");   
query = query.replace(/zhii/g, "??");   
query = query.replace(/zha/g, "?");   
query = query.replace(/zhi/g, "??");   
query = query.replace(/zhI/g, "??");   
query = query.replace(/zhA/g, "??");   
query = query.replace(/zhe/g, "??");   
query = query.replace(/zhE/g, "??");   
query = query.replace(/zho/g, "??");   
query = query.replace(/zhO/g, "??");   
query = query.replace(/zhu/g, "??");   
query = query.replace(/zhU/g, "??");   
   
query = query.replace(/zh/g, "??");   
query = query.replace(/zau/g, "??");   
query = query.replace(/zai/g, "??");   
query = query.replace(/zee/g, "??");   
query = query.replace(/zoo/g, "??");   
query = query.replace(/zaa/g, "??");   
query = query.replace(/zuu/g, "??");   
query = query.replace(/zii/g, "??");   
query = query.replace(/za/g, "?");   
query = query.replace(/zi/g, "??");   
query = query.replace(/zI/g, "??");   
query = query.replace(/zA/g, "??");   
query = query.replace(/ze/g, "??");   
query = query.replace(/zE/g, "??");   
query = query.replace(/zo/g, "??");   
query = query.replace(/zO/g, "??");   
query = query.replace(/zu/g, "??");   
query = query.replace(/zU/g, "??");   
   
query = query.replace(/z/g, "??");   
   
query = query.replace(/jau/g, "??");   
query = query.replace(/jai/g, "??");   
query = query.replace(/jee/g, "??");   
query = query.replace(/joo/g, "??");   
query = query.replace(/jaa/g, "??");   
query = query.replace(/juu/g, "??");   
query = query.replace(/jii/g, "??");   
query = query.replace(/ja/g, "?");   
query = query.replace(/ji/g, "??");   
query = query.replace(/jI/g, "??");   
query = query.replace(/jA/g, "??");   
query = query.replace(/je/g, "??");   
query = query.replace(/jE/g, "??");   
query = query.replace(/jo/g, "??");   
query = query.replace(/jO/g, "??");   
query = query.replace(/ju/g, "??");   
query = query.replace(/jU/g, "??");   
   
query = query.replace(/j/g, "??");   
   
   
query = query.replace(/thau/g, "??");   
query = query.replace(/thai/g, "??");   
query = query.replace(/thee/g, "??");   
query = query.replace(/thoo/g, "??");   
query = query.replace(/thaa/g, "??");   
query = query.replace(/thuu/g, "??");   
query = query.replace(/thii/g, "??");   
query = query.replace(/tha/g, "?");   
query = query.replace(/thi/g, "??");   
query = query.replace(/thI/g, "??");   
query = query.replace(/thA/g, "??");   
query = query.replace(/the/g, "??");   
query = query.replace(/thE/g, "??");   
query = query.replace(/tho/g, "??");   
query = query.replace(/thO/g, "??");   
query = query.replace(/thu/g, "??");   
query = query.replace(/thU/g, "??");   
   
query = query.replace(/th/g, "??");   
   
query = query.replace(/-hau/g, "??");   
query = query.replace(/-hai/g, "??");   
query = query.replace(/-hee/g, "??");   
query = query.replace(/-hoo/g, "??");   
query = query.replace(/-haa/g, "??");   
query = query.replace(/-huu/g, "??");   
query = query.replace(/-hii/g, "??");   
query = query.replace(/-ha/g, "?");   
query = query.replace(/-hi/g, "??");   
query = query.replace(/-hI/g, "??");   
query = query.replace(/-hA/g, "??");   
query = query.replace(/-he/g, "??");   
query = query.replace(/-hE/g, "??");   
query = query.replace(/-ho/g, "??");   
query = query.replace(/-hO/g, "??");   
query = query.replace(/-hu/g, "??");   
query = query.replace(/-hU/g, "??");   
   
query = query.replace(/-h/g, "??");   
   
query = query.replace(/hau/g, "??");   
query = query.replace(/hai/g, "??");   
query = query.replace(/hee/g, "??");   
query = query.replace(/hoo/g, "??");   
query = query.replace(/haa/g, "??");   
query = query.replace(/huu/g, "??");   
query = query.replace(/hii/g, "??");   
query = query.replace(/ha/g, "?");   
query = query.replace(/hi/g, "??");   
query = query.replace(/hI/g, "??");   
query = query.replace(/hA/g, "??");   
query = query.replace(/he/g, "??");   
query = query.replace(/hE/g, "??");   
query = query.replace(/ho/g, "??");   
query = query.replace(/hO/g, "??");   
query = query.replace(/hu/g, "??");   
query = query.replace(/hU/g, "??");   
   
query = query.replace(/h/g, "??");   
   
query = query.replace(/kau/g, "??");   
query = query.replace(/kai/g, "??");   
query = query.replace(/kee/g, "??");   
query = query.replace(/koo/g, "??");   
query = query.replace(/kaa/g, "??");   
query = query.replace(/kuu/g, "??");   
query = query.replace(/kii/g, "??");   
query = query.replace(/ka/g, "?");   
query = query.replace(/ki/g, "??");   
query = query.replace(/kI/g, "??");   
query = query.replace(/kA/g, "??");   
query = query.replace(/ke/g, "??");   
query = query.replace(/kE/g, "??");   
query = query.replace(/ko/g, "??");   
query = query.replace(/kO/g, "??");   
query = query.replace(/ku/g, "??");   
query = query.replace(/kU/g, "??");   
   
query = query.replace(/k/g, "??");   
   
   
query = query.replace(/-sau/g, "??");   
query = query.replace(/-sai/g, "??");   
query = query.replace(/-see/g, "??");   
query = query.replace(/-soo/g, "??");   
query = query.replace(/-saa/g, "??");   
query = query.replace(/-suu/g, "??");   
query = query.replace(/-sii/g, "??");   
query = query.replace(/-sa/g, "?");   
query = query.replace(/-si/g, "??");   
query = query.replace(/-sI/g, "??");   
query = query.replace(/-sA/g, "??");   
query = query.replace(/-se/g, "??");   
query = query.replace(/-sE/g, "??");   
query = query.replace(/-so/g, "??");   
query = query.replace(/-sO/g, "??");   
query = query.replace(/-su/g, "??");   
query = query.replace(/-sU/g, "??");   
   
query = query.replace(/-s/g, "??");   
   
query = query.replace(/Sau/g, "??");   
query = query.replace(/Sai/g, "??");   
query = query.replace(/See/g, "??");   
query = query.replace(/Soo/g, "??");   
query = query.replace(/Saa/g, "??");   
query = query.replace(/Suu/g, "??");   
query = query.replace(/Sii/g, "??");   
query = query.replace(/Sa/g, "?");   
query = query.replace(/Si/g, "??");   
query = query.replace(/SI/g, "??");   
query = query.replace(/SA/g, "??");   
query = query.replace(/Se/g, "??");   
query = query.replace(/SE/g, "??");   
query = query.replace(/So/g, "??");   
query = query.replace(/SO/g, "??");   
query = query.replace(/Su/g, "??");   
query = query.replace(/SU/g, "??");   
   
query = query.replace(/S/g, "??");   
   
   
query = query.replace(/rau/g, "??");   
query = query.replace(/rai/g, "??");   
query = query.replace(/ree/g, "??");   
query = query.replace(/roo/g, "??");   
query = query.replace(/raa/g, "??");   
query = query.replace(/ruu/g, "??");   
query = query.replace(/rii/g, "??");   
query = query.replace(/ra/g, "?");   
query = query.replace(/ri/g, "??");   
query = query.replace(/rI/g, "??");   
query = query.replace(/rA/g, "??");   
query = query.replace(/re/g, "??");   
query = query.replace(/rE/g, "??");   
query = query.replace(/ro/g, "??");   
query = query.replace(/rO/g, "??");   
query = query.replace(/ru/g, "??");   
query = query.replace(/rU/g, "??");   
   
query = query.replace(/r/g, "??");   
   
query = query.replace(/Rau/g, "??");   
query = query.replace(/Rai/g, "??");   
query = query.replace(/Ree/g, "??");   
query = query.replace(/Roo/g, "??");   
query = query.replace(/Raa/g, "??");   
query = query.replace(/Ruu/g, "??");   
query = query.replace(/Rii/g, "??");   
query = query.replace(/Ra/g, "?");   
query = query.replace(/Ri/g, "??");   
query = query.replace(/RI/g, "??");   
query = query.replace(/RA/g, "??");   
query = query.replace(/Re/g, "??");   
query = query.replace(/RE/g, "??");   
query = query.replace(/Ro/g, "??");   
query = query.replace(/RO/g, "??");   
query = query.replace(/Ru/g, "??");   
query = query.replace(/RU/g, "??");   
   
query = query.replace(/R/g, "??");   
   
query = query.replace(/tau/g, "??");   
query = query.replace(/tai/g, "??");   
query = query.replace(/tee/g, "??");   
query = query.replace(/too/g, "??");   
query = query.replace(/taa/g, "??");   
query = query.replace(/tuu/g, "??");   
query = query.replace(/tii/g, "??");   
query = query.replace(/ta/g, "?");   
query = query.replace(/ti/g, "??");   
query = query.replace(/tI/g, "??");   
query = query.replace(/tA/g, "??");   
query = query.replace(/te/g, "??");   
query = query.replace(/tE/g, "??");   
query = query.replace(/to/g, "??");   
query = query.replace(/tO/g, "??");   
query = query.replace(/tu/g, "??");   
query = query.replace(/tU/g, "??");   
   
query = query.replace(/t/g, "??");   
   
   
   
query = query.replace(/sau/g, "??");   
query = query.replace(/sai/g, "??");   
query = query.replace(/see/g, "??");   
query = query.replace(/soo/g, "??");   
query = query.replace(/saa/g, "??");   
query = query.replace(/suu/g, "??");   
query = query.replace(/sii/g, "??");   
query = query.replace(/sa/g, "?");   
query = query.replace(/si/g, "??");   
query = query.replace(/sI/g, "??");   
query = query.replace(/sA/g, "??");   
query = query.replace(/se/g, "??");   
query = query.replace(/sE/g, "??");   
query = query.replace(/so/g, "??");   
query = query.replace(/sO/g, "??");   
query = query.replace(/su/g, "??");   
query = query.replace(/sU/g, "??");   
   
query = query.replace(/s/g, "??");   
query = query.replace(/pau/g, "??");   
query = query.replace(/pai/g, "??");   
query = query.replace(/pee/g, "??");   
query = query.replace(/poo/g, "??");   
query = query.replace(/paa/g, "??");   
query = query.replace(/puu/g, "??");   
query = query.replace(/pii/g, "??");   
query = query.replace(/pa/g, "?");   
query = query.replace(/pi/g, "??");   
query = query.replace(/pI/g, "??");   
query = query.replace(/pA/g, "??");   
query = query.replace(/pe/g, "??");   
query = query.replace(/pE/g, "??");   
query = query.replace(/po/g, "??");   
query = query.replace(/pO/g, "??");   
query = query.replace(/pu/g, "??");   
query = query.replace(/pU/g, "??");   
   
query = query.replace(/p/g, "??");   
   
query = query.replace(/bau/g, "??");   
query = query.replace(/bai/g, "??");   
query = query.replace(/bee/g, "??");   
query = query.replace(/boo/g, "??");   
query = query.replace(/baa/g, "??");   
query = query.replace(/buu/g, "??");   
query = query.replace(/bii/g, "??");   
query = query.replace(/ba/g, "?");   
query = query.replace(/bi/g, "??");   
query = query.replace(/bI/g, "??");   
query = query.replace(/bA/g, "??");   
query = query.replace(/be/g, "??");   
query = query.replace(/bE/g, "??");   
query = query.replace(/bo/g, "??");   
query = query.replace(/bO/g, "??");   
query = query.replace(/bu/g, "??");   
query = query.replace(/bU/g, "??");   
   
query = query.replace(/b/g, "??");   
query = query.replace(/mau/g, "??");   
query = query.replace(/mai/g, "??");   
query = query.replace(/mee/g, "??");   
query = query.replace(/moo/g, "??");   
query = query.replace(/maa/g, "??");   
query = query.replace(/muu/g, "??");   
query = query.replace(/mii/g, "??");   
query = query.replace(/ma/g, "?");   
query = query.replace(/mi/g, "??");   
query = query.replace(/mI/g, "??");   
query = query.replace(/mA/g, "??");   
query = query.replace(/me/g, "??");   
query = query.replace(/mE/g, "??");   
query = query.replace(/mo/g, "??");   
query = query.replace(/mO/g, "??");   
query = query.replace(/mu/g, "??");   
query = query.replace(/mU/g, "??");   
   
query = query.replace(/m/g, "??");   
   
query = query.replace(/yau/g, "??");   
query = query.replace(/yai/g, "??");   
query = query.replace(/yee/g, "??");   
query = query.replace(/yoo/g, "??");   
query = query.replace(/yaa/g, "??");   
query = query.replace(/yuu/g, "??");   
query = query.replace(/yii/g, "??");   
query = query.replace(/ya/g, "?");   
query = query.replace(/yi/g, "??");   
query = query.replace(/yI/g, "??");   
query = query.replace(/yA/g, "??");   
query = query.replace(/ye/g, "??");   
query = query.replace(/yE/g, "??");   
query = query.replace(/yo/g, "??");   
query = query.replace(/yO/g, "??");   
query = query.replace(/yu/g, "??");   
query = query.replace(/yU/g, "??");   
   
query = query.replace(/y/g, "??");   
   
   
query = query.replace(/dau/g, "??");   
query = query.replace(/dai/g, "??");   
query = query.replace(/dee/g, "??");   
query = query.replace(/doo/g, "??");   
query = query.replace(/daa/g, "??");   
query = query.replace(/duu/g, "??");   
query = query.replace(/dii/g, "??");   
query = query.replace(/da/g, "?");   
query = query.replace(/di/g, "??");   
query = query.replace(/dI/g, "??");   
query = query.replace(/dA/g, "??");   
query = query.replace(/de/g, "??");   
query = query.replace(/dE/g, "??");   
query = query.replace(/do/g, "??");   
query = query.replace(/dO/g, "??");   
query = query.replace(/du/g, "??");   
query = query.replace(/dU/g, "??");   
   
query = query.replace(/d/g, "??");   
   
   
query = query.replace(/nau/g, "??");   
query = query.replace(/nai/g, "??");   
query = query.replace(/nee/g, "??");   
query = query.replace(/noo/g, "??");   
query = query.replace(/naa/g, "??");   
query = query.replace(/nuu/g, "??");   
query = query.replace(/nii/g, "??");   
query = query.replace(/na/g, "?");   
query = query.replace(/ni/g, "??");   
query = query.replace(/nI/g, "??");   
query = query.replace(/nA/g, "??");   
query = query.replace(/ne/g, "??");   
query = query.replace(/nE/g, "??");   
query = query.replace(/no/g, "??");   
query = query.replace(/nO/g, "??");   
query = query.replace(/nu/g, "??");   
query = query.replace(/nU/g, "??");   
   
query = query.replace(/n/g, "??");   
   
query = query.replace(/Nau/g, "??");   
query = query.replace(/Nai/g, "??");   
query = query.replace(/Nee/g, "??");   
query = query.replace(/Noo/g, "??");   
query = query.replace(/Naa/g, "??");   
query = query.replace(/Nuu/g, "??");   
query = query.replace(/Nii/g, "??");   
query = query.replace(/Na/g, "?");   
query = query.replace(/Ni/g, "??");   
query = query.replace(/NI/g, "??");   
query = query.replace(/NA/g, "??");   
query = query.replace(/Ne/g, "??");   
query = query.replace(/NE/g, "??");   
query = query.replace(/No/g, "??");   
query = query.replace(/NO/g, "??");   
query = query.replace(/Nu/g, "??");   
query = query.replace(/NU/g, "??");   
   
query = query.replace(/N/g, "??");   
query = query.replace(/lau/g, "??");   
query = query.replace(/lai/g, "??");   
query = query.replace(/lee/g, "??");   
query = query.replace(/loo/g, "??");   
query = query.replace(/laa/g, "??");   
query = query.replace(/luu/g, "??");   
query = query.replace(/lii/g, "??");   
query = query.replace(/la/g, "?");   
query = query.replace(/li/g, "??");   
query = query.replace(/lI/g, "??");   
query = query.replace(/lA/g, "??");   
query = query.replace(/le/g, "??");   
query = query.replace(/lE/g, "??");   
query = query.replace(/lo/g, "??");   
query = query.replace(/lO/g, "??");   
query = query.replace(/lu/g, "??");   
query = query.replace(/lU/g, "??");   
   
query = query.replace(/l/g, "??");   
query = query.replace(/Lau/g, "??");   
query = query.replace(/Lai/g, "??");   
query = query.replace(/Lee/g, "??");   
query = query.replace(/Loo/g, "??");   
query = query.replace(/Laa/g, "??");   
query = query.replace(/Luu/g, "??");   
query = query.replace(/Lii/g, "??");   
query = query.replace(/La/g, "?");   
query = query.replace(/Li/g, "??");   
query = query.replace(/LI/g, "??");   
query = query.replace(/LA/g, "??");   
query = query.replace(/Le/g, "??");   
query = query.replace(/LE/g, "??");   
query = query.replace(/Lo/g, "??");   
query = query.replace(/LO/g, "??");   
query = query.replace(/Lu/g, "??");   
query = query.replace(/LU/g, "??");   
   
query = query.replace(/L/g, "??");   
   
   
   
query = query.replace(/vau/g, "??");   
query = query.replace(/vai/g, "??");   
query = query.replace(/vee/g, "??");   
query = query.replace(/voo/g, "??");   
query = query.replace(/vaa/g, "??");   
query = query.replace(/vuu/g, "??");   
query = query.replace(/vii/g, "??");   
query = query.replace(/va/g, "?");   
query = query.replace(/vi/g, "??");   
query = query.replace(/vI/g, "??");   
query = query.replace(/vA/g, "??");   
query = query.replace(/ve/g, "??");   
query = query.replace(/vE/g, "??");   
query = query.replace(/vo/g, "??");   
query = query.replace(/vO/g, "??");   
query = query.replace(/vu/g, "??");   
query = query.replace(/vU/g, "??");   
   
query = query.replace(/v/g, "??");   
   
   
   
   
   
query = query.replace(/gau/g, "??");   
query = query.replace(/gai/g, "??");   
query = query.replace(/gee/g, "??");   
query = query.replace(/goo/g, "??");   
query = query.replace(/gaa/g, "??");   
query = query.replace(/guu/g, "??");   
query = query.replace(/gii/g, "??");   
query = query.replace(/ga/g, "?");   
query = query.replace(/gi/g, "??");   
query = query.replace(/gI/g, "??");   
query = query.replace(/gA/g, "??");   
query = query.replace(/ge/g, "??");   
query = query.replace(/gE/g, "??");   
query = query.replace(/go/g, "??");   
query = query.replace(/gO/g, "??");   
query = query.replace(/gu/g, "??");   
query = query.replace(/gU/g, "??");   
   
query = query.replace(/g/g, "??");   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
query = query.replace(/au/g, "?");   
query = query.replace(/ai/g, "?");   
query = query.replace(/aa/g, "?");   
query = query.replace(/ee/g, "?");   
query = query.replace(/ii/g, "?");   
query = query.replace(/uu/g, "?");   
query = query.replace(/oo/g, "?");   
   
   
   
   
query = query.replace(/-1000/g, "?");   
   
query = query.replace(/-100/g, "?");   
   
query = query.replace(/-10/g, "?");   
query = query.replace(/-1/g, "?");   
   
query = query.replace(/-2/g, "?");   
query = query.replace(/-3/g, "?");   
   
query = query.replace(/-4/g, "?");   
query = query.replace(/-5/g, "?");   
   
query = query.replace(/-6/g, "?");   
query = query.replace(/-7/g, "?");   
   
query = query.replace(/-8/g, "?");   
query = query.replace(/-9/g, "?");   
   
   
   
   
query = query.replace(/i/g, "?");   
query = query.replace(/I/g, "?");   
   
   
   
query = query.replace(/a/g, "?");   
   
query = query.replace(/A/g, "?");   
   
query = query.replace(/e/g, "?");   
query = query.replace(/E/g, "?");   
query = query.replace(/i/g, "?");   
query = query.replace(/I/g, "?");   
query = query.replace(/u/g, "?");   
query = query.replace(/U/g, "?");   
query = query.replace(/o/g, "?");   
query = query.replace(/O/g, "?");   
query = query.replace(/x/g, "?");   
query = query.replace(/q/g, "?");   
desfield.value=query;   
}
// JavaScript Document