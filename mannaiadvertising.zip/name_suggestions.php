<?php
// Fill up array with names
include("config/host.php"); 
$s_name = strtolower($_GET["q"]);

	  $sql = mysqli_query($_Conn, "select * from $sal_add_com where title LIKE '%$s_name%' OR tags LIKE '%$s_name%'");
	// $sql = mysqli_query($_Conn, "select * from $sal_add_com where title LIKE substring_index(".$s_name.",' ',1) AND tags LIKE substring_index(".$s_name.",' ',-1)"); 
	   
	  while($row = mysqli_fetch_object($sql))
	  {
	  $title = $row->title ;

	  echo "<a href='category_profile.php?id=$title' style='display:block;'><div style='margin-top:2px;border-radius: 10px;padding:10px;  display:block;border: 1px solid #BADA55;position:relative;z-index:2;background:#FAFAFA;width:933px;'>";
  echo "<span style='color:green;font-size:18px;font-weight:bold;font-family:cambaria;'>$row->title<br>";
	 	  echo "<span style='color:silver;font-weight:bold;font-size:14px;'>Category: $row->category,$row->sub_category<br>";
	  echo "<span style='color:deeppink;font-weight:bold;font-size:14px;'>$row->address<br>";
	  echo "<span style='color:purple;font-weight:bold;font-size:14px;'><span style='color:gray;font-size:12px;font-weight:bold;font-family:cambaria;'>Phone Number, Email ID - Click Here</span><br>";
	  	  echo "Tags: <span style='color:purple;font-weight:bold;font-size:14px;'>$row->tags<br></a>";
		


	
	  	  echo "</div>";
	    
	  }

?>
