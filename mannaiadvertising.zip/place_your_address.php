<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<?php include("title.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
</head>



<body id="top" >
<div class="wrapper col0" style='position:fixed;z-index:1;'>
  <div id="topline" >
<?php include("top_menu.php"); ?>
  </div>
</div><br><Br><br>
<!-- ####################################################################################################### -->

<!-- ####################################################################################################### -->
<!-- <div class="wrapper col2">
  <div id="topbar">
  <div id="topnav">
    <?php include("center_menu.php"); ?>
    </div> 
    <div id="search">
     <?php include("search.php"); ?>
    </div> -->
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper" style='height:700px;'>
  <div class="container" style='height:700px;'>
    <div class="content" style='height:700px;'>
      <div id="featured_slide" style='height:760px;'>
       <?php //include("top_slide.php"); ?>
<head>


</head>
<body>
<?php
error_reporting(0);
session_start();

?>
<?php
//error_reporting(0);
ob_start();
session_start();
include('config/host.php');
//include("company_suggestion.php");
$new_category= $_POST['new_category'];

$sub_category= $_POST['sub_category'];
$s_cat = $_POST['category1'];

$title= $_POST['title'];
$email= $_POST['email'];
$website= $_POST['website'];
$otherinfo= $_POST['otherinfo'];
$tags= $_POST['tags'];
$phone= $_POST['phone'];
$address = $_POST['address'];
$date = date("d-M-Y");
include ("rand_id.php");


//Email Generate start


/* email activation start*/
$message = "<table border=0 cellpadding=5 cellspacing=5 align='center'>";
$message .= "<tr><Td>Posted Date</td><td>$date</td></tr>";
$message .= "<tr><Td>Category</td><td> $s_cat</td></tr>";
$message .= "<tr><Td>Sub Category</td><td> $sub_category</td></tr>";
$message .= "<tr><Td>Company Name</td><td>$title</td></tr>";
$message .= "<tr><Td>Phone</td><td>$phone</td></tr>";
$message .= "<tr><Td>Email</td><td>$email</td></tr>";
$message .= "<tr><Td>Website </td><td>$website</td></tr>";
$message .= "<tr><Td>Otherinfo</td><td>$otherinfo</td></tr>";
$message .= "<tr><Td >Tags</td><td>$tags</td></tr>";
$message .= "<tr ><Td>Address</td><td>$address</td></tr>";
$message .= "<tr><td>Activation Link - </td><Td><a href='http://ads.mannaiadvertising.com/email_activation.php?id=$title&verification=$rand_id'>Click to Activate</a></td></tr>";
$message .= "</table>";



$to = $email;

$subject = 'New Address Received - Mannaiadvertising.com';

$headers = "From: " . strip_tags($_POST['email']) . "\r\n";
$headers .= "Reply-To: ". strip_tags($_POST['email']) . "\r\n";
$headers .= "CC: mannaiadvertising@gmail.com\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";


if($_POST['submit'] == "Save" && $title != "" )
{
if($_POST['cap'] != $_POST['cap_ver']) {
echo "<script type='text/javascript'> alert ('Invalid Captcha!'); window.history.back(); </script>";
}
else {
//if(ereg("^[^@]{1,64}@[^@]{1,200}\.[a-zA-Z]{2,3}$",$_POST['email']))
mail($to, $subject, $message, $headers);

$sql = mysqli_query($_Conn, "insert into $sal_add_com (category, sub_category, title, phone, address,otherinfo, pic, date, tags,email, website, rand_id) values ('$s_cat', '$sub_category', '$title' , '$phone', '$address', '$otherinfo', '$target_path', '$date', '$tags','$email', '$website', '$rand_id')");
$empty="";
mysqli_query($_Conn, "DELETE FROM $sal_add_com where category='$empty'");


echo "<script type='text/javascript'> alert('Successfully Added'); window.location.href='index.php'; </script>";
}
}
if($_POST['submit'] == "Save" && $title == "" )
{
echo "<span id='update' style='color:red;'>Please fill mandatory fields *</span>";
}
ob_end_flush();
?> 
<table border=0 cellpadding=10 cellspacing=10 id="circular">
 
  
  
  
  
  
  <form action="" method="post" name='form'>
  
  <tr>
    <td colspan=4 align=left style='color:#6E6E6E;font-size:22px;font-weight:bold;'>Post Your Address</td>
	<br>
	  </tr>
	<tr><td colspan=4><hr></td></tr>
	
 <tr><Td style='font-size:12px;color:red;'>* fields are mandatory</td></tr>
<?php
$selected = $_POST['category'];
?>
<tr><td colspan=1> Category <span style='color:red;'>*</span></td><td>
<select name='category'  id='inp' required title='Choose Category'>
<option value='' selected>-- ---- --</option>

<?php
include("config/host.php");
$sql = mysqli_query($_Conn, "select DISTINCT category from $sal_main_cat where id order by category");
while($r = mysqli_fetch_object($sql))
{
if($r->category != "") {
?>

<option value='<?php echo $r->category; ?>' onClick='document.form.submit()' 
<?php 
if ($selected && $r->category == $selected) 
{ 
$category = $r->category;
echo "selected"; 
} }?>
>

<?php echo $r->category; ?></option>
<?php
}
?></select>
</td></tr>
</form>
    <form action="place_your_address.php" method="post" >
<?php
$aselected = $_POST['sub_category'];
?>
<tr><td colspan=1>Sub Category <span id='star' style='color:red;'>*</span></td><td>
<select name='sub_category' id='inp' required title='Choose Sub Category'>
<option value='' selected>-- ---- --</option>
<?php
$sql = mysqli_query($_Conn, "select DISTINCT sub_category from $sal_sub_cat where category='$selected'");
while($r = mysqli_fetch_object($sql))
{
$sub_category = $r->sub_category;
?>

<option value='<?php echo $r->sub_category; ?>' 
<?php 
if ($aselected && $r->sub_category == $aselected) 
{ 
$sub_category = $r->sub_category;
echo "selected"; }
 ?> 
 ><?php echo $r->sub_category; ?></option>
<?php
}
?>
</select>
</td></tr>

  
  

	<input type='hidden' name='category1' value="<?php echo $category; ?>">
	
	 
  <tr>
  
    <td >Company name <span style='color:red;'>*</span></td>
    <td><input type="text" name="title" id='inp' value='<?php echo $ntitle; ?>' required title='Enter your company name' onkeyup="showHint(this.value)" size=50>
	<br>
	<div style="font-size:13px;position:absolute;background:white;width:325px;">
	<span id="txtHint"></span></div> 
	</td>
  </tr>
     <tr>
  <td >Mobile No. <span style='color:red;'>*</span></td>
    <td><input type="text" name="phone" id='inp' value='<?php echo $nphone; ?>' pattern="[789][0-9]{9}" title="Phone number with 7-9 and remaing 9 digit with 0-9" required size=40 maxlength=10 placeholder='Enter Valid Phone Number'><span style='font-size:9px;'> </span></td>
  </tr>
  
  <tr><td>Address</td><td><textarea cols=50 rows=4 name="address" id='inp' style='height:100px;'></textarea></td></tr>
<script language="javascript1.2">
  generate_wysiwyg('textarea1');
</script>
  </tr>
  
   <tr><td>Other Info</td><td><textarea cols=50 rows=2 name="otherinfo" id='inp' style='height:100px;'></textarea></td></tr>
<script language="javascript1.2">
  generate_wysiwyg('textarea1');
</script>
  </tr>
   <td >Tags</td>
    <td><input type="text" name="tags" id='inp' value='<?php echo $ntags; ?>' placeholder="Ex:. Mobile, Sales, Service, Accessories" size=40></td>
  </tr>
    <tr>

  <td >Email <span style='color:red;'></span></td>
    <td><input type="text" name="email" id='inp' value='<?php echo $nemail; ?>' pattern="[^ @]*@[^ @]*" title='Please enter the valid email id' placeholder='example@gmail.com' size=40><span style='font-size:9px;'></span></td>
  </tr>
  
    <tr>
  <td >Website</td>
    <td><input type="text" name="website" id='inp' value='<?php echo $nwebsite; ?>' size=40 placeholder='http://www.example.com'></td>
  </tr>
  <tr>   
  <?php $ra = rand(1000,9999); ?>
<input type='hidden' name='cap' size=10 value='<?php echo $ra; ?>'>
<tr><Td>Captcha</td><td><input type='text' name='cap_ver' id='inp' maxlength=4 required pattern="[0-9][0-9][0-9][0-9]" title='Enter the captcha : <?php echo $ra; ?>' required style='color:silver;width:80px;'>&nbsp;<span style='background:silver;border:solid 1px gray;padding-left:10px;padding-right:11px;padding:3px;font-size:20px;color:deeppink;'><?php echo $ra; ?> </span> &nbsp; <span style='font-size:9px;'> Enter the Captcha</span></td></tr>

     <td></td>
    <td><input type="submit" name="submit" value="Save" id="submit"> &nbsp;&nbsp;&nbsp; 
      <input type="submit" name="submit" value="Clear" id="submit"> </td>
  </tr>
  <tr>
  </form>
    <td></td>
  </tr>

</table>
<?php

?>
      </div>
    </div>
    <div class="column">
     <?php //include("right_col.php"); ?>
	 	<div id="fb-root"></div>
<script>(function(d, s, id) {
 var js, fjs = d.getElementsByTagName(s)[0];
 if (d.getElementById(id)) return;
 js = d.createElement(s); js.id = id;
 js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=1437054166542996";
 fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>




<div class="fb-like-box" data-href="https://www.facebook.com/pages/Mannai-Advertising/358580500869000?ref=hl" data-width="250" data-height="350" data-colorscheme="light" data-show-faces="true" data-header="true" data-stream="false" data-show-border="true"></div>
	      <?php include("rightad300_250.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper" >
  <div id="adblock">
    <?php //include("topad468_60ad.php"); ?>
  </div>
  <div id="hpage_cats" >
   <?php //include("place_your_address_code.php"); ?>
    </div>
    <br class="clear" />

  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="hpage_latest">
       <?php //include("content_3col.php"); ?>
        <br class="clear" />
      </div>
    </div>
    <div class="column">
      <?php //include("rightad300_250.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
   <?php include("footer_menu.php"); ?>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="socialise">
    <?php include("footer_2.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col8">
  <div id="copyright">
    <?php include("copyrights.php"); ?>
    <br class="clear" />
  </div>
</div>
</body>
</html>

