<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<?php include("title.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />

<!-- <script type="text/javascript" src="scripts/jquery-dis.js"></script>  -->
</head>



<body id="top">
<div class="wrapper col0">
  <div id="topline">
<?php include("top_menu.php"); ?>

  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="header">
    <div class="fl_left">
   <?php include("company_name.php"); ?>
    </div>
    <div class="fl_right">
	<?php //include("top_banner.php"); ?>
	
	</div>
	
    <br class="clear" />
	
  </div>
</div>
<!-- ####################################################################################################### -->
<!-- <div class="wrapper col2">
  <div id="topbar">
  <div id="topnav">
    <?php //include("center_menu.php"); ?>
	
    </div> 
    <div id="search">
     <?php //include("search.php"); ?>
    </div> -->
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper" style='height:700px;'>
  <div class="container" style='height:700px;'>
    <div class="content" style='height:700px;'>
      <div id="featured_slide" style='height:700px;'>
       <?php //include("top_slide.php"); ?>
<head>
<script src="jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
function showHint(str)
{
  var xmlhttp;
  if (str.length==0)
  { 
    document.getElementById("txtHint").innerHTML="";
    return;
  }
  if (window.XMLHttpRequest)
  {  
     // code for IE7+, Firefox, Chrome, Opera, Safari
     xmlhttp=new XMLHttpRequest();
  }
  else
  {  
     // code for IE6, IE5
     xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function()
  {
    if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
	  
    }
  }
  xmlhttp.open("GET","name_suggestions.php?q="+str,true);
  xmlhttp.send();
}
</script>
</head>
<body>
<?php
error_reporting(0);
session_start();

?>
<?php
//error_reporting(0);
ob_start();
session_start();
include('config/host.php');
include("company_suggestion.php");
$new_category= $_POST['new_category'];

$sub_category= $_POST['sub_category'];
$title= $_POST['title'];
$email= $_POST['email'];
$website= $_POST['website'];
$otherinfo= $_POST['otherinfo'];
$tags= $_POST['tags'];
$phone= $_POST['phone'];
$address = $_POST['address'];
$date = date("d-M-Y");
include ("rand_id.php");

if($_POST['submit'] == "Save" && $title != "")
{
if($_POST['cap'] != $_POST['cap_ver']) {
echo "<script type='text/javascript'> alert ('Invalid Captcha!'); window.history.back(); </script>";
}
else {
$sql = mysqli_query($_Conn, "insert into $sal_add_com (category, sub_category, title, phone, address,otherinfo, pic, date, tags,email, website, rand_id) values ('$new_category', '$sub_category', '$title' , '$phone', '$address', '$otherinfo', '$target_path', '$date', '$tags','$email', '$website', '$rand_id')");
$empty="";
mysqli_query($_Conn, "DELETE FROM $sal_add_com where category='$empty'");

echo "<script type='text/javascript'> alert('Successfully Added'); </script>";
}
}
if($_POST['submit'] == "Save" && $title == "")
{
echo "<span id='update'>Error</span>";
}
ob_end_flush();
?> 
<table border=0 cellpadding=10 cellspacing=10 id="circular">
  <tr>
    <td colspan=2 align=center><h1>Add Your Address</h1></td>
  </tr>
  <tr>
    <td>
	

      </td>
  </tr>
  <form action="" method="" name='form' id='form'>
  <?php


session_start();
include('config/host.php');
echo "<tr><td>Category</td><td>";
echo "<select id='category' name = 'category' style='width:250px;' >";
$sql = mysqli_query($_Conn, "select * from $sal_main_cat");
while($row = mysqli_fetch_array($sql))
{
$cate = $row['category'];
echo "<option value='$cate' onClick='document.form.submit()' >$cate</option>";
}
echo "</select>";
//echo $cate;
?>
</form>

	<form action="place_your_address.php" method="POST" name='form' id='form'>
    
     &nbsp;&nbsp;&nbsp; 
	
      </td>
  </tr>

	
<?php

$new_cate = $_POST['category'];
echo "<input type='hidden' name='new_category' value='$new_cate'>";
echo "<tr><td>Sub Category</td><td>";
echo "<select id='sub_category' name = 'sub_category' style='width:250px;'>";
$sql = mysqli_query($_Conn, "select * from $sal_sub_cat where id  ");
while($row = mysqli_fetch_array($sql))
{
$sub_cate = $row['sub_category'];
echo "<option value='$sub_cate' class='$new_cate' >$sub_cate</option>";
}
echo "</select>";
echo "</td></tr>";

?>
  <tr>
  
    <td >Title</td>
    <td><input type="text" name="title" id="txt1" value='<?php echo $ntitle; ?>' onkeyup="showHint(this.value)" size=50>
	<br>
	<div style="font-size:13px;position:absolute;background:white;width:325px;">
	<span id="txtHint"></span></div> 
	</td>
  </tr>
     <tr>
  <td >Phone No.</td>
    <td><input type="text" name="phone" id='phone' value='<?php echo $nphone; ?>' size=40 ></td>
  </tr>
  
  <tr><td>Address</td><td><textarea cols=50 rows=4 name="address" id='address'></textarea></td></tr>
<script language="javascript1.2">
  generate_wysiwyg('textarea1');
</script>
  </tr>
  
   <tr><td>Other Info</td><td><textarea cols=50 rows=2 name="otherinfo" id='otherinfo'></textarea></td></tr>
<script language="javascript1.2">
  generate_wysiwyg('textarea1');
</script>
  </tr>
   <td >Tags</td>
    <td><input type="text" name="tags" id='tags' value='<?php echo $ntags; ?>' size=40></td>
  </tr>
    <tr>
	<tr><td colspan=2><b>Optional</b></td></tr>
  <td >Email</td>
    <td><input type="text" name="email" id='email' value='<?php echo $nemail; ?>' size=40></td>
  </tr>
  
    <tr>
  <td >Website</td>
    <td><input type="text" name="website" id='website' value='<?php echo $nwebsite; ?>' size=40></td>
  </tr>
  <tr>   
  <?php $ra = rand(1000,9999); ?>
<input type='hidden' name='cap' size=10 value='<?php echo $ra; ?>'>
<tr><Td>Captcha</td><td><input type='text' name='cap_ver' size=8 placeholder="<?php echo $ra; ?>">&nbsp;<span style='background:silver;border:solid 1px gray;padding-left:10px;padding-right:10px;padding:3px;'><?php echo $ra; ?></span></td></tr>

     <td></td>
    <td><input type="submit" name="submit" value="Save" id="submit"> &nbsp;&nbsp;&nbsp; 
      <input type="submit" name="submit" value="Clear" id="submit"> </td>
  </tr>
  <tr>
  </form>
    <td></td>
  </tr>

</table>
<?php

?>
      </div>
    </div>
    <div class="column">
     <?php //include("right_col.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper" >
  <div id="adblock">
    <?php //include("topad468_60ad.php"); ?>
  </div>
  <div id="hpage_cats" >
   <?php //include("place_your_address_code.php"); ?>
    </div>
    <br class="clear" />

  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="hpage_latest">
       <?php //include("content_3col.php"); ?>
        <br class="clear" />
      </div>
    </div>
    <div class="column">
      <?php //include("rightad300_250.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
   <?php //include("footer_menu.php"); ?>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="socialise">
    <?php //include("footer_2.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col8">
  <div id="copyright">
    <?php include("copyrights.php"); ?>
    <br class="clear" />
  </div>
</div>
</body>
</html>

<?php
//newsletter subscription
error_reporting(0);
$to = "Mannaiadvertising.com <mannaiadvertising@gmail.com>";
$from= $_POST['emailid'];
$subject="New Company Address - Mannaiadvertising";
$name=$_POST['fullname'];
$body1= "New Company Address";


$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

$body="<table border=0 cellpadding=0 cellspaing=0 width='100%' style='background:white;border: solid black 1px;'>";
$body .= "<tr><td style='font-weight:bold;'>Hi,</td></tr>";
$body .= "<tr><Td>Company Details</td></tr>";
$body .= "<tr><td style='padding-left:0px;'>Category :  $category.</td><tr>";
$body .= "<tr><td style='padding-left:0px;'>Sub Category :  $sub_category.</td><tr>";
$body .= "<tr><td style='padding-left:0px;'>Title :  $title.</td><tr>";
$body .= "<tr><td style='padding-left:0px;'>Phone :  $phone.</td><tr>";
$body .= "<tr><td style='padding-left:0px;'>Address :  $address.</td><tr>";
$body .= "<tr><td style='padding-left:0px;'>Otherinfo :  $otherinfo.</td><tr>";
$body .= "<tr><td style='padding-left:0px;'>Tags :  $tags.</td><tr>";
$body .= "<tr><td style='padding-left:0px;'>Email :  $email.</td><tr>";
$body .= "<tr><td style='padding-left:0px;'>Website :  $website.</td><tr>";
$body .= "<tr><td><br><br>Sender Email: $from, </td></tr>";
$body .= "<tr><td><br><b>Message:</b><br><br></td></tr>";
$body .= "<tr><td style='padding-left:10px;'>$body1</td></tr>";
$body .= "<tr><td><br><br></td></tr>";
$body .= "<tr><td style='font-weight:bold;'> Thanks,     </td><tr><tr><td style='font-weight:bold; font-size;13px; color:#084B8A; text-transform:capitalize;'> $name </td><tr></table>";

if($_POST['submit'])
{
if(ereg("^[^@]{1,64}@[^@]{1,200}\.[a-zA-Z]{2,3}$",$_POST['emailid'])){
mail($to, $subject, $body,  $headers);
}
}
?>