<span style='color:deeppink;font-size:17px;font-weight:bold;'>Premium Advertisment</span><br><br><br>
<span style='color:purple;font-size:17px;font-weight:bold;'>Join with Us - We will reach your business worldwide.</span><br><br>
<span style='color:purple;font-size:17px;font-weight:bold;'>Sample Banner </span><br><br>
<img src="images/bottomad1.jpg" alt="" width=620 height=100 alt="" />
<b>Size : 620 * 100 (Height * Width)</b><br>
<b>Cost : INR 1000 Per Year (Including Design Charges). </b>
<br><br><br><br>
<img src="images/topadbanner.jpg" alt="" width=468 height=60 alt="" />
<b>Size : 468 * 60 (Height * Width)</b><br>
<b>Cost : INR 500 Per Year (Including Design Charges). </b>
<br><br><br><br>
<img src="images/advertisewithus.gif" alt="" width=300 height=250/>
<b>Size : 300 * 250 (Height * Width)</b><br>
<b>Cost : INR 1000 Per Year (Including Design Charges).</b>
<br><br><br><br>
<img src="images/ad2.jpeg" alt="" width=190 height=130 alt="" />
<b>Size : 190 * 130 (Height * Width)</b><br>
<b>Cost : INR 500 Per Year (Including Design Charges).</b>
<br><br>

<br><br>
<span style='color:purple;'> <br>If you have own banner.<br> Send us with company profile to : </span><b ><span style='color:deeppink;'>info@mannaiadvertising.com</b></span>
