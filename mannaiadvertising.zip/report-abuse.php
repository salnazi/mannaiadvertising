<?php session_start(); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<?php include("title.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" /> 
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>

<script type="text/javascript" language="javascript" src="js/behavior.js"></script>
<script type="text/javascript" language="javascript" src="js/rating.js"></script>

<link rel="stylesheet" type="text/css" href="css/rating.css" />
</head>
<body id="top" >
<div class="wrapper col0" style='position:fixed;z-index:1;'>
  <div id="topline" >
<?php include("top_menu.php"); ?>
  </div>
</div><br><Br><br>
<!-- ####################################################################################################### -->

<!-- ####################################################################################################### -->
<!-- <div class="wrapper col2">
  <div id="topbar">
  <div id="topnav">
    <?php include("center_menu.php"); ?>
    </div> 
    <div id="search">
     <?php include("search.php"); ?>
    </div> -->
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<!--<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="featured_slide">
     
      </div>
    </div>
    <div class="column">
     <?php //include("right_col.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>-->
  <?php //include("top_slide.php"); ?>
<!-- ####################################################################################################### -->

</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="hpage_latest">
	  
	 

	<form action='report-abuse.php' method="post">
	<table border=0 cellpadding=10 cellspacing=10 id='circular'>
	   <tr>
    <td colspan=4 align=left style='color:#6E6E6E;font-size:22px;font-weight:bold;'>Report Abuse</td>
	<br>
	  </tr>
	<tr><td colspan=4><hr></td></tr>
	<tr><td style='width:150px;'>AD ID: </td><td><input type='text' name='adid' size=40 id='inp'></td></tr>
	<tr><td>Your Email </td><td><input type='text' name='youremail' size=50 id='inp'></td></tr>
	
	<tr><td>Comments </td><td><textarea cols=50 rows=5 name='comments' id='inp' style='height:100px;'></textarea></td></tr>
	<tr><td colspan=2 align=center><input type='submit' value='Send!' name='sendemail'></td></tr>
	</table>
	</form>
        <br class="clear" />
      </div>
    </div>
    <div class="column">
      <?php include("rightad300_250.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
   <?php include("footer_menu.php"); ?>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="socialise">
    <?php include("footer_2.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col8">
  <div id="copyright">
    <?php include("copyrights.php"); ?>
    <br class="clear" />
  </div>
</div>
</body>
</html>
<?php

error_reporting(0);
$to = "Mannai Advertising <info@mannaiadvertising.com>";
$from= $_POST['youremail'];

$subject="Mannai Advertising";
$adid = $_POST['adid'];
$body1=nl2br($_POST['comments']);


$headers = "From: mannaiadvertising.com-noreply@mannaiadvertising.com\r\n";
$headers  .= 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";


$body="<table border=0 cellpadding=0 cellspaing=0 width='100%' style='background:white;border: solid black 1px;'><tr><td style='font-weight:bold;'>Hi,<br><br></td></tr><tr><td>Sender: $from, <br>AD Id: $adid,</td><tr><tr><td><br><b>Message:</b><br><br></td></tr><tr><td style='padding-left:10px;'>$body1<br></td><tr><tr><td><br><br></td></tr><tr><td style='font-weight:bold;'>    </td><tr><tr><td style='font-weight:bold; font-size;13px; color:#084B8A; text-transform:capitalize;'> Thanks,<br>$from</td><tr></table>";

if($_POST['sendemail'] )
{
if(ereg("^[^@]{1,64}@[^@]{1,200}\.[a-zA-Z]{2,3}$",$_POST['youremail'])){
mail($to,$subject,$body,$headers);
echo "<script type='text/javascript'> alert ('Message has been sent!'); </script>";
}
else
{
echo "<script type='text/javascript'> alert ('Message sending Failed!. Please check email id'); </script>";
}
}
?>
