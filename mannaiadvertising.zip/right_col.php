 <ul class="latestnews" >
 <h1>Now Showing</h1>
 
 <?php
 $id = $_GET['id'];
 
 include('config/host.php'); 
 $sql = mysqli_query($_Conn, "select * from $sal_cinema_updates where id");
 while($row = mysqli_fetch_object($sql))
 {
 ?>
 
 
        <li ><img src="<?php echo "webadmin/".$row->filmpic; ?>" alt="" height=80 width=80/>
          <p><strong><a href="category_list_view.php?id=Theatres"><?php echo $row->theatre; ?></a></strong> <br>
		   <b style='color:deeppink;'>Film:</b> <?php echo $row->filmname; ?><br>
		 <b style='color:deeppink;'>Starring:</b> <?php echo $row->filmdetails; ?></p>		 
        </li>
		
		
<?php
}
?>		
	
		
		
 
        <li style='height:150px;'> <h1>Celebrations</h1><img src="cinema/celebrations.jpeg" alt="" height=80 width=80/>
          <p><strong><a href="celebration.php">Place Your Ads Free!</a></strong> <br>
		<a href='celebrity.php?celebration=Wedding' style='color:deeppink;'>  Wedding Functions</a><br>
		 <a href='celebrity.php?celebration=Birthday' style='color:deeppink;'> Birthday Celebrations</b><br>
 <span style='color:gray;'>Mail us at : info@mannaiadvertising.com	</span>	 <br></p>
		 </li>
	</ul>	
       
      