<!--
<table border=0 cellpadding=20 cellspacing=20 align=center>
  <tr><td><form action="#" method="post"></td></tr>

          <tr><Td><h1> Search</h1></td></tr>
          <tr><Td><input type="text" value="Search Our Website&hellip;"  onfocus="this.value=(this.value=='Search Our Website&hellip;')? '' : this.value ;"  id='search' style='width:630px;position:relative;z-index:100;'/></td></tr>
         <tr><td style='text-align:center;'> <input type="submit" name="go"  value="Search Address" id='submit'/></td></tr>

        <tr><Td>      </form></td></tr>
	  		  </table>
	
