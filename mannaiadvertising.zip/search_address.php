<?php session_start(); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<?php include("title.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" /> 
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="scripts/jquery.timers.1.2.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.2.1.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.galleryview.setup.js"></script>

<script type="text/javascript" language="javascript" src="js/behavior.js"></script>
<script type="text/javascript" language="javascript" src="js/rating.js"></script>

<link rel="stylesheet" type="text/css" href="css/rating.css" />

<script type="text/javascript">
function showHint(str)
{
  var xmlhttp;
  if (str.length==0)
  { 
    document.getElementById("txtHint").innerHTML="";
    return;
  }
  if (window.XMLHttpRequest)
  {  
     // code for IE7+, Firefox, Chrome, Opera, Safari
     xmlhttp=new XMLHttpRequest();
  }
  else
  {  
     // code for IE6, IE5
     xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function()
  {
    if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
	  
    }
  }
  xmlhttp.open("GET","name_suggestions.php?q="+str,true);
  xmlhttp.send();
}
</script>
</head>
<body id="top" >
<div class="wrapper col0" style='position:fixed;z-index:1;'>
  <div id="topline" >
<?php include("top_menu.php"); ?>
  </div>
</div><br><Br><br>
<!-- ####################################################################################################### -->

<!-- ####################################################################################################### -->
<!-- <div class="wrapper col2">
  <div id="topbar">
  <div id="topnav">
    <?php include("center_menu.php"); ?>
    </div> 
    <div id="search">
     <?php include("search.php"); ?>
    </div> -->
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<!--<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="featured_slide">
     
      </div>
    </div>
    <div class="column">
     <?php //include("right_col.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>-->
  <?php include("top_slide.php"); ?>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="adblock">
 
		<?php
	 

	   echo " <span id='salnazititle'><a href='index.php' id='bread'>Home</a> >> <a id='breadempty'>Search</a>  </span><br><Br>";
	

?> 

<table border=0 cellpadding=10 cellspacing=10 align=center>
  <tr><td><form action="search_address.php" method="post"></td></tr>

  
          <tr><Td>
	
		   <div id="fb-root"></div>
<script>(function(d, s, id) {
 var js, fjs = d.getElementsByTagName(s)[0];
 if (d.getElementById(id)) return;
 js = d.createElement(s); js.id = id;
 js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=162177730659564";
 fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>




<div class="fb-like" data-href="https://www.facebook.com/pages/Mannai-Advertising/358580500869000?ref=hl" data-width="220" data-height="300" data-colorscheme="light" data-show-faces="true" data-header="true" data-stream="false" data-show-border="true"></div></td></tr>
<h1> Search</h1>
<tr><Td>
    <input type="text" name="search_name"  onkeyup="showHint(this.value)" autocomplete='off'  value="Search Our Website&hellip;"  onfocus="this.value=(this.value=='Search Our Website&hellip;')? '' : this.value ;"  id='search' style='width:820px;'>
	
	<div style="font-size:13px;position:absolute;background:white;width:325px;">
	<span id="txtHint"></span></div> 

    <!--      <tr><Td><input type="text" name='search_name' value="Search Our Website&hellip;"  onfocus="this.value=(this.value=='Search Our Website&hellip;')? '' : this.value ;"  id='search' style='width:900px;'/></td></tr>-->
      <input type="submit" name="search"  value="Search Address" id='submit'/></td></tr>

        <tr><Td>      </form></td></tr>
  		  </table> 
	
	

  	<?php
	header("Cache-Control: no-cache, must-revalidate");
	 include("config/host.php"); 
	 
	
	 
	 $s_name = $_POST['search_name'];
//include("name_suggestions.php");
	//$s_name = trim(str_replace(" ","%",$_POST['search_name'])); 
	
if($_POST['search'] == "Search Address")
{
	  
  
	  $sql = mysqli_query($_Conn, "select * from $sal_add_com where title LIKE '%$s_name%' OR tags LIKE '%$s_name%'");
	// $sql = mysqli_query($_Conn, "select * from $sal_add_com where title LIKE substring_index(".$s_name.",' ',1) AND tags LIKE substring_index(".$s_name.",' ',-1)"); 
	   
	  while($row = mysqli_fetch_object($sql))
	  {
	  $title = $row->title ;
	  echo "<a href='category_profile.php?id=$title' style='display:block;'><pre style='border-radius: 10px;padding:10px; border: 1px solid #BADA55;width:945px;'>";
	  echo "<span style='color:green;font-size:18px;font-weight:bold;font-family:cambaria;'>$row->title</span><br>";
	  	  echo "<span style='color:silver;font-weight:bold;font-size:14px;'>Category: $row->category,$row->sub_category<br>";
	  echo "<span style='color:deeppink;font-weight:bold;font-size:14px;'>$row->address<br>";
	  echo "<span style='color:purple;font-weight:bold;font-size:14px;'><span style='color:gray;font-size:12px;font-weight:bold;font-family:cambaria;'>Phone Number, Email ID - Click Here</span><br>";
	  	  echo "Tags: <span style='color:purple;font-weight:bold;font-size:14px;'>$row->tags<br>";
		  

	  echo "</pre></a>";
	  }
	  }

?>
    

  </div>
  <div id="hpage_cats">
  
    </div>
    <br class="clear" />

  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div class="container">
    <div class="content">
      <div id="hpage_latest">
	 
        <br class="clear" />
      </div>
    </div>
    <div class="column">
      <?php //include("rightad300_250.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
   <?php include("footer_menu.php"); ?>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="socialise">
    <?php include("footer_2.php"); ?>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col8">
  <div id="copyright">
    <?php include("copyrights.php"); ?>
    <br class="clear" />
  </div>
</div>
</body>
</html>

