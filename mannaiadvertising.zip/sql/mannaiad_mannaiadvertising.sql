-- phpMyAdmin SQL Dump
-- version 4.1.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 04, 2014 at 10:30 AM
-- Server version: 5.1.72-cll-lve
-- PHP Version: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mannaiad_mannaiadvertising`
--

-- --------------------------------------------------------

--
-- Table structure for table `sal_add_company`
--

CREATE TABLE IF NOT EXISTS `sal_add_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `sub_category` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `otherinfo` text NOT NULL,
  `pic` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `tags` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `rand_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=536 ;

--
-- Dumping data for table `sal_add_company`
--

INSERT INTO `sal_add_company` (`id`, `category`, `sub_category`, `title`, `phone`, `address`, `otherinfo`, `pic`, `date`, `tags`, `email`, `website`, `rand_id`) VALUES
(4, 'Business', 'Mobile Shops', 'Mohan Mobiles', '98944 94848', 'No.2, Sandapettai,\r\nMannai', '', '', '18-Apr-2012', 'recharge cards, sim card, mobile accessories', '', '', '1334763135593171343'),
(7, 'Banks', 'Banks', 'Indian Bank', '04367 252330', 'Email: 	indianbank@vsnl.com and  indbank@vsnl.com\r\nMicr Code:614019010\r\nIFSC Code:IDIB000M017\r\nWebsite:http://www.indian-bank.com\r\nP.B.No.16,\r\n224 MG Road,\r\nMannargudi\r\n', '', '', '25-Apr-2012', '', '', '', '13353294461318760'),
(9, 'Banks', 'Banks', 'City Union Bank (CUB)', '04367 - 252815 , 253933 ', 'CIUB0000007 / NON-MICR / 000007\r\n174, MAHATMA GANDHI ROAD\r\nCity: MANNARGUDI\r\nDistrict: THIRUVARUR\r\nState: TAMIL NADU\r\nPhone: 04367 - 252815 , 253933 Manager Per : 9345184457 Mobile : 9344010248 Email : cub007@cityunionbank.com', '', '', '25-Apr-2012', '', '', '', '13353649431032812809'),
(10, 'Banks', 'Banks', 'ICICI Bank', '022 - 67574314 / 4322', 'ICIC0006087 / 614229002 / 006087\r\nNO:4, KEELA RAJA VEEDHI, \r\nMANNARGUDI, \r\nTHIRUVARUR DIST.\r\nTAMILNADU, \r\nS.INDIA  614001 \r\nCity: MANNARGUDI\r\nDistrict: THIRUVARUR\r\nState: TAMIL NADU', '', '', '25-Apr-2012', '', '', '', '1335365015348239543'),
(11, 'Banks', 'Banks', 'Indian Bank (IB)', '04367 252330', 'IDIB000M017 / 614019010 / 00M017\r\n224 M G Road Mannargudi Thiruvarur 614001\r\n\r\nCity: MANNARGUDI\r\nDistrict: THIRUVARUR\r\nState: TAMIL NADU', '', '', '25-Apr-2012', '', '', '', '1335365055120111248'),
(12, 'Banks', 'Banks', 'Indian Overseas Bank (IOB)', '(04367) 252325', 'IOBA0000896 / NON-MICR / 000896\r\n101, Gandhi Road, \r\nMANNARGUDI, - 614001\r\n\r\nemail: mannarbr@nagasco.iobnet.co.in', '', '', '25-Apr-2012', '', '', '', '1335365134343040253'),
(13, 'Banks', 'Banks', 'State Bank Of India (SBI)', '04367- 251282, 250982, 254624, 252996', 'SBIN0000872 / 614002003 / 000872\r\n236, BIG BAZAR STREET, \r\nMANNARGUDI - 614001\r\n', '', '', '25-Apr-2012', '', '', '', '1335365181993102285'),
(14, 'Banks', 'Banks', 'Lakshmi Vilas Bank (LVB)', '04367 - 222208', 'LAVB0000447 / NON-MICR / 000447\r\n54, BIG BAZAAR STREET,\r\nMANNARGUDI - 614001,\r\nTIRUVARUR DT. TAMIL NADU\r\n', '', '', '25-Apr-2012', '', '', '', '13353652211001164953'),
(15, 'Banks', 'Banks', 'Bank Of India (BOI)', '250606 / 250607 ', 'BKID0008060 / NON-MICR / 008060\r\n30, MELARAJA VEEDHI, \r\nMANNARGUDI\r\n', 'Contact : R. Madhavan.\r\nBranch Manager\r\nMob : 94434 76992', '', '25-Apr-2012', '', '', 'http://www.bankofindia.com', '13353652531191880961'),
(16, 'Banks', 'Banks', 'Karur Vysya Bank (KVB)', '022-22665914, 022-22556467', 'KVBL0001648 / NON-MICR / 001648\r\nD.NO:236, GANDHI ROAD, \r\nMANNARGUDI, \r\nTIRUVARUR DT\r\nEmail : NEFT@KVBMAIL.COM', '', '', '25-Apr-2012', '', '', '', '1335365290499471084'),
(17, 'General Services', 'Govt. Offices', 'Mannargudi Municipality', '04367 ? 252263', 'No.120,Gandhi Road\r\n(Opp) Government Hospital\r\nMannargudi ? 614 001.\r\nE-Mail:commr.mannargudi@tn.gov.in                             \r\n                      ', '', '', '26-Apr-2012', '', '', '', '1335448325287392773'),
(18, 'General Services', 'Govt. Offices', 'Police Station', '222682', 'Taluk Office Road,\r\nMannargudi - 614 001', '', '', '26-Apr-2012', '', '', '', '133544857269097918'),
(19, 'Education', 'Schools', 'National Higher Secondary School', '250390', 'Gandhi Road,\r\nOpp. Indian Bank,\r\nMannargudi', '', '', '26-Apr-2012', '', '', '', '133544942315334239'),
(20, 'Education', 'Schools', 'Findlay Higher Secondary School', '252853', 'VOC Road,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335449432187362942'),
(21, 'Education', 'Schools', 'A.E.S School, East Othai Street', '--', 'Mannargudi', '', '', '26-Apr-2012', '', '', '', '1335449444616944911'),
(22, 'Education', 'Schools', 'Vani vilas High School', '', '', '', '', '26-Apr-2012', '', '', '', '13354494611010810014'),
(23, 'Education', 'Schools', 'St. Joseph Matriculation School', '252794', 'Rukmani Palayam Road,\r\nOpp. Arun Digital Studio,\r\nMannargudi.', '', '', '26-Apr-2012', 'girls', '', '', '1335449470970044561'),
(24, 'Education', 'Schools', 'Govt. Girls Higher Secondary School', '', '', '', '', '26-Apr-2012', '', '', '', '1335449481663437118'),
(25, 'Education', 'Schools', 'Devi Matriculation School', '253099', '', '', '', '26-Apr-2012', '', '', '', '1335449490310563524'),
(26, 'Education', 'Schools', 'Ashoka sishu vihar matriculation school', '271464', 'Mannargudi.', '', '', '26-Apr-2012', '', '', '', '13354494991171008446'),
(27, 'Education', 'Schools', 'Saviour Jesus Matriculation School', '', '', '', '', '26-Apr-2012', '', '', '', '1335449507121128501'),
(28, 'Education', 'Schools', 'SubhashChandra Bose Matriculation school', '250475', 'Mannargudi.', '', '', '26-Apr-2012', '', '', '', '1335449516647613190'),
(29, 'Education', 'Schools', 'Navabarath Matriculation school', '222431', '5th Street,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335449541951658664'),
(30, 'Education', 'Schools', 'Bharathidasan Matriculation Higher Secondary School', '255684', 'Mannargudi.', '', '', '26-Apr-2012', '', '', '', '13354495571047732512'),
(31, 'Education', 'Schools', 'Bharathi Vidyalaya Higher Secondary School', '252359', 'Othai Theru,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '13354495711220364031'),
(32, 'Education', 'Schools', 'Rajambalayam Middle School', '', '', '', '', '26-Apr-2012', '', '', '', '1335449586480934482'),
(33, 'Education', 'Schools', 'Mannargudi Municipality Middle School', '', '', '', '', '26-Apr-2012', '', '', '', '13354495961197306308'),
(34, 'Education', 'Schools', 'ARJ International Residential (CBSE)School', '', '', '', '', '26-Apr-2012', 'cbse syllabus', '', '', '1335449606143206648'),
(35, 'Education', 'Schools', 'St. Joseph School', '', '\r\n', '', '', '26-Apr-2012', '', '', '', '1335449622535263302'),
(36, 'Education', 'Schools', 'Sadasivam Kathirkamavalli Higher Secondary School', '', '', '', '', '26-Apr-2012', '', '', '', '1335449631613252661'),
(37, 'Education', 'Schools', 'Sri Shanmuka Matric Higher Secondary School', '220670  /  251546', '108,Thanjavor Main Road,\r\nMannargudi-614 001', '72,New Bypass Road,\r\nPhone : 251546, 343599', '', '26-Apr-2012', 'Matriculation', 'shanmukaschool1@gmail.com', 'http://www.shanmuka.in', '1335449657738864508'),
(38, 'Education', 'Schools', 'Mannargudi Municipality Urban Bank High School', '', 'GS West St.,\r\nMannargudi', '', '', '26-Apr-2012', '', '', '', '1335449677617924487'),
(39, 'Education', 'Schools', 'Dharani Matriculation Higher Secondary School', '222085 / 98656 99160 ', '55, Gopala Samudhram Vadakku Veedhi,\r\nMannargudi.', '', '', '26-Apr-2012', 'Dharani, Metriculation', '', '', '1335449699226319946'),
(40, 'Education', 'Schools', 'Sai Baalaji Nursery and Primary School', '', '', '', '', '26-Apr-2012', '', '', '', '1335449711735925779'),
(41, 'Education', 'Colleges', 'ARJ College of Engineering and Technology', '223333', 'Ayanaar Garden,\r\nEdayarnatham,\r\nThirumakootai Main Road,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335449734502259109'),
(42, 'Education', 'Arts and Science', 'MRG Government Arts College', '222682', 'V.O.C. Road,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335449796540311888'),
(43, 'Education', 'Arts and Science', 'SK College of Arts and Science', '326424', 'Melavasal, \r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335449819178848162'),
(44, 'Education', 'Arts and Science', 'Ajay Academy', '220829 / 94874 90829 ', '19, MGR Nagar, \r\nMannargudi.', 'Alagappa University and Tamilnadu Open University Study Centre\r\n\r\nDistance Educaiton', '', '26-Apr-2012', 'Distance Educaiton', '', '', '1335449864766820114'),
(45, 'Education', 'ITI', 'Ramajayathammal ITI', '', '', '', '', '26-Apr-2012', '', '', '', '1335449880538239707'),
(46, 'Education', 'ITI', 'Visweswaraya ITI', '', 'Paamani,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335449902983645604'),
(47, 'Education', 'Schools', 'Indira Gandhi ITI', '', 'Keela Raaja Veedhi,\r\nMannargudi', '', '', '26-Apr-2012', '', '', '', '133544992427503593'),
(48, 'Education', 'Polytechnic', 'ARJ Polytechnic College', '', 'Edayarnatham, \r\nMannargudi', '', '', '26-Apr-2012', '', '', '', '1335449943982892083'),
(49, 'Education', 'Polytechnic', 'SK Polytechnic College', '', 'Melavasal,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '13354499631105791258'),
(50, 'Education', 'Teacher Training', 'Government Teacher Training Institute', '', 'Kumarapuram, \r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '133545000896450708'),
(51, 'Entertainments', 'Theatres', 'Sami DTS(6Tracks)-PXD DIGITAL CINEMA', '', 'Rukmani Palayam Middle Street,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335450096467710200'),
(52, 'Entertainments', 'Theatres', 'Shanthi DTS(6Tracks) QUBE DIGITAL CINEMA', '', 'RK payalam Road,\r\nNear MGR Nagar,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335450135676812105'),
(53, 'Business', 'Mobile Shops', 'M Mobiles', '', 'Theradi,\r\nNear Raja Gopala Swamy Temple,\r\nMannargudi.\r\n', '', '', '26-Apr-2012', 'Recharge Cards, Sim Card, Mobile Accessories', '', '', '1335450629220254107'),
(54, 'Business', 'Mobile Shops', 'Univercell Mobile Showroom', '', 'Near Pandhaladi,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335450669465524990'),
(55, 'Business', 'Mobile Shops', 'Classic Cell Park', '', 'Balakrishna Nagar,\r\nMannargudi.', '', '', '26-Apr-2012', 'recharge cards, sim card, mobile accessories', '', '', '1335450702717426854'),
(57, 'Business', 'Electronics Showrooms', 'Moonstar Electronics', '94431 75961', 'RK Palayam Middle Street,\r\nMannargudi.', 'Prop: K.Prem', '', '26-Apr-2012', 'washing machine, dvd players, tv, refrigerator, home theatre', '', '', '1335450832411648283'),
(58, 'Business', 'Electronics Showrooms', 'SGS Electronics', '04367 - 252619', 'Near Arisi Kadai Sandhu,\r\nBig Bazaar Street,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335450872654507902'),
(59, 'Business', 'Metals and Furnitures', 'Jeyamuruga Villas  (Vessels and Furniture)', '254722', '24,Big Bazaar Street,\r\nMannargudi.\r\n', 'Prop:N.Jeyamurugan.', '', '26-Apr-2012', '', '', '', '13354509531069433899'),
(60, 'Business', 'Metals and Furnitures', 'Selvam Metals', '', 'Near Laxmi Vilas Bank,\r\nBig Bazaar Street, \r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '13354509861029874079'),
(61, 'Business', 'Metals and Furnitures', 'AVM Furniture Mart', '253666', 'Big Bazaar Street, \r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335451004232574165'),
(62, 'Business', 'Metals and Furnitures', 'Sri Laxmi Furniture Mart', '95977 96380  / 250016', 'New Street,\r\nNear Keelapaalam,\r\nMannargudi.', '', '', '26-Apr-2012', 'electronics', '', '', '13354510591045396599'),
(63, 'Business', 'Hardware Shops', 'AKR Hardwares', '+91 90437 96106', '69, Big Bazaar St,\r\nMannargudi.', '', '', '26-Apr-2012', 'paints, hardware, coir, ropes', 'akriqbal52@gmail.com', '', '1335451165159784096'),
(64, 'Business', 'Hardware Shops', 'ASP Hardwares', '', 'Big Bazaar St,\r\nMannargudi.', '', '', '26-Apr-2012', 'paints, nylon ropes, iron', '', '', '1335451196269722720'),
(65, 'Business', 'Hardware Shops', 'K K P Hardwares', '', 'Big Bazaar Street, \r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335451282740409225'),
(66, 'Business', 'Hardware Shops', 'TMR Hardwares', '', 'Big Bazaar Street, \r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '13354512931185212306'),
(67, 'Business', 'Hardware Shops', 'TMR & Sons', '', 'Big Bazaar Street, \r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '13354513041091700426'),
(68, 'Business', 'Hardware Shops', 'Murugan Hardwares', '253496', 'Big Bazaar Street, \r\nNear Poorna Lodge,\r\nMannargudi.', '', '', '26-Apr-2012', 'paint, ropes', '', '', '1335451317956594222'),
(69, 'Business', 'Hardware Shops', 'Tamilnadu Glass House', '', 'Mela Raja Veedhi,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '13354513511083713110'),
(70, 'Business', 'Hardware Shops', 'Sri Shakthi Hardwares', '', 'Thamarai Kulam North St, \r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '133545138440765552'),
(71, 'Business', 'Sweet Stalls', 'SMT Sweet Stall', '', 'Near Pandhal Adi,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335451429523546060'),
(72, 'Hospitals and Medicals', 'Medical Stores', 'Meena Medicals', '222664 / 99426 84427', 'Opp. Laxmi Department Stores,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335451460405318712'),
(73, 'Business', 'Hardware Shops', 'MRS Hardwares', '', 'Mela Raja Veedhi,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '13354514781070149744'),
(74, 'Business', 'Sweet Stalls', 'Delhi Sweets', '', 'Pandaladi,\r\nMannargudi.', '', '', '26-Apr-2012', '', '', '', '1335451532871823179'),
(75, 'Business', 'Sweet Stalls', 'Kudandhai Sweets', '', 'Theradi,\r\nMannai.', '', '', '26-Apr-2012', '', '', '', '1335451561786147912'),
(76, 'Business', 'Sweet Stalls', 'Sree Ariyabhavan Sweets', '222677', 'Opp.to:  Bus Stand,\r\nMannai.', 'Party Orders undertaken', '', '26-Apr-2012', 'hotels', '', '', '1335451585547960120'),
(77, 'Business', 'Textile and Readymades', 'Maruthi Cut Piece and Readymades', '254648', '226, Big Bazaar Street,\r\nMannargudi', '', '', '26-Apr-2012', 'readymades', '', '', '133545184136696542'),
(78, 'Business', 'Maligai Stores', 'Cholan Agency', '253678 / 253834 / 98424 23607 / 94431 23607', '48,49 Mela Raja Veethi,\r\nMannargudi', '', '', '26-Apr-2012', 'Maligai, Merchants', '', '', '1335458037807585567'),
(79, 'Business', 'Metals and Furnitures', 'Quality Furniture Mart', '9842370003', 'Big Bazaar Street,\r\nMannargudi', '', '', '26-Apr-2012', '', '', '', '1335459491521360851'),
(81, 'General Services', 'LIC and Insurance Agents', 'G. Dhanabalan', '226416', '42, Natarajan Complex,\r\nRukamani Palayam Middle St,\r\nMannai.\r\nMobile : 94433 16960', '', '', '27-Apr-2012', '', '', '', '1335511000757815546'),
(82, 'Automobiles', 'Motor Showrooms', 'Sree Motors - TVS Authorised Dealers', '252755 / 251186', 'No.6, Third Steet,\r\nMannai.', '', '', '27-Apr-2012', 'bikes, mopeds, tvs', '', '', '1335511126350839189'),
(83, 'Business', 'Broilers, Fish, Beef and Mutton Stalls', 'K.J.R. Broilers', '96266 84486', 'Opp. Shanthi Theatre,\r\nMannargudi.', 'Dealers: Suguna Chicken', '', '27-Apr-2012', '', '', '', '1335511583599463238'),
(84, 'Business', 'Textile and Readymades', 'Guna Readymades', '96885 58600 / 97899 49600', '218, Gandhi Road,\r\nPandaladi,\r\nMannai.', '', '', '27-Apr-2012', '', '', '', '1335511648209893201'),
(85, 'Business', 'Printing Press', 'Gemini Offset Printers and Lithos', '98424 52640  /  94867 43771', '88, Mela Raja Veedhi,\r\nMannai.', '', '', '27-Apr-2012', '', 'geminilithos@gmail.com', '', '1335511683785808828'),
(86, 'Business', 'Marriage Halls', 'TRG Kalayana Mandabam', '', 'Azad Street,\r\nMannai.', '', '', '27-Apr-2012', '', '', '', '1335511706724547621'),
(88, 'Hospitals', 'Clinics', 'Bharathi Health Centre - Heart Care', '255720', '27/1, Old Thanjavour Salai,\r\nKeerthi Clinic Complex,\r\nMannai.', '', '', '27-Apr-2012', '', '', '', '13355120181165470072'),
(89, 'Business', 'Metals and Furnitures', 'Royal and Co.', '98424 90890', 'Big Bazaar St,\r\nMannai.', '', '', '27-Apr-2012', '', '', '', '133551227344420126'),
(90, 'Business', 'Opticals', 'Allwin Opticals', '253931', '1/3, Mahamariamman Kovil Street,\r\nMannargudi.', '', '', '27-Apr-2012', '', '', '', '13355279841000750517'),
(91, 'Hospitals', 'Clinics', 'Tamilnadu Hospitals', '04367 222497, 222181', 'Mr.Selvamani.\r\n185, Nataraja Pillai Street,\r\nMannargudi - 614 001.\r\nCell : 94434 92173\r\nWeb : http://tamilnaduhospitals.com', '', '', '28-Apr-2012', 'Test tube baby', '', '', '1335590756778462004'),
(92, 'Business', 'Sweet Stalls', 'SMT Sweet land And Tiffin centre', '253045', 'Pandaladi West Side,\r\nMannargudi.', '', '', '28-Apr-2012', 'sweets ', '', '', '1335605008260416743'),
(93, 'Business', 'Broilers, Fish, Beef and Mutton Stalls', 'AVM Broiler Centre', '', 'Parangusam Street,\r\nMannargudi.', '', '', '28-Apr-2012', 'broilers,eggs, chicken', '', '', '1335605107400194773'),
(94, 'Business', 'Printing Press', 'Raja Offset Printers', '255578', 'Theradi,\r\nMannargudi.', '', '', '28-Apr-2012', 'printers', '', '', '1335605233995099114'),
(95, 'Business', 'Photo Studios', 'SMT Flex and Studio', '9944390888', '2,Bus Stand,\r\nMannargudi.', '', '', '28-Apr-2012', 'flex , photos', '', '', '1335605327921480173'),
(96, 'Business', 'Solar Power Systems', 'Mannai Sri Vekkaliamman Traders', '98436 64224 / 97517 99708', '41/4, Second Floor,\r\nSivakami Complex,\r\nMGR Nagar,Mannargudi.\r\nEmail : mannaivekaliamman@yahoo.com', '', '', '29-Apr-2012', 'solar systems, battery, inverters', '', '', '1335673229920651300'),
(97, 'Education', 'Arts and Science', 'Sengamala Thayaar Educational Trust  Womens College', '255423 / 251282', 'Sundarakottai,\r\nMannargudi.\r\n', '', '', '29-Apr-2012', '', 'stet_wc@yahoo.com', '', '13356762141094601480'),
(99, 'Hospitals and Medicals', 'Medical Stores', 'Indian Medicals', '04367-252256', 'Opposite of keerthi poly clinic,\r\n40-A,balakrishnan nagar,\r\nMannargudi.', '', '', '29-Apr-2012', '', '', '', '1335695247351877982'),
(100, 'Hospitals and Medicals', 'Medical Stores', 'Arokyam Medical Stores', '04367-250542', '109/74,gandhi road,\r\npandhaladi,\r\nMannargudi-614001.', '', '', '29-Apr-2012', '', '', '', '1335696938354326478'),
(101, 'Hospitals and Medicals', 'Medical Stores', 'Paarthi Medicals', '', '52,rukkumani paalayam road,\r\nNear Pottayan Kulam\r\nMannargudi', '', '', '29-Apr-2012', '', '', '', '1335697610864039770'),
(103, 'Business', 'Mobile Shops', 'Baba Cell Care', '99443 45311', 'Municipality Complex,\r\n1st Floor,\r\nRagavendra cell care upstairs,\r\nNear Bus Stand,\r\nMannargudi.', '', '', '29-Apr-2012', 'mobile service', '', '', '1335704147892441922'),
(104, 'Business', 'Mobile Shops', 'Paviska Mobiles', '99761 98975 / 316351', 'Pandaladi,\r\nOpp. ICICI Bank,\r\nMannargudi.', 'Mobile Sales and Service\r\n\r\nProp: Murugesan', '', '29-Apr-2012', 'mobile service, Mobile recharge, mobile accessories', '', '', '13357044031029958477'),
(105, 'General Services', 'Electricians - Plumbers', 'P.Loganathan. B.Com.,', '97867 74512', '15/11, Senbaga Vinayagar Koil Street,\r\nNear Shakthi Timber Depot.\r\nMannargudi', 'All Types of Electrical, Motor, Pump Set, Plumbing Works, UPS, Inverter Installation.', '', '29-Apr-2012', 'electrical works, plumbing works, Labour Contract Works', '', '', '133570465612206708'),
(106, 'Business', 'General Merchants', 'Shanthi Stores', '', 'Gandhi Road,\r\nMannargudi', '', '', '29-Apr-2012', '', '', '', '1335705387394678204'),
(107, 'Business', 'General Merchants', 'Balan Store', '', 'Gandhi Road,\r\nMannargudi', '', '', '29-Apr-2012', '', '', '', '1335705400183369856'),
(108, 'Business', 'General Merchants', 'Pink and Blue', '80988 41132', 'Baby Super Market,\r\nNo.6, R.K.Palayam Middle Street,\r\nMannargudi.', '', '', '29-Apr-2012', 'toys, baby dresses', '', '', '13357109151177694625'),
(109, 'Travels', 'Drivers', 'Arivalagan - Ambassador', '99449 27879', 'Government Hospital Taxi Stand,\r\nOpp. Near GH.\r\nMannargudi.', '', '', '29-Apr-2012', 'ambassador, car driver', '', '', '1335711427632822962'),
(110, 'Business', 'Textile and Readymades', 'Mohan Stores', '', '11, Big Bazaar Street,\r\nMannargudi.', '', '', '29-Apr-2012', 'lungies, vests, briefs', '', '', '1335715856662550961'),
(111, 'Travels', 'Travel Agencies', 'SG Aishwarya Travels', '04367-319933 ', '26, Annavasal Street,\r\nOpp. Fire Service Station,\r\nMannargudi.\r\n\r\nContact : NR. Rajani Balu\r\nMob : 9865339939', '', '', '29-Apr-2012', '', '', '', '1335716054271723162'),
(112, 'Business', 'Textile and Readymades', 'Saagar Silk House and  Readymades', '252266  /  94437 87350', 'No.5, Big Bazaar Street,\r\nMannargudi.', 'Prop: A.Haja Maideen, A.Abdul Rahman', '', '29-Apr-2012', 'gents wear, ladies wear, kids wear', '', '', '13357162251020593253'),
(113, 'Hospitals and Medicals', 'Medical Stores', 'Arasu Medicals', '251283', 'Opp. Jawahar Water Service Station.\r\nMannargudi', '', '', '29-Apr-2012', '', '', '', '133571632849624278'),
(114, 'Travels', 'Travel Agencies', 'Arun Travels and Autos', '9750885755 ', 'Contact : K. Raja\r\nMob :  8903470236', '', '', '29-Apr-2012', 'auto, amway products agent', '', '', '1335716477718217888'),
(115, 'Hospitals and Medicals', 'Medical Stores', 'Rajesh Medicals', '96772 16362', 'Ganesh Complex,\r\n107 / 31, Melaraja Veedhi,\r\nMannargudi.', '', '', '29-Apr-2012', '', '', '', '133571654849943955'),
(116, 'Business', 'Photo Studios', 'Thangam Digital Studio A/c - Video', '250378 ', '158, Gandhi Road,\r\nMannrgudi.\r\nMobile: 9443492441', '', '', '29-Apr-2012', 'wedding photos, videos, studio', '', '', '1335716686696321056'),
(117, 'Hospitals', 'Clinics', 'CAK Poly Clinic ', '', 'Dr. Ashok Kumar\r\nMGR Nagar,\r\nBehind Shanthi Theatre,\r\nMannargudi.', '', '', '29-Apr-2012', '', '', '', '1335716788197194865'),
(118, 'Business', 'Photo Studios', 'Santhanam Video and Photos', '99768 98198', '', '', '', '29-Apr-2012', 'wedding photos, videos, studio', '', '', '13357168561215401424'),
(119, 'Hospitals', 'Clinics', 'Aarthi Nursing Home', '224540', 'Dr. Geetha\r\nMannargudi.', '', '', '29-Apr-2012', 'ladies specialist', '', '', '1335717074326437245'),
(120, 'Business', 'Tailors', 'Feminas Ladies Tailor', '', 'Old Shanmuganandha,\r\nNSA Complex,\r\n57,58, Vinobaji Street,\r\nMannargudi', '', '', '29-Apr-2012', 'Ladies Tailor, Chudithar Specialist', '', '', '1335717238878468267'),
(121, 'General Services', 'Marriage Cooks', 'K. Mohammed Saali', '99432 78895', '35, Mela Badhmasaalavar Street,\r\nMannargudi.\r\n\r\n\r\nM. Jahir Hussain\r\nMob : 80158 55519\r\nM. Shahul Hameed,\r\nMob : 91594 48881', '', '', '29-Apr-2012', '', '', '', '13357181181066351137'),
(122, 'Business', 'Decoration Centres', 'Praveen Decoration Centre', '270559', '76-B, Taluk Office Road,\r\nMannargudi.\r\n\r\nContact: V. Senthil Murugan\r\nMob : 98424 96006', '', '', '29-Apr-2012', 'marriage hall decoration, decorations', '', '', '1335718313582025710'),
(123, 'Business', 'Electronics Showrooms', 'AR Air Cons', '94434 02525 / 97152 79355', '23, Rukkmani Palayam Street,\r\nMannargudi.\r\n\r\nContact : Selvamani\r\nEmail : ar_aircon2008@yahoo.com\r\nLG Authorised Sales and Service Dealer', '', '', '29-Apr-2012', 'AC service, AC sales, air conditioner, LG Authorised, dealer', '', '', '1335718484898569435'),
(124, 'Hospitals and Medicals', 'Blood Testing,E.C.G. - X-Rays Centers', 'Prabhu X-Rays ', '254751', '129A, Gandhi Road,\r\nNew Vijaya Medical Upstairs,\r\nMannargudi.\r\n\r\nMob : 92451 40175', '', '', '29-Apr-2012', 'xray, body scan, blood check up, ECG', '', '', '13357192951158286974'),
(125, 'Hospitals and Medicals', 'Doctors', 'Dr. Noorjahan Wahid MD.,DGO', '', 'Rajesh Medicals, Upstairs\r\nMannargudi.\r\n\r\n', 'Visit time: Sunday 2.30 PM to 4.30 PM', '', '29-Apr-2012', '', '', '', '1335719445985632641'),
(126, 'Hospitals and Medicals', 'Doctors', 'Dr. Babu MBBS., DLO', '', 'Meena Medicals\r\nOpp. LDS,\r\nBus Stand Road,\r\nMannargudi.\r\n\r\n\r\n', 'Visit Hours: 4.00 p.m. to 8.oo p.m\r\n             Every Tue,Thu,Saturdays', '', '29-Apr-2012', 'ear specialist, nose specialist, throat specialist', '', '', '1335719584556733205'),
(127, 'Hospitals and Medicals', 'Doctors', 'Sr. T.P. Dhandabhani MBBS DD', '', 'Golden Medical, Upstairs\r\nMannargudi\r\n\r\nVisit Time : Morning 11.00AM to 1.30 PM\r\nEvening : 5.30 PM to 8.30 PM', '', '', '29-Apr-2012', 'Skin specialist, civil  surgeon', '', '', '1335719798593281112'),
(128, 'Hospitals and Medicals', 'Medical Stores', 'Golden Medicals', '252383', 'Jinab Building,\r\n49, Mahamaariamman Street,\r\nMannargudi.', '', '', '29-Apr-2012', '', '', '', '1335719869726652534'),
(129, 'Education', 'Arts and Science', 'Sadasivam Kadhir Kaamavalli Art and Science (for Girls)', '04367 326424', 'Kumarapuram,\r\nMelavasal,\r\nMannargudi.\r\n', 'Affiliated to Bharathidasan University', '', '30-Apr-2012', 'arts and science', '', '', '1335777494680696446'),
(130, 'Business', 'Electrical Stores', 'Ram Dev Electricals', '98949 85726 / 99447 01536', '200, Big Bazaar Street,\r\nMannargudi.', '', '', '30-Apr-2012', 'electrical goods, fans,heaters', '', '', '1335778422442170012'),
(131, 'Business', 'Battery Sellers', 'Sami Battery Centre', '253658 / 94437 43190', '106/64, 3rd Street,\r\nMannargudi.', 'Contact: C. Sami Nathan', '', '30-Apr-2012', 'Battery, Inverter, UPS, exide, dealer,Sami Battery', '', '', '1335789225906086596'),
(132, 'Business', 'Battery Sellers', 'Veera Battery Works', '94435 32230', 'Annavasal Seniya Street,\r\nMannargudi', '', '', '30-Apr-2012', 'Battery, Inverter, UPS', '', '', '1335789291317397281'),
(133, 'Banks', 'Finance Co', 'Muthoot Finance Private Limited', '251372', 'Big Bazaar Street,\r\nMannargudi', '', '', '30-Apr-2012', 'gold loan, loan', '', '', '1335789431920435459'),
(134, 'Business', 'Electrical Stores', 'Lakshmi Traders (Devi Electricals)', '251353', '20, Big Bazaar Street,\r\nMannargudi.', '', '', '30-Apr-2012', 'Electrical goods, PVC Hoses', '', '', '1335798580432055722'),
(135, 'Hospitals and Medicals', 'Doctors', 'Dr. Najimarani BSc.,MD.,P.G.D.Diab.,', '96881 02223', 'No.107/31, Rajesh Medical Upstairs\r\nMelarajaveedi,\r\nNear Bank of India (BOI)\r\nMannargudi', 'Visit Hours : Evening 5.00pm to 8.00Pm', '', '30-Apr-2012', 'diabetics, government hospital', '', '', '1335798838190811373'),
(136, 'Business', 'Other Category', 'Mannai Chamber of Commerce', '252195', '2/114, Melaraja Veedhi,\r\nMannargudi.', '', '', '30-Apr-2012', '', '', '', '1335799154498936633'),
(137, 'Education', 'Arts and Science', 'Arunamalai B.Ed College', '326323 / 326424  /227997  /  94437 91436', 'Kumarapuram,\r\nMelavasal,\r\nMannargudi.', '', '', '30-Apr-2012', 'B.Ed College', '', '', '13357992891021739185'),
(138, 'Business', 'Other Category', 'Mannargudi Manavala Kalai Mandram Charity', '98651 32534 / 99426 71753', 'Gopala Samudram Keelaveedi,\r\nMannargudi', '', '', '30-Apr-2012', 'Charity', '', '', '1335799468701294269'),
(139, 'Business', 'Spare Parts stores', 'Latha Traders', '220242', '47, Rukmanipalayam Road, \r\nOpp to.Pottaiyankulam,\r\nMannargudi.\r\nRes: 220041\r\nMobile: 94436 70384', 'Mixies, Motors,Fans,Cookers,Gas Stove and related spare aprts available.', '', '01-May-2012', 'Mixie Jars, Mixie spare parts', '', '', '1335870828840385717'),
(141, 'Hospitals and Medicals', 'Clinics', 'Gokulam Hospital', '223490', 'No.22, MGR Nagar,\r\nMannargudi.', '', '', '01-May-2012', 'Skin specialist', '', '', '1335891364390078412'),
(142, 'Hospitals and Medicals', 'Doctors', 'Dr. N.Vijaya Kumar M.D., (Skin)', '222704', 'No 22, MGR Nagar,\r\nMannargudi.', '', '', '01-May-2012', 'Gokulam Hospital, Skin Specialist', '', '', '1335891430973694136'),
(143, 'Business', 'Gas Agencies', 'Rukmani Gas Agencies', '252089 / 252908 / 250766 / 252375', '10-B, 3rd Stree,\r\nMannargudi', '', '', '01-May-2012', 'Gas, Indane', '', '', '1335891847413725623'),
(144, 'Business', 'Pets and Aquarium', 'Naaga Aquarium', '93658 29029', 'Uppu Kaara Street,\r\nMannargudi.', '', '', '01-May-2012', 'Pets, Dogs, Fish', '', '', '1335891985713828321'),
(145, 'Hospitals and Medicals', 'Medical Stores', 'Priya Medicals', '351680', '41/11B, Kamal Nagar,\r\nMannargudi.', '', '', '01-May-2012', '', '', '', '1335881715700849405'),
(146, 'Business', 'News Paper Agents', 'Dhina Thanthi', '9865932856 / 9786302020 / 8940536913', 'K. Latha,\r\n151, Keela Raja Veedhi,\r\nMannargudi.', '', '', '02-May-2012', 'News Paper Agents', '', '', '13359773361101307811'),
(147, 'Business', 'Printing Press', 'Vairam Press', '250063 / 94435 88243', '72/2, Mela Raja Veedhi,\r\nMannargudi.', '', '', '02-May-2012', 'printing jobs', '', '', '1335977418480030258'),
(148, 'General Services', 'Mason', 'P.Kalimuthu,   Bldg Mashthri', '7639720901', '42/47, Kaathayi Amman Koil Street,\r\nMannargudi.', '', '', '03-May-2012', '', '', '', '1336035111170031973'),
(149, 'Automobiles', 'Motor Showrooms', 'N.Dhasarathi and Sons', '94869 70400', 'Mahindra  Tractor Dealers,\r\nBranch Office: No. 10, Keela Palam, Mannargudi.', '', '', '03-May-2012', 'Tractors', '', '', '13360355611118073640'),
(150, 'General Services', 'Others', 'R..Palanisamy and Sons', '250501', '52, Azad Street, \r\nMannargudi', 'Sewing Machine Mechanic', '', '03-May-2012', 'Sewing', '', '', '1336044682893599918'),
(151, 'Business', 'Coir Merchants', 'A. Murugesan', '9715279486', 'Nataraja Pillai Street,\r\nMannargudi.', '', '', '03-May-2012', 'coir producers', '', '', '1336044891361539178'),
(152, 'Business', 'Textile and Readymades', 'Om Muruga Textiles', '98424 95945', '29, Big Bazaar Street,\r\nMannargudi.', '', '', '03-May-2012', 'Textiles', '', '', '1336045013166264371'),
(153, 'Business', 'Marriage Halls', 'Maha Laxmi Marriage Hall', '', 'Keela raja Veedhi,\r\nMannargudi', '', '', '03-May-2012', '', '', '', '1336045099872991136'),
(154, 'Education', 'Teacher Training', 'Arunamalai Teacher Traing Institute (D.T.Ed)', '', '27, Serumangalam,\r\nThanjavur Main Road,\r\nMannargudi.', '', '', '03-May-2012', '', '', '', '1336045382138421793'),
(155, 'Education', 'ITI', 'Cholas Industrial School', '96980 77111 / 96981 77111 / 97500 21217', '7, Mela Othai Street,\r\nMannargudi.', 'A/C Course,Electrician,Welder,TV-Radio repair,Cellphone repair courses\r\n\r\nGovernment Certified.', '', '03-May-2012', 'Institute, Training', '', '', '1336045695522265075'),
(156, 'Business', 'Service Providers', 'Cholas A/c Service Home', '06980 77111 / 96981 77111 / 97500 21217', '7, Mela Othai Street,\r\nMannargudi.', '', '', '03-May-2012', '', '', '', '1336046528472042942'),
(157, 'Business', 'Steel Company', 'Vairam Steel Company', '220002 / 227211 / 94430 94648 / 99655 27211 / 94434 95357', '66, Gopalasamudram South Street,\r\nMannargudi.', 'Dealers: Agni TMT, Amman Try, Kiscol TMT, Kanishk TMT, Arasu cement sheets.', '', '03-May-2012', 'steels,TMT rods', '', '', '1336046909288862137'),
(158, 'Business', 'Steel Company', 'Indian Steels and Pipes', '227311 / 99761 06269', '127, Nataraja Pillai Street,\r\nThanjavur Main Road,\r\nMannargudi.', 'Electrical goods, Steels, Pipes Dealers', '', '03-May-2012', 'Electricals, pipes', '', '', '1336047103126930608'),
(159, 'Business', 'Textile and Readymades', 'Maruthi Cutpiece and Readymades', '254648', '', '', '', '03-May-2012', '', '', '', '1336047177369488818'),
(160, 'Business', 'Sweet Stalls', 'Krishna Biscuits and sweets', '252608', '234, Big Bazaar Street, Mannargudi.', '', '', '03-May-2012', 'sweets', '', '', '1336047541931238261'),
(161, 'Business', 'Sweet Stalls', 'New Krishna Bakery', '224275', '27, Natesan Street,\r\nMannargudi.', '', '', '03-May-2012', 'sweets', '', '', '133604766322417331'),
(162, 'Business', 'Textile and Readymades', 'A. Duraisamy Mudaliar and Sons', '253244', '222, Big Bazaar Street,\r\nMannargudi.', '', '', '03-May-2012', 'textiles', '', '', '13360477661162569018'),
(163, 'Business', 'Tailors', 'Goodwill Tailors', '254145', '75,Big Bazaar Street,\r\nMannargudi.', 'working hours: 9.00am to 9.00pm.\r\nsundays holiday.', '', '03-May-2012', 'tailors', '', '', '13360478961086840220'),
(164, 'Business', 'Shoe Marts', 'Danam Shoe Mart', '94860 43042', '73, Big Bazaar Street,\r\nMannargudi.', '', '', '03-May-2012', 'shoes', '', '', '1336048019460589432'),
(165, 'General Services', 'LIC and Insurance Agents', 'P. Gopalakrishnan. M.A.,', '94860 43042', '73, Big Bazaar Street,\r\nMannargudi.', '', '', '03-May-2012', '', '', '', '1336048165873895360'),
(166, 'Business', 'Fancy Stores', 'Mariappa Fancy Stores', '81484 29923', '225, Big Bazaar Street,\r\nMannargudi.', '', '', '03-May-2012', 'Fancy goods', '', '', '1336048366789877838'),
(167, 'Banks', 'ATM Centres', 'State Bank ATM Centre', '', 'Rukmani Palayam Road,\r\nOpp. Moonstar Electronics\r\nMannargudi.\r\n', '', '', '03-May-2012', 'SBI', '', '', '13360492691217387626'),
(168, 'Hotels, Lodges and Restaurants', 'Lodges', 'New Mannai TMA Towers', '221814 / 222814 / 223814', 'Mannargudi.', 'A/C Classical Hotel\r\nFax : 04367-224814', '', '03-May-2012', 'Hotel, Boarding, Lodge', 'tmatowers@gmail.com', '', '1336051961799108463'),
(169, 'Employment', 'Recruitment Consultancy', 'Saimass Consultancy and Trading', '227435 / 98410 25435 / 94438 65435', '198, Swathi Complex,\r\nNataraj Pillai Street,\r\nMannargudi.', 'Manpower Recruiting & Air Ticketing. \r\nWe have low levy skilled training center for Singapore. \r\nPlacement for Malaysia all other middle east countries.', '', '03-May-2012', 'overseas recruitment, employment, real estate, construction, building', 'saimassconsultancy@ymail.com / saimassconsultancy@yahoo.com ', 'www.saimass.com', '1336052115224511497'),
(170, 'Business', 'Electronics Showrooms', 'Jeeva Electronics', '9842477594', 'Near Udupi Hotel,\r\nPandaladi,\r\nMannargudi', 'UPS and Inverter Sales and Services', '', '03-May-2012', 'Inverter, UPS', '', '', '1336052402852382354'),
(171, 'Automobiles', 'Motor Mechanics', 'Jayaraj', '9894548477', 'Masthan Palli Street,\r\nMannargudi', 'Bike Mechanic', '', '03-May-2012', 'Bike, Mechanic', '', '', '1336052691716786361'),
(172, 'Business', 'Broilers, Fish, Beef and Mutton Stalls', 'Rahmatullah - Mutton Stall', '80128 85541', 'Periya Pallivaasal Street,\r\nMannargudi.', 'Mutton Stall', '', '03-May-2012', 'Mutton', '', '', '1336052829564725948'),
(173, 'General Services', 'Mason', 'Natarajan - Meshthri', '97501 96501', '', 'Meshthri', '', '03-May-2012', 'Meshthri', '', '', '1336052903318211756'),
(174, 'Business', 'Coir Merchants', 'Abdul Lathief', '98658 03251', 'Big Bazaar Street,\r\nOpp. AKR Hardwares,\r\nMannargudi.', '', '', '03-May-2012', 'coir, ropes', '', '', '1336052962889832317'),
(175, 'Travels', 'Drivers', 'Palani - Ambassador', '94431 75620', '', 'Ambassador Car Driver', '', '03-May-2012', 'ambassador', '', '', '1336053009616756531'),
(176, 'Business', 'Decoration Centres', 'Oli Mohammed', '99421 61667', '', 'Pandhal Contractor', '', '03-May-2012', 'Contractor', '', '', '1336053188854680591'),
(177, 'General Services', 'Painters', 'Perumal ', '98296 87527', 'Aadhichapuram', 'Painter', '', '03-May-2012', '', '', '', '1336053288934478399'),
(178, 'General Services', 'Others', 'Govindarajan', '98424 97793', 'RK Palayam Road,\r\nNear Shanthi Theatre,\r\nMannargudi.', 'RTO Services', '', '03-May-2012', 'RTO', '', '', '13360533611657844'),
(179, 'Business', 'Welding Workshops', 'R.T Engineering', '220949 / 99407 66946', 'Taluk Office Road,\r\nMannargudi', 'Grill Welding Works', '', '03-May-2012', 'Grill', '', '', '13360535631114456742'),
(180, 'General Services', 'Painters', 'Sekar', '318321 / 9655857393', 'Serumankulam.\r\n', '', '', '03-May-2012', '', '', '', '13360536591044793783'),
(181, 'Building Construction', 'Civil Engineers', 'Er. Moorthy', '94431 50510', 'Moovanallur.', 'Civil Engineer', '', '03-May-2012', 'Civil, Engineer', '', '', '1336053977657408955'),
(182, 'General Services', 'LIC and Insurance Agents', 'Ravindran', '9442158785', '', 'National Insurance Company', '', '03-May-2012', 'Insurance', '', '', '1336054140246551968'),
(183, 'Business', 'Coir Merchants', 'Ayesha Beevi and Sons (Noor Coir Traders)', '250943 / 9942563641', 'Big Bazaar Street,\r\nOpp. Selvam Metals,\r\nMannargudi.', 'Proprietor : M.A. Sultan Jalaludeen ', '', '03-May-2012', 'Coir, Ropes', '', '', '1336054267491069331'),
(184, 'Travels', 'Drivers', 'Abdul Rehman - Tata Ace', '9788982269', 'Near Shakthi Maravaadi,\r\nThamaraikulam Vadakarai,\r\nMannargudi', 'TATA ACE', '', '03-May-2012', 'TATA ACE', '', '', '1336054373762336668'),
(185, 'Travels', 'Drivers', 'Ganapathi - Auto', '9842880542', 'Opp. CAK Poly Clinic,\r\nMGR Nagar,\r\nMannargudi.', '', '', '03-May-2012', 'Auto', '', '', '1336054437313841338'),
(186, 'General Services', 'Electricians - Plumbers', 'Senthil ', '9865672301', '', 'Electrician', '', '03-May-2012', 'Electrical, Plumber', '', '', '1336054663959495276'),
(187, 'General Services', 'Electricians - Plumbers', 'Nagarajan', '9578157345', '', 'Electrician', '', '03-May-2012', 'Electrician, Electrical, Plumber', '', '', '1336054715190113291'),
(188, 'Business', 'Broilers, Fish, Beef and Mutton Stalls', 'Deen Broilers', '9344889424', 'Periya Pallaivaasal Street,\r\nMannargudi', '', '', '03-May-2012', 'Chicken', '', '', '1336054772387158871'),
(189, 'Business', 'Broilers, Fish, Beef and Mutton Stalls', 'Siraj - Beef Stall', '9842699308', 'Near Keelapaalam,\r\nMannargudi.', '', '', '03-May-2012', 'Beef', '', '', '133605482448677516'),
(190, 'Business', 'Marriage Halls', 'AKS Kalyana Mandabam', '94870 29615', 'Gopala Samuthiram Vadakku Veedhi,\r\nMannargudi.', '', '', '03-May-2012', 'Marriage, Mandabam', '', '', '1336054896572298828'),
(191, 'Automobiles', 'Motor Mechanics', 'Wahab Auto Works ', '251563 / 98424 55808', 'No.4, East West Sathara Street,\r\nNear National Higher Secondary School,\r\nMannargudi.', 'Prop : S. Abdul Wahab', '', '03-May-2012', 'Bike, Mechanic', '', '', '1336055012513674943'),
(192, 'Business', 'Textile and Readymades', 'Veera Silks and Readymades', '252888  / 93612 11999', '38,Mela Raja Veedhi,\r\nMannargudi.', 'Prop: G.Veera Udhayanan.', '', '03-May-2012', 'Readymades, Silks', '', '', '1336056967983494900'),
(193, 'Building Construction', 'Building Contractors', 'Ammuraj Construction', '94431 75958', '49 A, RK Palayam Middle Street,\r\nMannargudi', 'Proprietor : Ramaiya Rajendran ', '', '03-May-2012', 'Construction, Building', '', '', '1336057049243161126'),
(194, 'Automobiles', 'Auto Spare Parts', 'Sree Guru Auto Spares', '220136', '58-B, Rukmani Palayam Road,\r\nNear Dr. Thangamani Building,\r\nMannargudi.', 'Two Wheeler, Four Wheeler and Trucks Spares', '', '03-May-2012', 'Spares', '', '', '1336057143241654085'),
(195, 'Business', 'Tailors', 'Galaxy Tailors (Gents)', '98425 21818', '244-1, Big Bazaar Street,\r\nMannargudi', 'Proprietor: M. Sandanam and Sons \r\nGents Specialist', '', '03-May-2012', 'Gents Tailor', '', '', '1336057253541103085'),
(196, 'Business', 'Jewellery Shops', 'S Madhava Jewellery', '252222 / 94427 14236', 'Big Bazaar Street,\r\nNear Murugavel Textiles\r\nMannargudi.', 'Prop : A. Sethu Madhavan', '', '03-May-2012', 'Gold', '', '', '13360576141171121474'),
(197, 'General Services', 'Others', 'SBI Business Service', '252222 / 94427 14236', 'Big Bazaar Street,\r\nMannargudi.', 'Contact : A. Sethu Madhavan', '', '03-May-2012', 'SBI', '', '', '133605775496601412'),
(198, 'Hotels, Lodges and Restaurants', 'Lodges', 'Poorna Lodge A/C', '251695 / 251675 / 253676 / 253577 / 320044', '50, Big Bazaar Street,\r\nMannargudi', 'A/C Lodge', '', '03-May-2012', 'Hotel, Boarding, Lodge', '', '', '1336057881252052667'),
(199, 'Building Construction', 'Constuction Suppliers', 'Dharani Readymix', '98424 21160 / 98424 24540 / 98423 43160 ', '27, Theppakulam Melkarai,\r\nMannargudi.', 'Plant Tel No: 227329', '', '03-May-2012', 'Readymix', '', '', '13360580131226542898'),
(200, 'Building Construction', 'Building Contractors', 'Dharani Hi-Tech Projects Pvt Ltd', '98424 22160 / 98424 22085 / 227133', '54, Gopala Samudram Vadakku Veedi,\r\nMannargudi.', 'Plant : Aadhanoor Mandabam', '', '03-May-2012', 'Dharani', '', '', '1336058168955124857'),
(201, 'Education', 'ITI', 'Sree Vinayaga Educational Trust - Govt. ITI', '312341 / 250616 / 98656 12347', '58, Pearl Prami Mall Complex,\r\nRK Palayam Road.\r\nMannargudi.', 'Government ITI\r\n\r\nLandmark : Thangamani Building Bus Stop', '', '03-May-2012', 'Vinayaga, Trust', '', '', '1336058469880488664'),
(202, 'Education', 'Paramedical Colleges', 'Vishanth Paramedical College (Girls)', '321116 / 98656 12347', '40/12, Balakrishana Nagar,\r\nLEO Cable Upstairs,\r\nMannargudi.', 'Sree Vinayaga Educational Trust', '', '03-May-2012', 'Vinayaga, Trust', '', '', '1336058674130359125'),
(203, 'Business', 'Tailors', 'Yours Tailors', '81227 15256', 'Swathi Complex,\r\nRukmani Palayam Road,\r\nMannargudi.', 'Prop: P. Nagarajan', '', '03-May-2012', 'Gents Tailor', '', '', '1336059045288673757'),
(204, 'General Services', 'Agencies', 'Surya Agencies (Cottage Indutries)', '9976206242', '157/106, Natarajan Mela Street,\r\nMannargudi.', 'Prop: Navaneedha Krishan.K\r\n\r\nBricks, Jalli and Sand (Buying and Selling)\r\nWholesale and Retail', '', '03-May-2012', 'Bricks, Sand, Wholesale, Retail', '', '', '133605919087860576'),
(205, 'Travels', 'Travel Agencies', 'Lena Travels', '9976206242', '157/106, Natarajan Mela Street,\r\nMannargudi.', 'Rental: Cars, Vans', '', '03-May-2012', 'car, van', '', '', '1336059271414511661'),
(206, 'Business', 'Photo Studios', 'Sunrise Digital Studio and Video', '92451 32713 / 90033 10523', 'Rukmanipalayam Middle Street,\r\nNear Shanthi Theatre,\r\nMannargudi ', '', '', '03-May-2012', 'studio, video', '', '', '1336066015860407346'),
(207, 'Automobiles', 'Motor Showrooms', 'Sree Saravana Motors - Yamaha Showroom', '96885 59979', '1, Malar Complex, \r\nRukmanipalayam,\r\nMannargudi.', 'Sales Manager: S. Raj Kumar.\r\nsales-service-stores', '', '03-May-2012', 'Yamaha,motors', 'Raj1981yam@gmail.com', '', '1336066410146898898'),
(208, 'Automobiles', 'Auto Spare Parts', 'City Spares', '94423 98887', '4/7, R.K.Palayam Middle Street,\r\nmannargudi.', 'All two wheeler spares.\r\nProp: A.Sheik Ibrahim', '', '03-May-2012', 'spares', '', '', '1336067396678658230'),
(209, 'Business', 'Steel Company', 'Eswari Steel Company', '255970 / 94422 67970 / 94444 51722', '34,Rukmanipalayam Road,\r\nNear Shanthi Theatre,\r\nMannargudi.', 'Prop: P.Ganapathi.B.Com.,', '', '03-May-2012', 'steels,cements', 'eswari1970@gmail.com', '', '1336068139191733360'),
(210, 'Business', 'Steel Company', 'P.S.B.Steels', '222661 / 98426 16671', '188, Nataraja Pillai Street,\r\nMannargudi.', 'Stockist: MS flats,MS angles,MS channels,CP-GP-GC-HR sheets,MS round rods,TOR,MS wires,MS weldmesh and MS pipes.', '', '03-May-2012', 'angles,channels,weldmesh,ms wires.rods', '', '', '13360703311035374778'),
(211, 'Business', 'Tiles and Granites', 'Sri Lakshana Ceramics', '324144 / 250115 / 94422 50848 / 94875 70848', '198, Swathi Complex,\r\nNataraja Pillai Street,\r\nNear Travelers Bungalow,\r\nMannargudi.\r\n', 'Dealers : Johnson Ceramic Tiles\r\nProducts : Parryware Sanitary Wares, Marbonite, Endura Tiles', '', '04-May-2012', 'Tiles, Ceramic', '', '', '1336108539505348543'),
(212, 'Hospitals and Medicals', 'Blood Testing,E.C.G. - X-Rays Centers', 'Turning Point Nutrition Centre', '98948 25124', '60, Umma Salma Building, 1st Floor,\r\nOpp. Sree Balaji Petrol Bunk,\r\nNear BSNL Building,\r\nRK Palayam Road,\r\nMannargudi.', 'Free Body Fat Check-up\r\nTiming : Between 7.00 am to 10.30 am\r\n\r\nProp : S.S. Kajamaideen', '', '04-May-2012', 'Nutrition', '', '', '13361087751068491999'),
(213, 'Travels', 'Drivers', 'S. Senthil Kumar - Auto', '94431 08313 / 94425 15390', '', 'Dhill Autos', '', '04-May-2012', 'Auto, Drivers', '', '', '1336108855834523921'),
(214, 'Business', 'Fancy Stores', 'Priya Fancy Stores', '75982 20390', 'Near Arulmigu Sree Muthu Maariyamman Kovil,\r\nNo.10, Mannappan Street,\r\nMannargudi.', '', '', '04-May-2012', 'Fancy', '', '', '1336108927457688378'),
(215, 'Business', 'Battery Sellers', 'Sree Sastha Sales and Service', '98436 50867 / 95970 93335', 'No.1, SMR Building,\r\nThanjavur Main Road,\r\nKaalavaakarai,\r\nMannargudi.', 'All UPS and Batteries Sales and Service', '', '04-May-2012', 'UPS, Invertors, Sales, Services, Battery', 'ssuresh4u@gmail.com', '', '1336109048820508442'),
(216, 'Business', 'Printing Press', 'Nice Digital and Offset', '300017 / 9894958495 / 9940453815', 'Opp. Co-operative Milk Society,\r\nNear Sub Registrar Office,\r\nMannargudi.\r\n', 'Creative Works: Flex Board, Digital Photos, Invitation, Digital Videos, Lamination, DTP Works, Print Outs, Spiral Binding, Cell Recharge Cards, Multi Color Lithos, Courier Service, Rubber Stamp, Visiting Cards, Birthday Ads, Cell Memory Card, CD, VCD, DVD and MP3 Writing.', '', '04-May-2012', 'flex, dtp, offset,printing,spiral, videos, courier', 'director.nd@gmail.com', '', '1336109365466504567'),
(217, 'Travels', 'Drivers', 'Samsu Nina Mohammed - Auto', '9894958495', '', '', '', '04-May-2012', 'Auto', '', '', '13361094231122820818'),
(218, 'Business', 'Courier Service', 'Courier DTDC', '9750875518', 'Opp. Co-operative Milk Society,\r\nNear Sub Registrar Office,\r\nMannargudi.\r\n', 'Prop: Samsu Naina Mohammed', '', '04-May-2012', 'Courier', '', '', '1336109527903169627'),
(219, 'Business', 'Tiles and Granites', 'Gowri Impex GSE Granite Exporters Show Room', '97885 45370', 'No.127, Nataraja Pillai Street,\r\nNear Murugan Temple,\r\nMannargudi.', 'Diamond Polish-Water Cutting Export Quality.\r\n\r\nProp : G.S. Elangovan', '', '04-May-2012', 'Tiles, Granites', '', '', '1336109699828684138'),
(220, 'Hospitals and Medicals', 'Health Services', 'TIENS - International Independent Distributor', '9715394395 / 9042976126', 'Nemmeli Road,\r\nSerankulam,\r\nMannargudi.', 'Distributor : U.Senthil', '', '04-May-2012', 'medical', '', '', '1336110039822882031'),
(221, 'Building Construction', 'Constuction Suppliers', 'G.S. Senthil Earth Movers', '9787382978 / 9626538918', 'No.1, SMR Building,\r\nVaduvoor Road,\r\nKaalavaaikarai,\r\nMannargudi.', 'JCB with Hitachi Tipper available for hire.\r\nContact for Semman (Red Sand) needs.', '', '04-May-2012', 'sand', '', '', '1336110184740974365'),
(222, 'Travels', 'Travel Agencies', 'G.S. Senthil Earth Movers - Tata Ace', '9787382978 / 9626538918', 'No.1, SMR Building,\r\nVaduvoor Road,\r\nKaalavaaikarai,\r\nMannargudi.', 'Tata Ace, Tractor with tipper facility available for hire', '', '04-May-2012', 'tata ace, tractor', '', '', '133611025967854610'),
(224, 'Business', 'Battery Sellers', 'Selvam Battery Works', '98658 80399', '49-B, RK Palayam Middle Street,\r\nMannargudi.', 'Inverter, Battery sales and service\r\n\r\nProp: A. Selvam', '', '04-May-2012', 'Interverter, Battery, Sales, Service', '', '', '1336110493734004302'),
(226, 'Business', 'Printing Press', 'Amirdham Computer Press', '223280 / 94424 67864', '47-C, Kopala Samudram Keela Veedhi,\r\nAmirdham Complex,\r\nNear Shanthi Theatre,\r\nMannargudi.', 'All Printing Jobs Done Here\r\n\r\nProp: R. Veera Pandian', '', '04-May-2012', 'offset,printing, muilti color', 'amirthamoffset@yahoo.com', '', '13361107191133784540'),
(227, 'Business', 'Mobile Shops', 'Airvoice Communications', '94434 02410', 'Amirdham Complex,\r\nMannargudi.', 'Cell Sales and Service, Recharge Cards\r\n\r\nProp: V. Kathiravan', '', '04-May-2012', 'mobile, sales, service, recharge', 'airvoice_kathir@yahoo.in', '', '1336110801302124096'),
(228, 'Automobiles', 'Motor Mechanics', 'Sri Veeranar Auto Works', '94428 46493 ', '33-B, Azad Street,\r\nMannargudi.', 'Dieserl, Pertrol, Electrical, AC and Genset Works\r\n\r\nProp: D. Mariyappan', '', '04-May-2012', 'Electrical, AC', '', '', '13361109741091399018'),
(229, 'Travels', 'Driving Schools', 'Annai Driving School', '9976277111 / 8940778989', '119, Nataraja Mela Street,\r\nMannargudi.', 'Driving School', '', '04-May-2012', 'Driving', '', '', '1336112530455314789'),
(230, 'Banks', 'Private Bankers', 'Sri Thilaga Bankers', '98425 24391 ', '100/159A, Nataraja Pillai Street,\r\nThanjavur Main road,\r\nMannargudi.', 'Prop: K. Bala Subramaniyan', '', '04-May-2012', 'Bankers', '', '', '1336112631153605229'),
(231, 'Business', 'Mobile Shops', 'Sri Thilaga Cell Sales and Service', '98425 24391', '100/159A, Nataraja Pillai Street,\r\nThanjavur Main Road,\r\nMannargudi.', 'Prop: K. Bala Subramaniyan', '', '04-May-2012', 'mobile, sales, service, recharge', '', '', '1336112697469707029'),
(232, 'Business', 'Tailors', 'Gnanadaas Tailors - Ladies and gents Specialist', '9788835772', '101, Nataraja Pillai Street,\r\nMannargudi', '', '', '04-May-2012', '', '', '', '1336112793597127325'),
(234, 'Entertainments', 'Music Band - Orchestra', 'Nambargal Music Band - Orchestra', '98425 40250 / 321979', 'Anthoniyar Kovil Street,\r\nMannargudi.', 'Prop : Thanga. Murugesan BA', '', '04-May-2012', 'Music, Bands, Orchestra', '', '', '1336116952454975705'),
(235, 'Entertainments', 'Music Band - Orchestra', 'S.A.Dass Music Band - Orchestra', '93600 76470 / 98432 20603 / 97899 78841', 'Anthoniyar Koil Street,\r\nMannargudi.', '', '', '04-May-2012', 'Music, Bands, Orchestra', '', '', '1336116980998640659'),
(237, 'Automobiles', 'Tyre Showrooms', 'Sree Jagatha Transports', '97509 50639', '40B, Balakrishna Nagar,\r\nMannargudi.', 'Dealer : Birla Tyres.\r\n\r\nProp: P. Manivannan. B.Sc., Ex.MC', '', '05-May-2012', 'birla, tyre, Jagatha', '', '', '1336193376759850051'),
(238, 'Travels', 'Travel Agencies', 'Sree Jagatha Transports', '', '40 B, Balakrishna Nagar,\r\nMannargudi.', 'Government Transport Contractor\r\nDealer : Birla Tyres\r\n\r\nProp: P. Manivannan. B.Sc.,Ex MC', '', '05-May-2012', 'Jagatha, Birla, Tyre', '', '', '13361935001186568642'),
(239, 'Business', 'Courier Service', 'French Courier', '98655 41313 / 91718 48383', '6/9, P.R.R. Complex,\r\nOpp. Chinna Convent,\r\nBalakrishna Nagar,\r\nMannargudi.', 'French Express Network PVT Ltd.\r\n(International / Express Gargo / Courier)', '', '05-May-2012', 'courier', '', '', '13361937921192822861'),
(240, 'Business', 'Jewellery Shops', 'Sri Aiswarya Jewellery', '250419 ', '189, Big Bazaar Street,\r\nMannargudi', '', '', '05-May-2012', 'Jewellery, Gold, Silver', '', '', '1336194244525881973'),
(241, 'Business', 'Mobile Shops', 'Sabarish Cell Sales and Service', '89034 39687', '49, Modern Nagar,\r\nMannargudi.', 'Prop : T.S. Bharathi Mohan', '', '05-May-2012', 'Mobile, Sales, Service, mobile recharge, Sabharish', '', '', '13361959021208157001'),
(242, 'Travels', 'Tourist Buses, Vans and Cars', 'Sabharish  Tourist Bus', '89034 39687', '49, Modern Nagar,\r\nMannargudi.', 'Tourist Bus for marriage and tour\r\n\r\nProp: Bharathi Mohan', '', '05-May-2012', 'Sabharish', '', '', '1336196019665245567'),
(243, 'Entertainments', 'Music Band - Orchestra', 'V.S.M Mohammed Imamdeen', '94863 37118 / 97860 59351 / 04373 272775', '', 'Horse Dance for Marriage Functions', '', '05-May-2012', 'horse, dance, marriage', '', '', '1336196218693690962');
INSERT INTO `sal_add_company` (`id`, `category`, `sub_category`, `title`, `phone`, `address`, `otherinfo`, `pic`, `date`, `tags`, `email`, `website`, `rand_id`) VALUES
(244, 'Travels', 'Travel Agencies', 'Kumara Agencies - Tata Ace', '98432 06334', 'Madhukkur Road,\r\nNear Gopiraalayam,\r\nMannargudi.\r\n', 'Tata Ace for rental\r\n\r\nProp : N.S. Kumar', '', '05-May-2012', 'Tata Ace, Rental', '', '', '1336196482276165319'),
(245, 'Business', 'Battery Sellers', 'Sri Balaji Battery &amp; UPS', '99447 80136 / 91717 75809', '42, Gopala Samuthram East Street,\r\nNear Indian Bank,\r\nMannargudi.', 'Power Zone Battery\r\nAuthorized Dealer\r\n\r\nContact : R.Satheesh B.B.A.,', '', '05-May-2012', 'dealer, battery, UPS', '', '', '1336196606703486727'),
(246, 'Business', 'Battery Sellers', 'Sri Veera Battery Point Sales and Service', '94435 32230 / 91502 68585', 'Opp. Fire Service Station,\r\nMannargudi.', 'Contact : R. Ilayaraja', '', '05-May-2012', 'sales, service, battery, ups, amaron, speed', '', '', '1336196713934892835'),
(247, 'Business', 'Battery Sellers', 'Sami Battery Works', '253658 / 94437 43190', 'No.37, New Street,\r\nMannargudi', 'Exide Battery Dealer.\r\n\r\nProp: C.Sami Nathan', '', '05-May-2012', 'Battery, Inverter, UPS, exide, dealer,Sami Battery', '', '', '13361969071158801416'),
(248, 'Building Construction', 'Building Contractors', 'PSP Constructions', '94434 75690 / 9965 75690', '101/8, Nataraja Pillai Street,\r\nMannargudi.', 'Plan & Estimate, Total Contracts & Labour Contracts, Supervising, Water Proof Chemicals, 3D Elevations, Joint Ventures etc.,\r\n\r\nProp : P.Ponmurali', '', '05-May-2012', 'building, contractor, construciton, labour', 'pspconstructions@yahoo.com, pspconstructions@gmail.com', '', '13361971281095957817'),
(249, 'Business', 'Flex Boards and Stickers', 'G7 Stickers & Cars', '98436 45656', '11, Mahamaariamman Kovil St,\r\nOpp. Sakthi Graphics & Flex,\r\nMannargudi.', 'Contact : P. Vijayaragavan.', '', '05-May-2012', 'Stickers', '', '', '1336197422753520480'),
(250, 'Business', 'Flex Boards and Stickers', 'Sakthi Graphics and Flex', '300040 / 98426 70507 / 98425 77464', 'No.1 , Kandiyar Complex,\r\nOpp. Mahamaariyamma Kovil,\r\nKamala Street,\r\nMannargudi.', '', '', '05-May-2012', 'Flex, Graphics', '', '', '1336197531941523815'),
(251, 'Business', 'Agencies', 'Sri Annamalaiyar Agencies', '98426 59584', '40/A, Balakrishna Nagar,\r\nMannargudi.', 'Contact : P. Amirtharaj, D.Pharm.,', '', '05-May-2012', '', '', '', '1336197640427246155'),
(252, 'Business', 'Drinking Water Suppliers', 'Chella Agencies - Drinking Water', '99767 14942 / 99446 02888 / 97880 44760', '29, Kanagambaal Kovil Street,\r\nMannargudi.', '300ml, 500ml, 1lt, 20lts available here.\r\n\r\nDoor Delivery Service.\r\n\r\nProp : A. Amirthalingam and T. Ashok', '', '05-May-2012', 'mineral, drinking, water, allain', '', '', '133619783062316235'),
(253, 'Automobiles', 'Service Stations', 'Jawahar Transport', '254533', '45, Mahamariamman Kovil Street,\r\nMannargudi.', 'Prop : Rafi Mohammed Yaasin. B.Com.,\r\nEx. Panchayat Vice President', '', '05-May-2012', 'Jawahar, Bus', '', '', '1336198106668259649'),
(254, 'Building Construction', 'Building Contractors', 'Saimass Building Constrution and Contractors', '98410 25435 / 94438 65435', '', 'Services : We under take quality Building construction residential, Commercial, Renovation, Interior Design & Water Proofing at lowest cost.\r\n\r\nBuying & selling for Land all over Tamilnadu.\r\n\r\nContact : B.Mahendra Boopathi MD', '', '05-May-2012', 'building, contractor, construciton, labour, saimass', 'mahen_boopathy@yahoo.com', 'http://www.saimass.com', '13361982781036203650'),
(256, 'Business', 'Department Stores', 'Dhanam Store', '', 'Thanjavur Main Road,\r\nNear Santhosh Mahal,\r\nMannargudi.', '', '', '05-May-2012', 'Department', '', '', '1336200376642941364'),
(257, 'Business', 'Department Stores', 'Sakthi Department Stores', '228033', 'Thanjavur Main Road,\r\nMannargudi.', '', '', '05-May-2012', 'Department', '', '', '1336200454229635435'),
(258, 'General Services', 'Laundry', 'Kirubai Laundry', '88834 42287', 'Thajavur main road,\r\nMannargudi.', '', '', '05-May-2012', 'Laundry', '', '', '133620054338128231'),
(259, 'Building Construction', 'Cement Dealers', 'Raasi Traders', '', 'Thajavur Main Road,\r\nMannargudi', 'Dealer : Dalmia Cements', '', '05-May-2012', 'Cements, Dealer', '', '', '1336200611386744435'),
(260, 'Business', 'Steel Company', 'Sree Amman Steels and Enterprises', '93452 78901 / 89037 18555', 'SMR Building,\r\nThanjavur Main Road,\r\nMannargudi.', 'Stainless Steel, Hand Rails, SS Gates, Balcony SS Letters,', '', '05-May-2012', 'Steels', '', '', '1336200715180807315'),
(261, 'Agriculture', 'Agri. Equipments', 'Sree Maariamman Agencies', '93806 99812 / 96985 69803', 'SMR Complex,\r\nThanjavur Main Road,\r\nMannargudi', 'Rotavator Sales and Service', '', '05-May-2012', 'Rotavator', '', '', '1336200941268667791'),
(262, 'Business', 'Metals and Furnitures', 'Kamachiamman Furniture', '99421 14479 / 90959 40153', 'Thanjavur Main Road,\r\nMannargudi', '', '', '05-May-2012', 'Metal, Furniture', '', '', '1336201048440884874'),
(263, 'Business', 'Rice Suppliers ( Arisi Mandy )', 'V.A Arisi Mandy', '94433 69436 / 97511 77593', 'Thanjavur Main Road,\r\nMannargudi.', '', '', '05-May-2012', 'rice', '', '', '1336201190593698807'),
(264, 'Business', 'Department Stores', 'RK Department Store', '99425 57365 ', 'Thanjavur Main Road,\r\nMannargudi.', '', '', '05-May-2012', 'Department', '', '', '1336201233634012147'),
(265, 'Automobiles', 'Motor Showrooms', 'Annamalai Automobiles', '', 'Thanjavur Main Road,\r\nMannargudi.', 'Dealer : John Deere', '', '05-May-2012', '', '', '', '1336201422594678384'),
(266, 'Automobiles', 'Service Stations', 'Rishi Autos Water Service Centre', '99405 55235', 'Thanjavur Main Road,\r\nMannargudi.', '', '', '05-May-2012', 'Water Service', '', '', '1336201483433500374'),
(267, 'Business', 'Metals and Furnitures', 'Suruthi Metals', '99422 22981', 'Thanjavur Main Road,\r\nMannargudi.', '', '', '05-May-2012', 'Metal, Furniture', '', '', '1336201529248360417'),
(268, 'Entertainments', 'Sound Services', 'Suruthi Sound Services', '99422 22981', 'Thanjavur Main Road,\r\nMannargudi.', '', '', '05-May-2012', 'Sound', '', '', '1336201579556587928'),
(269, 'Business', 'Department Stores', 'Om Sakthi Department Stores', '', 'Thanjavur Main Road,\r\nMannargudi.', '', '', '05-May-2012', 'Department', '', '', '1336201598344622645'),
(270, 'Automobiles', 'Motor Showrooms', 'Mercury Motors', '', 'Kaalavakkarai,\r\nMannargudi.', 'Dealer : Honda \r\nSales, Service and Spares', '', '05-May-2012', 'motors, service', '', '', '1336201671622973074'),
(271, 'General Services', 'Engineering Works', 'Sri Sakthi Engineering Works', '96554 56547', '3/69, Kaalvaikarai,\r\nMannargudi.', '', '', '05-May-2012', 'Grill, Welding', '', '', '1336201764753369776'),
(272, 'Automobiles', 'Motor Showrooms', 'Sivashakthi Motors', '97863 31557', '62, Kaalvaikarai,\r\nMannargudi.', '', '', '05-May-2012', 'motors, service', '', '', '13362018391157181347'),
(273, 'Business', 'Broilers, Fish, Beef and Mutton Stalls', 'Kavi Broilers', '95785 70369', 'Kaalvaikarai,\r\nMannargudi.', '', '', '05-May-2012', 'chicken', '', '', '1336201876463264429'),
(274, 'Travels', 'Travel Agencies', 'C.B. Travels', '97508 85973', 'Kaalvaikarai,\r\nMannargudi.', '', '', '05-May-2012', '', '', '', '13362019141007004736'),
(275, 'Business', 'Tailors', 'Skylab Tailors', '2263559', 'Kaalvaikarai,\r\nMannargudi.', '', '', '05-May-2012', 'tailor', '', '', '13362019411168484153'),
(276, 'Automobiles', 'Service Stations', 'Sri Kamachiamman Water Service', '97873 93039', 'Kaalvaikarai,\r\nMannargudi.', '', '', '05-May-2012', 'Water Service', '', '', '1336201986338330750'),
(277, 'Business', 'Rice Suppliers ( Arisi Mandy )', 'Sri Swathi Arisi Mandy', '', 'Kaalvaikarai,\r\nMannargudi.', '', '', '05-May-2012', 'rice', '', '', '133620206016351492'),
(278, 'Business', 'Tailors', 'Durairaj Tailor', '99659 56699', 'Kaalvaikarai,\r\nMannargudi.', '', '', '05-May-2012', 'tailor', '', '', '1336202087892168230'),
(279, 'Travels', 'Travel Agencies', 'VKMs Cabs', '98658 49373', 'Kaalvaikarai,\r\nMannargudi.', '', '', '05-May-2012', 'travels', '', '', '133620213267440174'),
(280, 'Business', 'Rice Mills', 'Muthu Rice Mill', '', 'Kaalvaikarai,\r\nMannargudi.', '', '', '05-May-2012', 'Rice Mill', '', '', '1336202180477242232'),
(281, 'General Services', 'Rewinding Works', 'RK Rewinding Works', '', 'Kaalvaikarai,\r\nMannargudi.', '', '', '05-May-2012', 'Rewinding', '', '', '1336202281271606521'),
(282, 'General Services', 'Rewinding Works', 'Maheswari Rewinding Works', '94435 66112', '6, Rukmani Palayam Middle Street,\r\nMannargudi.', 'Prop : R. Murugan', '', '05-May-2012', 'Rewinding', '', '', '1336202337789877838'),
(283, 'Business', 'Mobile Shops', 'S.G Mobiles', '98424 95188', 'Kaalvaikarai,\r\nMannargudi.', '', '', '05-May-2012', 'Mobile, Sales, Service, mobile recharge', '', '', '13362023731074633190'),
(284, 'Hospitals and Medicals', 'Medical Stores', 'Kalai Medicals', '227732', 'Kaalvaikarai,\r\nMannargudi.', '', '', '05-May-2012', '', '', '', '1336202443941335435'),
(285, 'Business', 'Broilers, Fish, Beef and Mutton Stalls', 'R.K Broilers', '', 'Kaalvaikarai,\r\nMannargudi.', '', '', '05-May-2012', 'chicken', '', '', '1336202465388176123'),
(286, 'Business', 'Department Stores', 'Saitu Depatment Stores', '', 'Vadakku Veedi,\r\nMannargudi', '', '', '05-May-2012', 'Department', '', '', '13362025521218480230'),
(287, 'Business', 'Maligai Stores', 'N.K Maligai', '227639', 'Vadakku Veedhi,\r\nMannargudi.', '', '', '05-May-2012', 'Maligai', '', '', '133620259190234165'),
(288, 'Business', 'Rice Suppliers ( Arisi Mandy )', 'Sri Lakhsmi Rice Store', '', 'Vilal Kaara Street,\r\nMannargudi', '', '', '05-May-2012', 'Rice', '', '', '1336202627248586473'),
(289, 'Business', 'Maligai Stores', 'Ramya Maligai', '', 'Therku Veedhi, (South Street) \r\nMannargudi.', '', '', '05-May-2012', 'Maligai', '', '', '1336202801927998124'),
(290, 'General Services', 'Engineering Works', 'Santhosh Auto Engineering Works', '', 'Therku Veedhi (South Street),\r\nMannargudi.', '', '', '05-May-2012', 'Engineering', '', '', '1336202856338067018'),
(291, 'Automobiles', 'Motor Mechanics', 'A.M Raja Auto Works', '97884 38620', 'Kaalavaikkarai,\r\nMannargudi.', '', '', '05-May-2012', 'Auto Works', '', '', '13362029091033340273'),
(292, 'Business', 'Agencies', 'Thamani Agency - Amirtha Ice Cream', '99425 75288', 'Kaalavaaikkarai,\r\nMannargudi.', '', '', '05-May-2012', 'Ice Cream', '', '', '1336203200416847574'),
(293, 'General Services', 'Rewinding Works', 'Kathiravan Rewinding Works ', '', 'Kaalavaaikkarai,\r\nMannargudi.', '', '', '05-May-2012', 'Rewinding', '', '', '1336203247645164249'),
(294, 'Building Construction', 'Cement Dealers', 'IRM Traders', '', '127/4, Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', 'Cements, Dealer', '', '', '1336203333378907823'),
(295, 'Building Construction', 'Cement Dealers', 'Yelumalaiyaan Agencies', '', 'Nataraja Pillai Street,\r\nMannargudi.', 'Dealer : Ram Co Cements', '', '05-May-2012', 'Cements, Dealer', '', '', '1336203387283888903'),
(296, 'General Services', 'Engineering Works', 'Rathna Engineering Works', '', 'Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', 'Engineering', '', '', '13362034101070790236'),
(297, 'Business', 'Book Stores', 'Abirami Paper Stores', '97869 63700', 'Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', 'Paper', '', '', '1336203487323524075'),
(298, 'General Services', 'Laundry', 'Sunlight Power Laundry', '94881 11661 / 97869 63936', '1/9, Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', 'Laundry', '', '', '1336203559727260294'),
(299, 'Business', 'Maligai Stores', 'Murugan Maligai Store', '', 'Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', 'Maligai', '', '', '13362035851174173232'),
(300, 'Banks', 'ATM Centres', 'KVB ATM Centre', '', 'Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', 'ATM', '', '', '1336203622530591475'),
(301, 'Agriculture', 'Agri. Equipments', 'Selvamani Agencies - Kavi Agro Power Tillers', '', 'Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', '', '', '', '13362037691125797224'),
(302, 'Agriculture', 'Agri. Equipments', 'Sivam Traders - Ganga Power Tiller', '', 'Kaalavaaikari,\r\nMannargudi.', '', '', '05-May-2012', '', '', '', '1336203935102930983'),
(303, 'Agriculture', 'Agri. Equipments', 'Indian Agro Centre', '', '123, Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', '', '', '', '13362039721070978616'),
(304, 'Automobiles', 'Motor Mechanics', 'Kulandhai Vel Two Wheeler Works', '', 'Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', 'two wheeler', '', '', '1336204008362594106'),
(305, 'Business', 'Rice Suppliers ( Arisi Mandy )', 'R.K Arisi Mandy', '', 'Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', 'rice', '', '', '13362040311097954646'),
(306, 'Automobiles', 'Motor Mechanics', 'S. Velu Auto Works', '97518 00460', 'Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', 'Auto Works', '', '', '133620406131497251'),
(307, 'Automobiles', 'Motor Mechanics', 'Sri Sami Auto Works', '94420 40981', 'Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', 'Auto Works', '', '', '1336204093823522523'),
(308, 'General Services', 'Saloons', 'Subashree Saloon', '97871 67662', 'Nataraja Pillai Street,\r\nMannargudi. ', '', '', '05-May-2012', 'saloons', '', '', '1336204255450680639'),
(309, 'General Services', 'Saloons', 'Buvan Saloon', '94435 66112', 'Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', 'saloons', '', '', '13362044061121276101'),
(310, 'Business', 'Maligai Stores', 'Balu Maligai', '', '43/98, Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', 'Maligai', '', '', '1336204477917750247'),
(311, 'Business', 'Maligai Stores', 'Vaandaiyaar Maligai', '', 'Nataraja Pillai Street,\r\nMannargudi.', '', '', '05-May-2012', '', '', '', '1336204559187965758'),
(312, 'Agriculture', 'Pesticide Dealers', 'Thanjavur Trading & Investments (P) Ltd', '', '27 Easwari Mill Complex,\r\nMannargudi', 'Whole Saler', '', '05-May-2012', '', '', '', '133622423975389814'),
(313, 'Agriculture', 'Pesticide Dealers', 'Sri Ganesh Traders', '251289', '219.Gandhi Road, \r\nPandhaladi North, \r\nMannargudi.', 'Contact :K.Mahendran', '', '05-May-2012', '', '', '', '133622432250297585'),
(314, 'Agriculture', 'Fertilizer - Pesticide Dealers', 'Ekananthan Urakadai', '253897 / 9442399198 / 9486336909', '74 Melarajaveedhi,\r\nMannargudi', '', '', '05-May-2012', '', '', '', '1336224394772094757'),
(315, 'Agriculture', 'Seed Dealers', 'Murugappa Traders', '250773 / 9894029894', '10, Mekarahaveedhi, \r\nMannargudi', '', '', '05-May-2012', '', '', '', '1336224469596298452'),
(316, 'Agriculture', 'Fertilizer - Pesticide Dealers', 'M/s Guna Traders', '252602', '130, Keeala Raja Veethi,\r\nMannargudi.', 'Contact : V.Mohan ', '', '05-May-2012', '', '', '', '1336224627966276959'),
(317, 'Agriculture', 'Fertilizer - Pesticide Dealers', 'Balaji Agencies', '252339', '29, Keela Palam, \r\nMannargudi.', 'Contact : Rajendran ', '', '05-May-2012', '', '', '', '13362246631116604275'),
(318, 'Agriculture', 'Fertilizer - Pesticide Dealers', 'TANFED', '04367 - 252248', '10, Meenakshi Ammann Kovil,\r\nMannargudi', 'Whole Saler', '', '05-May-2012', '', '', '', '1336224713195727018'),
(319, 'Agriculture', 'Fertilizer - Pesticide Dealers', 'Bio minin Labaoritries', '', '1/3 Main Road, \r\nSundharakottai, \r\nMannargudi ', 'Contact : K.Indiragandhi', '', '05-May-2012', '', '', '', '133622475369964467'),
(320, 'Agriculture', 'Fertilizer - Pesticide Dealers', 'A.Natarajan', '', '13 East Main St, \r\nMannargudi', 'Whole Saler', '', '05-May-2012', '', '', '', '1336224780406562021'),
(321, 'Agriculture', 'Fertilizer - Pesticide Dealers', 'M/s Sathyanarayanan Agencies,', '', '15-D, Natesan Street,\r\nOPP to Bus Stand,\r\nMannargudi', 'Retailer', '', '05-May-2012', '', '', '', '1336224879245421687'),
(322, 'Agriculture', 'Fertilizer - Pesticide Dealers', 'Sri Murugan Traders', '04367 - 227710', '21 Mela Raja Veethi,\r\nMannargudi ', 'Contact : 	Senthilkumar', '', '05-May-2012', '', '', '', '1336224956253182947'),
(323, 'Agriculture', 'Fertilizer - Pesticide Dealers', 'V.A.Asokan', '9443251912', '28 Mela raja veethi,\r\nMannargudi', 'Retailer', '', '05-May-2012', '', '', '', '1336224992875214021'),
(324, 'Agriculture', 'Fertilizer - Pesticide Dealers', 'ARN Agecies', '2545954 / 9843754212', '44, Viboji Street, \r\nMannargudi.', 'Contact : A.Ranganathan', '', '05-May-2012', '', '', '', '1336225041254840692'),
(325, 'Agriculture', 'Fertilizer - Pesticide Dealers', 'Thangam Agencies', '', '4/2, Gobiralayam Road, \r\nMannargudi', 'Contact : Sivavalampuriselvi', '', '05-May-2012', '', '', '', '1336225112972116742'),
(326, 'Agriculture', 'Fertilizer - Pesticide Dealers', 'M/s. Sarumani Traders', '', '70/10 Thanjavur Main Rd, \r\nKalavakkarai, \r\nMannargudi', 'Contact : A.Sarangapani ', '', '05-May-2012', '', '', '', '13362251451093207467'),
(327, 'Agriculture', 'Fertilizer - Pesticide Dealers', 'Sarumani Agri Clinic', '', '71/10 Kalavakkarai, \r\nThanajvur Main Rd,\r\nMannargudi', 'Whole Saler\r\n\r\nContact : S. Karikalan', '', '05-May-2012', '', '', '', '133622518434586685'),
(328, 'Agriculture', 'Fertilizer - Pesticide Dealers', 'The Regional Officer, TCMF Retail Depot', '', '20/A, Balakrishna Nagar, \r\nMannargudi.', 'Retailer', '', '05-May-2012', '', '', '', '1336225235723530369'),
(329, 'Agriculture', 'Seed Dealers', 'Harish Agro Marketing', '', '70/1 Annavasal Street, \r\nMannargudi', '', '', '05-May-2012', '', '', '', '1336225342647500162'),
(330, 'Agriculture', 'Seed Dealers', 'Mahendra Seeds Centre', '', '78.West Main Street, \r\nMannargudi.', '', '', '05-May-2012', '', '', '', '1336225374187475970'),
(331, 'Agriculture', 'Seed Dealers', 'V.A.Asokan', '', '28.West Main Street, \r\nMannargudi.', '', '', '05-May-2012', '', '', '', '13362253961074746218'),
(332, 'Agriculture', 'Seed Dealers', 'Vikas Agri Centre', '', '21-A. Rukmanipalayam Middle Street, \r\nMannargudi.', '', '', '05-May-2012', '', '', '', '13362254251143994741'),
(333, 'Agriculture', 'Seed Dealers', 'Sriraj Agencies', '', '21/7.Meenatchi Complex, \r\nAnnavasal St. \r\nMannargudi.', '', '', '05-May-2012', '', '', '', '1336225452197497791'),
(334, 'Agriculture', 'Seed Dealers', 'Amutha Traders', '', '32 K.S.S.Street, \r\nMannargudi', '', '', '05-May-2012', '', '', '', '1336225472931049881'),
(335, 'Agriculture', 'Seed Dealers', 'A.R.N. Agencies', '', '51 Vinobaji Street, \r\nMannargudi', '', '', '05-May-2012', '', '', '', '13362254991217915090'),
(336, 'Agriculture', 'Seed Dealers', 'Sri.Sathiya Narayana Agencies', '', '15D Natesan Street, \r\nMannargudi', '', '', '05-May-2012', '', '', '', '13362255181207591861'),
(337, 'Agriculture', 'Seed Dealers', 'V.Muthuramakrishnan', '', '76E, Melarajaveedhi, \r\nMannargudi', '', '', '05-May-2012', '', '', '', '1336225536548035472'),
(338, 'Agriculture', 'Seed Dealers', 'TCMF Ltd', '', 'Balakrishna Nagar, \r\nMannargudi.', 'Co-Operative Society', '', '05-May-2012', '', '', '', '1336225560546151671'),
(339, 'Agriculture', 'Seed Dealers', 'Sri. Sabari Traders', '', '32 K.S.S. Street, \r\nMannargudi', '', '', '05-May-2012', '', '', '', '1336225617472570406'),
(340, 'Agriculture', 'Seed Dealers', 'C.Namachivayam', '', '23.B.West Main Street, \r\nMannargudi.', '', '', '05-May-2012', '', '', '', '1336225662203337574'),
(341, 'Business', 'Broilers, Fish, Beef and Mutton Stalls', 'R.P. Murugan - Fish', '251946 / 98439 09080 / 93677 88622', '90, Arisi kadai sandhu,\r\nMannargudi.', '', '', '05-May-2012', 'Fish', '', '', '13362259381181595408'),
(342, 'Hospitals and Medicals', 'Health Services', 'M.A. Pharma Health Care', '252383 / 90036 37990', '39, Mahamariamman Kovil Street,\r\nMannargudi.', 'Contact : A.Abdul Kadhar B.A (Marketing Manager)', '', '05-May-2012', '', '', '', '133622602394642259'),
(343, 'Business', 'Other Category', 'G. Ramsingh Flower Merchants', '97880 44561', 'Natesan Street,\r\nMannargudi.', '', '', '05-May-2012', 'Flower', '', '', '1336226080586465011'),
(344, 'General Services', 'Others', 'P.R.M Liner Works', '99449 21951', '181 Keela Raja Veedhi,\r\nOpp. ICICI Bank,\r\nMannargudi.', 'Liner Works for van, jeep, car and auto. \r\nSofa sets cushion works', '', '05-May-2012', 'sofa, liner', '', '', '13362262051109031395'),
(345, 'Banks', 'ATM Centres', 'Bank of Baroda', '', '189, Nataraja Pillai Street,\r\nMannargudi.', '', '', '07-May-2012', 'Bank of Baroda', '', '', '1336374398619958992'),
(346, 'Business', 'Maligai Stores', 'Anantha Maligai', '', 'Nataraja Pillai Street,\r\nMannargudi.', '', '', '07-May-2012', '', '', '', '1336374451401362730'),
(347, 'Entertainments', 'Music Band - Orchestra', 'Star Music School and Orchestra', '', 'Nataraja Pillai Street,\r\nMannargudi.', '', '', '07-May-2012', 'orchestra, music, school', '', '', '1336374532959344572'),
(348, 'Automobiles', 'Motor Mechanics', 'Saravana Auto Electrical Works', '9486116642', 'Rukmani Kulam,\r\nMannargudi.', '', '', '07-May-2012', 'auto', '', '', '13363746401073804317'),
(349, 'General Services', 'Saloons', 'New Style Hair Dressing', '', 'Rukmani Kulam,\r\nMannargudi.', '', '', '07-May-2012', 'hair', '', '', '133637468398221481'),
(350, 'General Services', 'Saloons', 'Vishnu Priya Hair Saloon', '9790354212', 'New Bypass Road,\r\nMannargudi.', '', '', '07-May-2012', 'hair', '', '', '1336374877917260458'),
(351, 'Business', 'Rice Suppliers ( Arisi Mandy )', 'New Arisi Kadai', '94434 83920', 'Madukkur Road,\r\nMannargugi.', '', '', '07-May-2012', 'rice', '', '', '1336374923580210792'),
(352, 'Business', 'Rice Mills', 'Karpagam Rice Mill', '', '24/3, Madukkur Road,\r\nMannargudi.', '', '', '07-May-2012', 'rice, mill', '', '', '1336374977799560575'),
(353, 'Business', 'Tailors', 'A.V.M. Tailors', '75020 50994', '23 D, Main Road,\r\nGopiralayam,\r\nMannargudi.', '', '', '07-May-2012', 'ladies', '', '', '1336375061422612005'),
(354, 'General Services', 'Saloons', 'Raja Saloon', '', '23 D, Main Road,\r\nGopiralayam,\r\nMannargudi.', '', '', '07-May-2012', 'hair', '', '', '1336375082706161724'),
(355, 'Business', 'Broilers, Fish, Beef and Mutton Stalls', 'Pughzal Briolers', '', '23 D, Main Road,\r\nGopiralayam,\r\nMannargudi.', '', '', '07-May-2012', 'chicken', '', '', '1336375122502033053'),
(356, 'Business', 'Tailors', 'Rex Tailors', '9600200679', 'Madukkur Road,\r\nMannargudi.', 'Contact : V. Sekar', '', '07-May-2012', '', '', '', '1336375195634878696'),
(357, 'Hospitals and Medicals', 'Medical Stores', 'Abi Medicals', '', 'Madukkur Road,\r\nMannargudi.', '', '', '07-May-2012', '', '', '', '133637523538919427'),
(358, 'Business', 'Photo Studios', 'Sun Videos and Photos', '98650 72642', 'Mannai Nagar,\r\nMannargudi.', '', '', '07-May-2012', 'video, photos, digital', '', '', '1336375288387573307'),
(359, 'Automobiles', 'Motor Mechanics', 'M.K.S. Auto Works', '', 'Modern Nagar,\r\nMannargudi.', '', '', '07-May-2012', 'auto', '', '', '1336375499534773513'),
(360, 'Entertainments', 'Sound Services', 'M.K.S. Sound Service', '', 'Modern Nagar,\r\nMannargudi.', '', '', '07-May-2012', 'sound', '', '', '1336375527855923899'),
(361, 'Business', 'Welding Workshops', 'Mathi Welding Works', '96263 22606', '23/2, Madukkur Road,\r\nMannargudi.', '', '', '07-May-2012', 'welding', '', '', '1336375603946723105'),
(362, 'Building Construction', 'Cement Dealers', 'Hari Traders Dalmia Cement', '94455 23946', 'Madukkur Road,\r\nMannargudi.', '', '', '07-May-2012', 'cement', '', '', '13363756561165394720'),
(363, 'Automobiles', 'Service Stations', 'Shin Water Service Centre', '98434 51407 / 97503 89668', 'Modern Nagar,\r\nMannargudi.', '', '', '07-May-2012', 'water service', '', '', '1336375742139099962'),
(364, 'Automobiles', 'Motor Mechanics', 'Shin Autos', '98434 51407 / 97503 89668', 'Madukkur Road,\r\nMannargudi.', '', '', '07-May-2012', 'auto', '', '', '1336375774644184673'),
(365, 'Business', 'Tiles and Granites', 'G.V. International Granites', '94892 89588', 'Gopiralayam,\r\nMadukkur Road,\r\nMannargudi.', '', '', '07-May-2012', 'granites', '', '', '13363758211228238319'),
(366, 'Building Construction', 'Cement Dealers', 'P.G.M. Shankar Cement', '94860 43107', 'Madukkur Road,\r\nMannargudi.', '', '', '07-May-2012', 'cement', '', '', '1336375864632580459'),
(367, 'Agriculture', 'Seed Dealers', 'P.G.M Seeds Centre', '94860 43107', 'Madukkur Road,\r\nMannargudi.', '', '', '07-May-2012', 'seeds', '', '', '1336375932549919273'),
(368, 'Business', 'Maligai Stores', 'Bharathi Maligai', '98424 74235', 'Madukkur Road,\r\nMannargudi.', '', '', '07-May-2012', '', '', '', '1336376092936851988'),
(369, 'Business', 'Tiles and Granites', 'Mannai Tiles', '99657 26007', '44/1, Madukkur Road,\r\nMannargudi.', '', '', '07-May-2012', 'tiles', '', '', '1336376174353099750'),
(370, 'Automobiles', 'Auto Spare Parts', 'Sri Kumaran Autos', '96263 84428', 'Madukkur Road,\r\nMannargudi.', '', '', '07-May-2012', 'auto', '', '', '1336376217758531390'),
(371, 'Automobiles', 'Auto Spare Parts', 'Jeevan Auto Parts', '', 'Madukkur Road,\r\nMannargudi.', '', '', '07-May-2012', 'auto', '', '', '1336376237252391751'),
(372, 'General Services', 'Saloons', 'Modern Indian Beauty Parlour for Men A/C', '', 'Madukkur Road,\r\nMannargudi.', '', '', '07-May-2012', 'hair', '', '', '1336376299581341073'),
(373, 'Business', 'Broilers, Fish, Beef and Mutton Stalls', 'R. Bahurdeen Ali Mutton Stall', '95245 78870', '29-B, Balakrishna Nagar,\r\nMannargudi.', '', '', '07-May-2012', 'mutton', '', '', '1336376385990464963'),
(374, 'Business', 'Metals and Furnitures', 'Prabhu Furniture and Saamiyana Rental Centre', '93602 63947', '104, Balakrishna Nagar,\r\nMannargudi.', '', '', '07-May-2012', 'furniture, rental', '', '', '1336376466454184509'),
(375, 'Business', 'Rice Suppliers ( Arisi Mandy )', 'G. Singaravelu Arisi Mandy', '94866 41866 / 94893 19488', 'Balakrishna Nagar,\r\nMannargudi.', 'Nel Arisi Mandi', '', '07-May-2012', 'rice', '', '', '1336376563587632968'),
(376, 'Building Construction', 'Building Contractors', 'Samrat Construction ', '94438 06671', '52-JA, Old Thanjavur Road,\r\nMannargudi.', 'Samrat Construction Planning and Designing', '', '07-May-2012', 'construction, building', '', '', '1336376661437531708'),
(377, 'Business', 'Tiles and Granites', 'Sri Thaayar Granites', '226259 / 94431 22778', 'Thanjavur Main Road,\r\nMannargudi.', '', '', '07-May-2012', 'granites', '', '', '1336376731343718421'),
(378, 'General Services', 'Saloons', 'Young India Mens Beauty Parlour', '99448 84535', 'Opp. Keerthi Clinic,\r\nBalakrishna Nagar,\r\nMannargudi.', '', '', '07-May-2012', 'hair', '', '', '1336376798363611359'),
(379, 'Education', 'Schools', 'Xavier Matriculation School', '220350', 'Mannargudi.', '', '', '07-May-2012', 'matriculation', '', '', '13363776561022941692'),
(380, 'Education', 'Schools', 'SBA Matriculation School', '227590', 'Vadaseri Road,\r\nMannargudi.', 'Recognised by Govt. of Tamilnadu.\r\n\r\nCorrespondent : P.Ramesh MCA.,M.Phil.,MBA.,', '', '07-May-2012', 'matriculation', '', '', '133637779272564112'),
(381, 'Business', 'Rice Suppliers ( Arisi Mandy )', 'Sri Rajalakshmi Arisi Mandy', '222547 / 94431 75968 / 98427 05274', '57,R.K Palayam road,\r\nmannargudi.', 'Wholesale and retailer.\r\nFree door delivery.\r\nProp: B.R.S.Sivakumar.\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n', '', '10-May-2012', 'Rice', '', '', '1336632761367481283'),
(382, 'Hospitals and Medicals', 'Medical Stores', 'Golden Medicals', '252383 /  90036 37990', '49,Maha Mariamman koil street,\r\nMannargudi.', '', '', '13-May-2012', '', '', '', '13369266111101227742'),
(383, 'Hospitals and Medicals', 'Doctors', 'Dr. V.Karimuthu.B.Sc.,M.B.B.S.,D.A.,', '351680', '41/11b, Kamal Nagar,\r\nMannargudi.', 'Government Doctor.', '', '13-May-2012', '', '', '', '133693194420662254'),
(384, 'Banks', 'Money Transfer', 'UAE Exchange', '98424 38006 / 25547.', '28,First Floor,\r\nV.A.Ashokan Complex,\r\nNear Head Post Office,\r\nMela Raja Veedhi,\r\nMannargudi.', 'Instant Gold Loans,Foreign Exchange,Vehicle loans,\r\nMoney Transfer, Air ticketing and tourism services.\r\n\r\nToll Free No: 1860 3000 1555', '', '13-May-2012', 'gold loans, air tickets, tourism', 'mail.us@uaeexchange.co.in', 'www.uaeexchangetravel.com', '1336932526318611008'),
(385, 'Business', 'Tailors', 'Jothis Tailors', '97888 35900', '19/8,Maha Mariamman Koil Street,\r\nMannargudi.', 'Prop: N.Senthil.', '', '13-May-2012', '', '', '', '1336933078525007041'),
(386, 'Hospitals and Medicals', 'Blood Testing,E.C.G. - X-Rays Centers', 'Sree Nivas Blood testing Centre', '97917 63680  /  96264 03704', '2/58A,Natesan Street,\r\nMannargudi.', 'Prop:P.Manikandan.MA.,MLT.,CRA.,', '', '13-May-2012', '', '', '', '13369336921131222899'),
(387, 'Hotels, Lodges and Restaurants', 'Hotels', 'Sree Ariyabhavan Hotel and Sweets', '222677', 'Opp.to: Bus Stand,\r\nMannargudi.', 'Party Orders undertaken.', '', '14-May-2012', 'sweets', '', '', '133693403617409716'),
(388, 'General Services', 'Beauty Parlours', 'Jeyam alagu Nilayam (Beauty Parlour)', '250615  /  93641 16738', '88B, Melaraja Veedhi,\r\nNear Gemini Press,\r\nMannargudi.                                                  \r\n                      \r\n', '', '', '14-May-2012', '', '', '', '1336934571516603257'),
(389, 'General Services', 'Painters', 'G. Senthil Kumar ', '97862 35860', '127, Moorka Vinayagar Kovil Street,\r\nMannargudi.', '', '', '14-May-2012', '', '', '', '1336982768151376199'),
(390, 'Banks', 'Finance Co', 'Manappuram Finance Limited', '324544 / 253903', '1/74, Mela Raja Veedhi,\r\nNear Bus Stand,\r\nMannargudi.', '', '', '14-May-2012', '', '', '', '1336982883440584414'),
(391, 'Business', 'Other Category', 'Pradeepa Flour and Grinder Mill', '93600 80161', 'Near Bhakiyam Maligai,\r\nVinobaji Street,\r\nMannargudi.', 'Grinding of Ginger, Garlic, Coconut, Turmeric, Rice, Chilli, Wheat, Coriander, Black gram, Idly Flour ', '', '14-May-2012', '', '', '', '1336982975714165402'),
(392, 'Business', 'Printing Press', 'Annai Offset Printers', '251595 / 98424 57147 / 91717 17154', '7-C, Maha Maariamman Kovil Street,\r\nNear S.T. Couriers,\r\nMannargudi.\r\n', 'Wedding Invitations, Binding, Bill Books, Notice, Scanning, Printout, Spiral Binding, Multi Color Visiting Cards, Rubber Stamps\r\n\r\nProp: A. Xavier Shagayaraj', '', '14-May-2012', 'printing job', 'annaioffset@rediffmail.com', '', '1336983167412240598'),
(393, 'Business', 'Printing Press', 'Sri Vidya Printing Press', '253944', 'Mannargudi', '', '', '14-May-2012', 'printing job', '', '', '1336983315781792691'),
(394, 'Business', 'Browsing Centres', 'Star.net Browsing', '227154  /  97880 44406  /  99768 03625', '58, Rukmani Palayam Road, \r\nMannargudi.', 'Air and Railway ticket Booking,Project works,\r\nscanning,DTP works and Web Chatting.', '', '14-May-2012', 'air tickets,railway tickets', 'starnet.mng@gmail.com', '', '1336984531423517979'),
(395, 'Hotels, Lodges and Restaurants', 'Restaurants', 'Red Chilli Multicuisine Restaurant', '227154  /  97880 4404.6  /  99768 03625', '58, Rukmani Palayam Road,\r\nMannargudi.', 'We Undertake Special Party Orders.', '', '14-May-2012', 'party orders', 'redchilli.mng@hotmail.com', '', '1336985125275470870'),
(396, 'Banks', 'Finance Co', 'SPL Chits', '94870 31549', '34,Vinobaji Street,\r\nMannargudi.', '', '', '14-May-2012', 'chits', '', '', '1336985331712864890'),
(397, 'General Services', 'Painters', 'Venkateshwara Spray and Art', '76392 51599', 'Karakkottai,\r\nMannargudi.', '', '', '14-May-2012', 'painters', '', '', '1336985511106195586'),
(398, 'Business', 'Other Category', 'Cane and Corn Juice Shop', '', '52,Near Aarthi Nursing Home,\r\nMannargudi.', '', '', '14-May-2012', 'juices', '', '', '1336985846715041122'),
(399, 'General Services', 'Others', 'Amma Tv', '94432 73781', '27/113C,Old Thanjavur Road,\r\nBalakrishna Nagar,\r\nMannargudi.', 'Prop:S.Kannan.\r\nTamilnadu Government approved channels', '', '14-May-2012', '', '', '', '1336986194282584377'),
(400, 'Business', 'Printing Press', 'Lakshmi Printing Press', '94423 99299', 'Near ICICI Bank,\r\nPandaladi,\r\nMannargudi.', '', '', '15-May-2012', 'printing job', '', '', '1337071883838496841'),
(401, 'Education', 'Tutorials', 'Baalaji Tutorials', '9944116737', 'No.7, Mela Othai Street,\r\nMannargudi.', '', '', '15-May-2012', '', '', '', '1337071934333399897'),
(402, 'Hotels, Lodges and Restaurants', 'Hotels', 'Hotel Aariyaas A/C', '253681', '60, Kaamarajar Veedhi,\r\nBig Bazaar Street,\r\nMannargudi.', 'High Quality Vegetarian Hotel, Juice Stall and Sweets ', '', '15-May-2012', '', '', '', '1337072113810071592'),
(404, 'Business', 'Fancy Stores', 'Ramdev Fancy Center', '252590  /  94432 46240', 'No.2,Thamaraikulam Melkarai,\r\nNear K.B.Complex,\r\nMannargudi.\r\n', 'wholesale dealers in glass bangles,metal bangles, rubber bangles,toys and fancy items.\r\n\r\nProp: B.S. Dhiya.', '', '17-May-2012', 'toys,bangles', '', '', '1337241333472903558'),
(405, 'Business', 'Tailors', 'Naveen Tailors', '98426 23800  /  97880 44687', '48, Big Bazaar Street,\r\nMannargudi.', '', '', '17-May-2012', '', '', '', '1337258663479194050'),
(406, 'Business', 'Gold Covering Stores', 'Kalaivani Covering, Fancy and Gift', '99420 17631', '209, Big Bazaar Street,\r\nMannargudi.', 'Prop: S.Jamal Mohamed.\r\n6 months and 1 year guaranteed gold covering sets available. covering gold set available on rental basis also.', '', '17-May-2012', 'gifts', '', '', '1337259103423787044'),
(407, 'Business', 'Metals and Furnitures', 'Sree Selvam Metal Sales', '316311  /  92620 11162', '54, Big Bazaar Street,\r\nMannargudi.', 'household items business\r\n\r\n', '', '17-May-2012', 'furniture', '', '', '1337259386179012534'),
(408, 'Business', 'Metals and Furnitures', 'Guru Furniture', '316311  /  92620 11162', 'Second Floor,\r\n54,Big Bazaar Street,\r\nMannargudi.', 'household items business', '', '17-May-2012', 'metals', '', '', '1337259525397625409'),
(409, 'Business', 'Mobile Shops', 'Citizen Watches and Cellphone Sales and Service', '98433 12014  /  98656 87240', '45/2,Melaraja Veedhi,\r\nMannargudi. ', '', '', '17-May-2012', 'watches', '', '', '13372598241005128964'),
(410, 'Hotels, Lodges and Restaurants', 'Hotels', 'Hotel Achees', '251145', '2,Thamaraikulam West,\r\nMannargudi.', '', '', '17-May-2012', '', '', '', '1337260158335900422'),
(411, 'Business', 'Mobile Shops', 'Susai and Brothers Mobiles and Recharge Corner', '98425 26644  /  83001 26300', 'Opp to:K.K.P.Lodge,\r\nBig Bazaar Street,\r\nMannargudi.', 'Prop:S.Cell-Varaj.', '', '17-May-2012', '', '', '', '1337260416995359321'),
(412, 'Business', 'General Merchants', 'Noor Stores', '252049  /  98424 14904  /  98941 43031', '2,Big Bazaar Street,\r\nNear Thamaraikulam,\r\nMannargudi.', 'all foreign goods available', '', '17-May-2012', 'tourist cars', '', '', '1337260693331746520'),
(418, 'Business', 'Textile and Readymades', 'Sree Murugavel Textiles', '254022', '63,Big Bazaar Street,\r\nMannargudi.', 'Prop:K.Rajan.\r\nWholesale Textiles Business.', '', '17-May-2012', 'wholesale', '', '', '13372620071224177127'),
(419, 'Business', 'Textile and Readymades', 'Rasu Trading', '254022', '63,Big Bazaar street,\r\nMannargudi.', 'wholesale textiles trading.', '', '17-May-2012', '', '', '', '1337262108216520420'),
(420, 'Business', 'Textile and Readymades', 'Sri Mangai Silks', '255399  /  98423 69392', '16,Big Bazaar Street,\r\nMannargudi.', 'Prop:A.Selvamani.B.Com.,', '', '17-May-2012', '', '', '', '1337262262338084905'),
(421, 'Business', 'General Merchants', 'New Indian Stores', '251960  /  98425 22141', '9c,Big Bazaar Street,\r\nOpp to: State Bank of India,\r\nMannargudi.', 'Prop: A.Nazir Ahamad.B.Sc.,\r\n      N.Navbal Ahamad.B.B.A.,\r\nAll types of shop items, fancy goods and gift items available.', '', '17-May-2012', 'gifts', '', '', '1337262905470042848'),
(422, 'Business', 'Electrical Stores', 'Sri Bhagavathi Electricals', '252452  /  94431 31452  /  98439 41138', '45/1,Melaraja Veedhi,\r\nOpp to: PMM Lodge,\r\nMannargudi.', 'Kundan, Vinay, Lisha and Goldmedal brands available.', '', '17-May-2012', '', '', '', '13372633511215080413'),
(423, 'Automobiles', 'Auto Spare Parts', 'Sree Guru Auto Spares', '220136', '58-B,Rukmanipalayam Road,\r\nNear Thangamani Building,\r\nMannargudi.', 'Two wheeler, Four wheeler and Truck spares\r\navailable.', '', '17-May-2012', '', '', '', '13372636091016556139'),
(424, 'Business', 'Textile and Readymades', 'Sri Aaba Readymades', '253583  /  98947 76428', '40,Melaraja Veedhi, \r\nMannargudi.', 'Prop: B.Sekar.M.A.,', '', '17-May-2012', '', '', '', '1337263999466202218'),
(425, 'Education', 'Polytechnic', 'Maruthan Industrial School', '', 'Thanjavur Road,\r\nKumarapuram,\r\nMelavasal,\r\nMannargudi.', 'Catering free training ', '', '18-May-2012', '', '', '', '1337359904213808067'),
(426, 'Hospitals and Medicals', 'Doctors', 'Dr.V.Bhaskaran.M.D.,F.A.C.P.,', '254004  /  252449', 'A.V.M.Hospital,\r\n2,Balakrishna Nagar,\r\nOpp to:St.Joseph Convent,\r\nMannargudi.', 'visiting hours:Thursdays 9am to 6pm and Saturdays \r\n4pm to 8pm.', '', '19-May-2012', 'hospitals', '', '', '13374056891085081947'),
(427, 'Hospitals and Medicals', 'Medical Stores', 'Sree Thayaar Medicals', '254004', 'AVM Hospital,\r\n2,Balakrishna Nagar,\r\nOpp to: St.Joseph Convent,\r\nMannargudi.', 'sundays open.', '', '19-May-2012', '', '', '', '1337405876573040215'),
(428, 'Hospitals and Medicals', 'Blood Testing,E.C.G. - X-Rays Centers', 'AVM Hospital  X-Ray, E.C.G. and Clinical Laboratory', '252449  /  254004', '2,Balakrishna Nagar,\r\nOpp to: St.Joseph Convent,\r\nMannargudi.', '', '', '19-May-2012', 'hospitals', '', '', '1337406228694373207'),
(429, 'Business', 'Agencies', 'Gajendra Agencies', '223202  /  224202  /  94422 24202', 'Cement Dealers,\r\nNo1,Vadakku Veedhi,\r\nNear Dharani School,\r\nMannargudi.', 'Dealers: Coromandal king, Coromandal super power, \r\nShankar sakthi, Shankar super power, Super 53 grade cement and 43 grade cement.\r\nProp:G.Jayaraman.', '', '19-May-2012', 'cements', '', '', '1337407313607599455'),
(430, 'Business', 'Electronics Showrooms', 'Satyam Electronics', '349691  /  94436 48287', '40/13,RK Palayam Road,\r\nOpp to: BSNL Office, \r\nMannargudi.', 'Dealers in: All Companies DTH,DVD,Home Theater,\r\nRemots and TV Spares.(Panasonic,Sony,Toshiba,Pioneer,Philips,Everest)\r\nProp:M.Indrajit, I.Sathiyajit.', '', '19-May-2012', 'TV Spares,Stabilizers', '', '', '1337407872626384262'),
(431, 'Business', 'Mobile Shops', 'Tel India Mobiles', '80122 24070', '40/6,R.K.Palayam Road,\r\nMannargudi.', 'Mobile Sales and Service,Computer spares.\r\nProp: S.Sureshkumar.', '', '19-May-2012', 'computer spares', 's.suretronics@gmail.com', '', '1337408198190540071'),
(432, 'Building Construction', 'Civil Engineers', 'P.Suriyaprakash.B.E.,M.I.E.,F.I.V.,', '222211  /  251294  /  94431 21294', 'Meenakshi Construction,\r\n25D, R.K.Palayam Middle Street,\r\nMannargudi.', 'Engineer,Valuer,Contractor.', '', '19-May-2012', 'contractors,Valuers', 'suriya_mcm@yahoo.com', '', '1337408601496547333'),
(433, 'Building Construction', 'Building Contractors', 'Meenakshi Construction', '222211  /  251294  /  94431 21294', '25D,R.K.Palayam Middle Street,\r\nMannargudi.\r\n', 'Contractor,Valuer,Engineer.\r\nProp: P.Suriyaprakash.B.E.,M.I.E.,F.I.V.,', '', '19-May-2012', 'engineers', 'suriya_mcm@yahoo.com', '', '1337408894529514247'),
(434, 'Business', 'Fancy Stores', 'Lakshmi Novelty', '98949 89473  /  252590', '17A,Big Bazaar Street,\r\nOpp: State Bank of India,\r\nMannargudi.', 'All Fancy items, Plastics and Shop Products\r\nwholesale rate available here.', '', '19-May-2012', 'fancy goods', '', '', '1337409208674011252'),
(435, 'Business', 'Fancy Stores', 'Ruby Fancy  - Shopping and Covering', '253757', '48,Big Bazaar Street,\r\nMannargudi.', '', '', '19-May-2012', 'coverings', '', '', '1337409335983270732'),
(436, 'Business', 'Photo Studios', 'Prema Digital Studio and Video  -  xerox', '251977  /  98423 99146  /  96983 44098', 'Big Bazaar Street,\r\nOpp: State Bank of India,\r\nMannargudi.', 'xerox jobs done here', '', '19-May-2012', 'xerox', '', '', '1337409546922387298'),
(437, 'Business', 'Spare Parts stores', 'Sundaram Tools Center', '99426 97738', '33,Big Bazaar Street,\r\nMannargudi.', 'Dealers; Bosch, Hitachi, Black and Decker.\r\nAll company tools,machine and spare parts available.\r\nAll company machine service done here.', '', '19-May-2012', 'machine services', '', '', '1337409821813785406'),
(438, 'Building Construction', 'Cement Dealers', 'Gajendra Agencies    ', '223202  /  224202  /  94422 24202', 'No.1,Vadakku Veedhi,\r\nNear Dharani School,\r\nMannargudi.', 'Dealers; Coromandal king ,Coromandal super power,\r\nShankar sakthi, Shankar super power, Super 53 grade cement and 43 grade cement.\r\nProp: G.Jayaraman.\r\n', '', '19-May-2012', 'agencies', '', '', '1337410196429513020'),
(439, 'Travels', 'Tourist Buses, Vans and Cars', ' Noor  Travels    ', '252049  /  98424 14904  /  98941 43031', '2,Big Bazaar Street,\r\nNear Thamaraikulam,\r\nMannargudi.', 'car,van,tempo,qualis, toyota innova available for hire.', '', '20-May-2012', 'tourist', '', '', '1337524850601859933'),
(440, 'Travels', 'Travel Agencies', 'Rangoon Travels', '', 'Gandhi Road,\r\nMannargudi.', 'Air Ticketing', '', '20-May-2012', 'Air Ticket', '', '', '1337524994422828426'),
(441, 'Business', 'Cycle Company', 'City Traders', '251008  /  93802 91266', '42A, Melaraja Veedhi,\r\nMannargudi.', 'contact: Mr.Kumaran.', '', '20-May-2012', 'cycles', '', '', '133752955744218541'),
(442, 'Business', 'Marriage Halls', 'Santhosh Kalyana Mahal', '220327  /  221577', 'Thanjavur Main Road,\r\nMannargudi.', '', '', '20-May-2012', '', '', '', '1337529797410743014'),
(443, 'Business', 'Marriage Halls', 'Ashoka Thirumana Mahal', '', 'Madukkur Road,\r\nMannargudi.', '', '', '20-May-2012', '', '', '', '1337529876168062158'),
(444, 'Business', 'Service Providers', 'Venus Fridge Service Center', '98426 97364', '134,Madukkur Road,\r\nMannargudi.', '', '', '20-May-2012', 'fridge service', '', '', '1337530149538161016'),
(445, 'Business', 'Department Stores', 'Saarah Department Stores', '250035  /  94881 15114', '11, West Third Street,\r\nMannargudi.', 'Quality maligai items,Shop items,Fancy goods and Household items from A to Z.', '', '21-May-2012', 'fancy goods', '', '', '1337579986335340698'),
(446, 'Hospitals and Medicals', 'Blood Testing,E.C.G. - X-Rays Centers', 'Prabu X-Rays and computer blood testing center', '', 'Gandhi Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '1337603644875544615'),
(447, 'Hospitals and Medicals', 'Medical Stores', 'Vijaya Medicals', '', '129,Gandhi Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '1337603696500668583'),
(448, 'Business', 'Other Category', 'Mannai Flour and Oil Mills', '', '127, Gandhi Road,\r\nMannargudi', '', '', '21-May-2012', '', '', '', '1337603801890683038'),
(449, 'Business', 'General Merchants', 'Anbu Stores', '', '125, Gandhi Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '1337603956786776389'),
(450, 'Building Construction', 'Building Contractors', 'Galaxy Builders', '9976602524', 'V.S.T Complex,\r\nRK Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '1337603996646596863'),
(451, 'Travels', 'Driving Schools', 'Guna Driving School', '94426 83292', 'R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '1337604033537745997'),
(452, 'Hospitals and Medicals', 'Medical Stores', 'Sekar Medical Store', '426518', '38/1-D, R.K Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '1337604068609782779'),
(453, 'Business', 'Xerox Shops', 'Deepam Xerox and PCO', '', 'R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '1337604176321319617'),
(454, 'Travels', 'Tourist Buses, Vans and Cars', 'Sri Ganesha Transports Bus Service', '9965574750', 'R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '1337604243573161837'),
(455, 'Business', 'Metals and Furnitures', 'J.K. Enterprises', '9865517242', '36-B, R.K. Palayam Road,\r\nMannargudi.', 'Furniture items at production rates.', '', '21-May-2012', '', '', '', '1337604302269924176'),
(456, 'General Services', 'Auto Electrical Works', 'Mano Auto Electrical Works', '', '62, R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '13376044881124455267'),
(457, 'Automobiles', 'Tyre Showrooms', 'Sri Malayappa', '', '62 R.K. Palayam Road,\r\nMannargudi', 'Tyre tube works', '', '21-May-2012', 'Tyre', '', '', '1337604545763667232'),
(458, 'General Services', 'Auto Electrical Works', 'Sekar Auto Works', '424448', 'R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', 'Auto', '', '', '1337604582316878856'),
(459, 'Business', 'Xerox Shops', 'Om Xerox', '', 'R.K. Palayam Road,\r\nMannargudi.', '40 Paisa Per Xerox', '', '21-May-2012', '', '', '', '1337604640601209204'),
(460, 'Business', 'Agencies', 'Lucky Agencies', '', '23, R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '133760469293201360'),
(461, 'Business', 'Hardware Shops', 'Selvam Hardware', '98420 24394', '22, R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '1337604780158845938'),
(462, 'Business', 'Service Providers', 'Sun Auto Consulting', '98423 64714 / 93600 64714', '18, R.K. Palayam Road,\r\nMannargudi.', 'All Two Wheeler Buying and Selling', '', '21-May-2012', '', '', '', '13376048721027586399'),
(463, 'Business', 'Mobile Shops', 'Velavan Cell Service', '', 'R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', 'mobile', '', '', '1337604909594040717'),
(464, 'Travels', 'Travel Agencies', 'Raj Travels and Electricals', '9443585609', 'R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '1337604958940465595'),
(465, 'Agriculture', 'Agri Clinic and Research', 'Mega Agri Clinic and Consulting Centre', '', '73, MRV Complex,\r\nR.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '1337605076280920562'),
(466, 'Business', 'Photo Studios', 'Shakthi Digital Studio and Videos', '9245459644', '73- R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', 'photo, video, digital', '', '', '1337605178549742910'),
(467, 'General Services', 'Auto Electrical Works', 'Sri Murugan Auto Works', '', '12, R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '133760524495716467'),
(468, 'Automobiles', 'Motor Showrooms', 'Sri Durga Auto Parts', '228431', '73- Rukmani Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '133760530949367890'),
(469, 'Travels', 'Driving Schools', 'Raasi Driving School', '94428 46536', '73, R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '13376054001115689917'),
(470, 'Building Construction', 'Building Contractors', 'Suresh Construction', '94434 75692', '73, R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '133760544092842674'),
(471, 'General Services', 'Rewinding Works', 'Mano Rewinding Electrical and Plumbing Works', '9443402337', '6/B, R.K. Palayam Road,\r\nMannargudi', '', '', '21-May-2012', '', '', '', '133760578012274639'),
(472, 'Business', 'Electrical Stores', 'Sri Maruthi Electricals', '94861 54837', '6B-1, R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '1337605839530979670'),
(473, 'Business', 'Rice Suppliers ( Arisi Mandy )', 'S.J. Arisi Mandy', '94421 25097', 'R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '1337605883270939957'),
(474, 'Hotels, Lodges and Restaurants', 'Hotels', 'Hotel Giramiyam', '9786633734', 'R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', '', '', '', '1337606632274502165'),
(475, 'Business', 'Xerox Shops', 'Sri Shakthi Cellcom Xerox and DTP', '', 'R.K. Palayam Road,\r\nMannargudi.', '', '', '21-May-2012', 'Xerox', '', '', '1337606694883116807'),
(476, 'Building Construction', 'Building Contractors', 'Royal Construction', '228461  /  251015  /  94431 28461', '101/43,East Third Street,\r\nMannargudi.', 'R.Kanagaraj.D.C.E.,B.Tech.,\r\nConsulting Civil Engineer and Licensed Surveyor.\r\nEngineering Contractor.', '', '23-May-2012', 'Civil Engineers,Surveyors', '', '', '1337793419264887104'),
(478, 'Business', 'Opticals', 'Vision Eye Care  Opticals and clinic', '86953 39377', 'Balakrishna Nagar,\r\nOpp: Chinna Convent,\r\nMannargudi.\r\n', 'Eye Testing Center. Eye Specialist visits daily \r\nfrom 10am to 1pm and 5pm to 8pm.\r\n25percent discount on every purchase of cooling glass and glass frames.\r\n', '', '26-May-2012', 'clinic', '', '', '1338055351839556852'),
(479, 'Education', 'Schools', 'Xavier Jesus Matric Higher Secondary School', '252397', '21, Kulandhai Vel Street,\r\nMannargudi.', 'Pre KG to IX Std.', '', '28-May-2012', '', '', '', '1338192682540211739'),
(480, 'Business', 'Mobile Shops', 'S.S.Cells', '', 'Pandaladi,\r\nMannargudi.', 'Available all world famous mobiles, china mobiles\r\nand spares.\r\n\r\n', '', '14-Jun-2012', '', '', '', '1339677325142474018'),
(481, 'Hospitals and Medicals', 'Clinics', 'Raj Hospital', '252457', '10, Balakrishna Nagar,\r\nMannargudi.', '24 hours Ambulance service.\r\nC.T.Scan Facility Available here.', '', '14-Jun-2012', '', '', '', '1339677738285374295'),
(483, 'Automobiles', 'Tyre Showrooms', 'Aero Tyre Retreading', '73730 73230  / 31 / 32 / 33', '10,Meenakshi Amman Koil Vadakku Veedhi,\r\nKeelappalam,\r\nMannargudi.', 'Quality cooling and Hot method tyre retreading done here for Tata Ace,Lorry,Van,Bus,Tractor and also all types of vehicle tyres.', '', '18-Jun-2012', '', '', '', '1340013409389983444'),
(485, 'Business', 'Electrical Stores', 'City Corporation', '291129', 'No.2B,Sandhai Pettai,\r\nNear Ulavar Sandhai,\r\nMannargudi.', 'Dealers: Motor,Pumpset,Rice and Flour Mill stores.\r\nPlumbing and Electricals.', '', '18-Jun-2012', 'Motor, Pumpsets,Rice and Flour Mill stores,Plumbing', '', '', '13400150231024636163'),
(486, 'Business', 'Printing Press', 'Meenakshi Offset    ', '346333 /  93456 26798', 'Pandaladi,\r\nMannargudi.', '', '', '18-Jun-2012', '', '', '', '1340015275834306877'),
(487, 'Education', 'ITI', 'Sri Jagan ITI', '291666  /  94860 43600', 'K.K.Nagar,\r\nKaalavaikarai,\r\nMannargudi.', '', '', '15-Jul-2012', '', '', '', '1342362408804664801');
INSERT INTO `sal_add_company` (`id`, `category`, `sub_category`, `title`, `phone`, `address`, `otherinfo`, `pic`, `date`, `tags`, `email`, `website`, `rand_id`) VALUES
(488, 'Business', 'Printing Press', 'Rajamani Offset Press', '253003  /  94430 75770', '', '', '', '15-Jul-2012', '', '', '', '1342362521608058605'),
(489, 'Education', 'Schools', 'Lord Seven Hills Higher Secondary School', '326232', 'Thanjavur Main Road,\r\nKumarapuram,\r\nMelavasal,\r\nMannargudi.', 'From LKG to +2.\r\nBest Teaching in the way of Smart Class through Interactive Board', '', '15-Jul-2012', '', '', '', '1342362967645527655'),
(490, 'General Services', 'LIC and Insurance Agents', 'LIC Housing Loan Direct Consultant', '04362-271887 /  98425 65224  /  94430 02614', 'HLA Office,\r\nMela Raja Veedhi,\r\nNear Head Post Office,\r\nMannargudi.', 'Direct Consultant: Mr.K.Thetshanamoorthy,B.A.,C.I.S.,D.C.A.,', '', '15-Jul-2012', '', '', '', '13423634471170561571'),
(491, 'Business', 'Mobile Shops', 'Selviees and Co.,', '91712 00079  /  251823', '5/6,P.R.R. Complex,\r\nMannargudi.', 'Uninor Help Line Distributor, Retailer and Customer.\r\nBranches at Thiruthuraipoondi and Muthupet.', '', '15-Jul-2012', '', '', '', '1342363858459272767'),
(492, 'Education', 'Arts and Science', 'STET College Of Education For Women', '293551', 'Sundarakkottai,\r\nMannargudi-614016', 'A Unit Of S.T.E.T\r\nOptional Subjects Offered: Tamil,English,History,Mathematics,\r\nPhysical Sciences and Biological Sciences.', '', '15-Jul-2012', '', '', '', '1342364515714409102'),
(493, 'Education', 'Paramedical Colleges', 'Venkateshwara College Of Pharmacy and Nursing', '255757 /  94431 34562', '1-A, BalaKrishna Nagar,\r\nOpp to: St.Josephs Hr.Sec.School,\r\nMannargudi.', 'Diploma in Nursing AIDE approved by Tamil Nadu Government  Dr.M.G.R.Medical University.\r\n', '', '15-Jul-2012', '', '', '', '1342365291169017919'),
(494, 'Business', 'Printing Press', 'Vedha Digital Studio,Video and Offset', '93677 49838', '', '', '', '18-Jul-2012', '', '', '', '1342631575685585558'),
(495, 'Hospitals and Medicals', 'Medical Stores', 'Baba Medicals', '250819  /  99652 07740  /  88834 42564', '5, Bala Krishna Nagar,\r\nNear Chinna Convent,\r\nMannargudi.', '', '', '13-Oct-2012', '', '', '', '13501015121082366975'),
(496, 'Hospitals and Medicals', 'Doctors', 'Dr. M. Hameed Ali M.V.Sc., (Veterinary Surgeon)', '94422 70351 / 98424 70153', 'Veterinary Hospital,\r\nMannargudi - 614001,\r\nThiruvarur Dist.', '', '', '17-Oct-2012', 'Veterinary, Surgeon', 'drhameedalim@gmail.com', '', '1350467588935128618'),
(497, 'Hotels, Lodges and Restaurants', 'Restaurants', 'Kuwait Dheen Athikkadai Purotta centre (Halal)', '98651 02404', '33, Azad Street,\r\nNear Old Bus Stand,\r\nMannargudi.', 'Propreitor: A. Dheen Tahir.\r\nBig Special Orders taken for your Home Functions.', '', '03-Nov-2012', '', '', '', '1351914387170084902'),
(498, 'Business', 'Metals and Furnitures', 'Sr i Balamurugan TV,Fridge,Furniture Show Room', '253763', '64,65,Gandhi Road,\r\nPandaladi Northside,\r\nMannargudi.', 'Special Offers And Special Discounts are avialable\r\nin all Festive Seasons.', '', '04-Nov-2012', 'Wooden Furnitures', '', '', '1352002394508106610'),
(499, 'Business', 'Printing Press', 'SS Offset Printers', '253456', 'Near Vegetable Market,\r\nMannargudi.', '', '', '04-Nov-2012', '', '', '', '1352002523487502527'),
(500, 'Business', 'Mobile Shops', 'N.R. Mobile and Fancy Store', '90954 11305, 98422 31805', '144, Arisi Kadai Sandhu,\r\nMannargudi.', 'Nokia,Samsung,China Mobiles Available at Cheaper \r\nPrices.And also avilable Fancy goods, Covering \r\nJewellery and Plastic goods.', '', '06-Nov-2012', 'Covering Jewellery', '', '', '1352177043100009505'),
(501, 'Business', 'Agencies', 'Om Murugan Agencies', '97516 83386  /  97502 46523', '10, Natesan Street,\r\nMannargudi.', 'International Quality Laxman Brand Pickles \r\navailable.', '', '09-Nov-2012', '', '', '', '1352437344162069526'),
(502, 'Business', 'Textile and Readymades', 'Thulasi Pengal Ulagam', '96885 58600', '218, Gandhi Road,\r\nPandaladi,\r\nMannargudi.', 'Readymades, chudidhars,Knightees etc., available \r\nfor girls & women. Branded Dresses and Cheaper Prices.', '', '11-Nov-2012', '', '', '', '1352609463721095215'),
(503, 'Business', 'Gold Covering Stores', 'SRJ  Kanniga Covering', '', '146, J and J Plaza,\r\nBig Bazaar Street,\r\nMannargudi.', 'Guaranteed Gold Covering Bangles and Jewellery\r\navailable at cheaper prices.', '', '11-Nov-2012', '', '', '', '13526097951200247986'),
(504, 'Hospitals and Medicals', 'Doctors', 'Dr. G.Ramachandran. MBBS.,DTCD.,', '222957  /  98423 24957', 'Kamatchi Hospital,\r\n1L, Natesan Street,\r\nMannargudi. ', '', '', '12-Nov-2012', '', '', '', '1352731849238919362'),
(505, 'Hospitals and Medicals', 'Clinics', 'Kamatchi Hospital', '222957  /  98423 24957', '1L, Natesan Street,\r\nMannargudi.', 'Dr. G.Ramachandran.MBBS.,DTCD.,', '', '12-Nov-2012', '', '', '', '1352732030186315240'),
(506, 'Entertainments', 'TV and Media', 'Sai TV', '351555  /  93 6060 1194  /  98425 66066', '27/113, Keerthi Clinic Complex,\r\nBalakrishna Nagar,\r\nMannargudi.', 'Tamil Nadu Government approved Local TV Channel.\r\nProprietor: R. Bhakyaswami.M.com.,MBA.,', '', '17-Nov-2012', 'Local TV Channel', 'saitvswami@yahoo.com', '', '13531276271047184643'),
(507, 'Business', 'Textile and Readymades', 'Pink Lady', '97508 89822', '25, Keela Raja Veedhi,\r\nOpp.To: T.M.A Towers,\r\nMannargudi.', 'Always in Hi-Fashion.\r\nLatest Dubai Burkas,Skirts, Pants, Fashion Scarf,\r\nChudidhar,Leggings, Kurtis,Nightwear, Innerwear,\r\nT-Shirts,Tops and Readymade Chudis are available\r\nin Huge varieties at cheaper prices.', '', '17-Nov-2012', 'Textiles, Readymades', '', '', '1353128077552998223'),
(508, 'Business', 'Imports and Exports', 'Royal Exports', '99651 13955  /  96596 98784', '43/1, K.S.S. New Street,\r\nMannargudi.', 'Proprietor: R.Ravi.\r\nTelefax: +91-4367-253955', '', '17-Nov-2012', 'Exports', 'royalexport.mng@gmail.com', '', '13531284711161224689'),
(509, 'Business', 'Photo Studios', 'Saravana Videos A/C', '310092  /  94431 70405  /  98430 42603', '71. R.K. Palayam Road,\r\nNear Sami Theatre,\r\nMannargudi.', 'Proprietor: Jc. K.V.Saravanan.', '', '17-Nov-2012', '', '', 'www.mannaisaravanavideos.com', '135312935014098818'),
(510, 'Business', 'Rice Suppliers ( Arisi Mandy )', 'Sri Om Sakthi Arisi Kadai', '96592 54051', '28, Gopalasamudram Vadakku Veedhi,\r\nMannargudi.', 'Proprietor: A.Nagarajan.\r\nAll Brand Rices available in Retail and also in Wholesale.Door Delivery Facility available.', '', '17-Nov-2012', '', '', '', '1353129698164117762'),
(511, 'Business', 'Printing Press', 'Jayasakthi Offset', '223108  /  96595 0218', '7, Parangusam Street,\r\nSanthai Pettai Road,\r\nMannargudi.', 'Wedding Invitations, Notice, Bill Book,Letter Pads,\r\nSpiral Binding, Lamination Binding,Project Binding\r\nEtc.,', '', '20-Nov-2012', '', 'jayasakthi108@gmail.com', '', '135342154357744210'),
(512, 'Business', 'Mobile Shops', 'Guru Mobiles', '97865 5079  /  96888 78733', '25, Natesan Street, \r\nOpp. Bus Stand,\r\nMannargudi.', 'Sales and Service', '', '20-Nov-2012', '', '', '', '1353421777977583505'),
(513, 'Business', 'Traders', 'Thangam Traders', '94867 41668  /  80126 35364', '70, Mela Raja Veedhi,\r\nMannargudi.', 'Branch: Alangudi.\r\nRetail and Wholesale Groundnut Dealers.\r\nProprietor: S.K.K. Subbaiyan. DCA.,', '', '20-Nov-2012', '', '', '', '1353422172942582340'),
(514, 'Business', 'Computer Shops', 'Hi5 Computers', '9043796106', '21/3, Kamal Nagar,\r\nOpp: Dr.Sekar Cilnic,\r\nMannargudi.', 'Computer Sales and Service, Web Design, Web Hosting, Flex Banners, Internet Cafe, Invitation Cards,Visiting Cards, Letter Pads,Internet Cafe, Game CDs and all computer related services.', '', '20-Nov-2012', 'Web Design, Web Hosting, Domain Registration, Internet Cafe, Printing Jobs, Flex Banners', 'info@hi5webdesign.com', 'www.hi5webdesign.com', '1353422485734249499'),
(519, 'Business', 'Sweet Stalls', 'Thanjai Sri Krishna Sweets', '', '5, Natesan Street,\r\nOpp. New Bus Stand,\r\nMannargudi.', '', '', '13-Dec-2012', '', '', '', '1355373968739784514'),
(520, 'Business', 'Juice Centers', 'Linga Pazhamudhir cholai & Juice Center', '99944 87939', '149A,Gandhi Road,\r\nOpp: National High School,\r\nMannargudi.\r\nProp: C. Senthil.', 'Sweetest Juices at Low prices. All fruits sold on retail and also on wholesale.', '', '13-Dec-2012', '', '', '', '1355374392239799949'),
(521, 'Banks', 'Finance Co', 'DhanaLaxmi Srinivasan Chit Funds Pvt Ltd', '97509 68171, 97509 68353', 'Branch Office,\r\n59-B, Natesan Street,\r\nOpp. LDS First Follr,\r\nCanara Bank Upstairs,\r\nMannargudi.', 'Registered & Head Office: Perumbalur.', '', '15-Dec-2012', '', '', '', '1355575564898217630'),
(522, 'General Services', 'Beauty Parlours', 'Anu Beauty Parlour', '94435 08212', 'New Bypass Road,\r\nMannargudi.\r\n', 'Proprietor:  R.Anu, Aroma Threapist.\r\nNormal and Aroma Thepeutical treatments given to all Hair & Skin problems.', '', '19-Dec-2012', '', '', '', '1355895680541242187'),
(523, 'Business', 'Agencies', 'Udaya Agencies', '90425 64385', '14,12 Town Bus Stand,\r\nSandapettai, Mannargudi.', 'Paper Plates, Paper Napkins, Toilet Paper Rolls, Table Sheet Papers, Tea Cups, Plastic Spoons, Carry Bags, PP Cover, Silver Plates, Banana Leaf Plates, Big Pepsi Cups', '', '02-Jan-2013', 'Paper Plates, Paper Cups, Carry Bags, Plates', '', '', '1357102454639832564'),
(524, 'Business', 'Photo Studios', 'Siva Videos & Digital Studio  (Lazer Color Lab)', '220185  /   93440 10195', 'Opp.Dr. Karunakaran Clinic,\r\nBus Stanad Road,\r\nMannargudi.', '', '', '02-Jan-2013', 'Color Labs', 'sivadigitalvideo@gmail.com', '', '1357104446132636480'),
(525, 'Business', 'Printing Press', 'Dileepan Printers', '92444 09050', 'Natesan Street,\r\nNear Bus Stand,\r\nMannargudi.', '', '', '02-Jan-2013', '', '', '', '1357104670275604617'),
(526, 'Building Construction', 'Real Estate', 'Roopa Promoters', '95858 05005 / 95858 04666 / 91714 22294', 'No.25, Annavasal Street, \r\nMannargudi.', 'Bank Loan Arrangement, Land Buying and Selling', '', '02-Jan-2013', 'Land, Buying, Selling, Loan', 'roopapromoters@yahoo.com', '', '1357104944468407554'),
(527, 'Travels', 'Travel Agencies', 'Roopa Cars', '95858 05005 / 95858 04666 / 96555 73366', 'No, 25, Annavasal Street,\r\nMannargudi.', 'All Two & Four Wheelers Buying and Selling', '', '02-Jan-2013', 'Car, Buying, Selling, Two Wheelers, Four Wheelers', 'roopacars@yahoo.com', '', '1357105246760133433'),
(528, 'Business', 'Marriage Halls', 'Sundaram Subra Mahal', '', 'Opp. American dental Clinic,\r\n6, Third Street East,\r\nMannargudi.', '', '', '06-Jan-2013', '', '', '', '1357453222368137733'),
(529, 'Business', 'Flex Boards and Stickers', 'Ayyan Flex and Graphics', '98424 36226', '22, Rukmani Palayam Road,\r\nOpp. Sami Theatre,\r\nMannargudi.', 'Flex Boards, Sticker Printing, Wedding Invitations,\r\nVisiting Cards and Posters.', '', '10-Jan-2013', '', '', '', '1357829669467500571'),
(530, 'Building Construction', 'Real Estate', 'Mepco City Developers', '92451 22998  /  98943 32391', '21, Kamal Nagar,\r\nNear Dr.Sekar Clinic,\r\nMannargudi.', 'Plots available near Savalakkaaran in the Mannargudi to Thiruvarur Main road on installment\r\nbasis.', '', '10-Jan-2013', '', '', '', '13578299991147907676'),
(531, 'Business', 'Marriage Halls', 'N.S.A  Thirumana Mandapam', '', '56, Vinobaji Street,\r\nVeera Silks Backside,\r\nMannargudi.', '', '', '10-Jan-2013', '', '', '', '1357830179999107401'),
(533, 'Building Construction', 'Real Estate', 'Archana Real Consulting', '98427 30877  /  98420 86278  /  94427 68022', '7, Bala Krishna Nagar,\r\nMannargudi.', 'Prop: U.Chengutuvan.', '', '18-Jan-2013', '', '', '', '1358508491118121176'),
(534, 'Business', 'Drinking Water Suppliers', 'G.R. Agencies', '94878 30323', '3, Ponnu Samy  Nagar,\r\nMannargudi.', 'Mineral Water Available in all quantities like \r\n20Lt,1Lt,500ml,300ml and also in water packets.', '', '21-Jan-2013', '', '', '', '1358770522461397138'),
(535, 'Business', 'Broilers, Fish, Beef and Mutton Stalls', 'T.M.S. Broilers', '97153 78480', 'Thiruthuraipoondi Road,\r\nMannargudi.', '', '', '08-Feb-2013', '', '', '', '13603216361222924667');

-- --------------------------------------------------------

--
-- Table structure for table `sal_admin`
--

CREATE TABLE IF NOT EXISTS `sal_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `sal_admin`
--

INSERT INTO `sal_admin` (`id`, `username`, `password`) VALUES
(1, 'salnazi', 'splender84');

-- --------------------------------------------------------

--
-- Table structure for table `sal_banner_updates`
--

CREATE TABLE IF NOT EXISTS `sal_banner_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bannername` varchar(255) NOT NULL,
  `bannerimage` varchar(255) NOT NULL,
  `banner_homepage` varchar(255) NOT NULL,
  `rand_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `sal_banner_updates`
--

INSERT INTO `sal_banner_updates` (`id`, `bannername`, `bannerimage`, `banner_homepage`, `rand_id`) VALUES
(1, 'http://www.hi5matrimony.mannaiadvertising.com', 'topbanners/399matri1.jpg', 'jmv.mannaiadvertising.com', '6545123123123'),
(2, 'http://www.hi5webdesign.com', 'topbanners/41123banner 0006.jpg', 'dhanam.mannaiadvertising.com', '787451113212'),
(3, 'Banner 3', 'topbanners/16popopo.jpg', '', '654651231321'),
(4, 'http://jmv.mannaiadvertising.com', 'topbanners/117010681295jeya copy.JPG', '', '8465112313'),
(5, 'Banner 5', 'topbanners/95Pink Lady.jpg', '', '65465416484564'),
(6, 'Banner 6', 'topbanners/923130rty copy.jpg', '', '85411313132123'),
(7, 'http://store.hi5webdesign.com', 'topbanners/126599banner 0005.jpg', '', '65456123123'),
(8, 'Banner 8', 'topbanners/1954case.jpg', '', '445456465456454'),
(9, 'Banner 9', '', '', '6454564654'),
(10, 'Banner 10', '', '', '654651564465456465'),
(11, 'Banner 11', '', '', '7465456141416'),
(12, 'Banner 12', '', '', '654564564564564'),
(13, 'Banner 13', '', '', '985449789789'),
(14, 'Banner 14', '', '', '979878945'),
(15, 'Banner 15', '', '', '89794564564');

-- --------------------------------------------------------

--
-- Table structure for table `sal_cinema_updates`
--

CREATE TABLE IF NOT EXISTS `sal_cinema_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `theatre` varchar(255) NOT NULL,
  `filmname` varchar(255) NOT NULL,
  `filmdetails` text NOT NULL,
  `filmpic` varchar(255) NOT NULL,
  `rand_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `sal_cinema_updates`
--

INSERT INTO `sal_cinema_updates` (`id`, `theatre`, `filmname`, `filmdetails`, `filmpic`, `rand_id`) VALUES
(1, 'Sami Theatre', 'Poda Podi', 'Simbu,Varalaxmi\r\n', 'cinema/722poda.jpg', '1335712692304949797'),
(2, 'Shanthi Theatre', 'Thuppakhi', 'Vijay,Kajal Agarwal', 'cinema/243thu.jpg', '2342423543563456');

-- --------------------------------------------------------

--
-- Table structure for table `sal_counterips`
--

CREATE TABLE IF NOT EXISTS `sal_counterips` (
  `ip` varchar(15) NOT NULL,
  `visit` datetime NOT NULL,
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sal_counterips`
--

INSERT INTO `sal_counterips` (`ip`, `visit`) VALUES
('173.252.120.119', '2014-05-04 10:12:02'),
('66.249.73.170', '2014-05-04 10:11:51'),
('109.163.234.4', '2014-05-04 10:11:08');

-- --------------------------------------------------------

--
-- Table structure for table `sal_counters`
--

CREATE TABLE IF NOT EXISTS `sal_counters` (
  `id` bigint(11) NOT NULL,
  `day_id` bigint(11) NOT NULL,
  `day_value` bigint(11) NOT NULL,
  `yesterday_id` bigint(11) NOT NULL,
  `yesterday_value` bigint(11) NOT NULL,
  `week_id` bigint(11) NOT NULL,
  `week_value` bigint(11) NOT NULL,
  `month_id` bigint(11) NOT NULL,
  `month_value` bigint(11) NOT NULL,
  `year_id` bigint(11) NOT NULL,
  `year_value` bigint(11) NOT NULL,
  `all_value` bigint(11) NOT NULL,
  `record_date` datetime NOT NULL,
  `record_value` bigint(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sal_counters`
--

INSERT INTO `sal_counters` (`id`, `day_id`, `day_value`, `yesterday_id`, `yesterday_value`, `week_id`, `week_value`, `month_id`, `month_value`, `year_id`, `year_value`, `all_value`, `record_date`, `record_value`) VALUES
(1, 123, 24, 122, 49, 18, 266, 5, 162, 2014, 2277, 20140, '2013-03-02 23:50:10', 296);

-- --------------------------------------------------------

--
-- Table structure for table `sal_main_category`
--

CREATE TABLE IF NOT EXISTS `sal_main_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `rand_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category` (`category`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `sal_main_category`
--

INSERT INTO `sal_main_category` (`id`, `category`, `date`, `rand_id`) VALUES
(1, 'Business', '24-Apr-2012', '1335250430988618838'),
(2, 'Entertainments', '24-Apr-2012', '1335250436817155276'),
(3, 'Hospitals and Medicals', '24-Apr-2012', '1335250454318211756'),
(4, 'Education', '24-Apr-2012', '1335256667427961999'),
(5, 'Building Construction', '24-Apr-2012', '133525667664350740'),
(6, 'Banks', '24-Apr-2012', '13352566881075009950'),
(7, 'Employment', '24-Apr-2012', '1335256714723756425'),
(8, 'Travels', '24-Apr-2012', '1335256723457952111'),
(9, 'Agriculture', '24-Apr-2012', '1335256736941297759'),
(10, 'General Services', '24-Apr-2012', '1335280340978936102'),
(11, 'Automobiles', '04-May-2012', '133611115688275012'),
(12, 'Hotels, Lodges and Restaurants', '04-May-2012', '13361111741155749659');

-- --------------------------------------------------------

--
-- Table structure for table `sal_newsletters`
--

CREATE TABLE IF NOT EXISTS `sal_newsletters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `rand_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=85 ;

--
-- Dumping data for table `sal_newsletters`
--

INSERT INTO `sal_newsletters` (`id`, `sname`, `email`, `rand_id`) VALUES
(1, 'Salnazi', 'salnazi@gmail.com', '1336293043607008780'),
(2, 'A.M.Rafik', 'amrafik@ymail.com', '1336293152743688621'),
(3, 'musthafa', 'mrt.musthafa@yahoo.co.in', '1337238629879456706'),
(4, 'halildubai', 'halilulishaq@gmail.com', '13373215951051570425'),
(5, 'bdlqslywe', 'nlggyl@wgjhoc.com', '1342022896371980325'),
(6, 'tbbddpds', 'mgcphb@sibfey.com', '13447649671194030760'),
(7, 'faizal mohamed', 'faisal_s79@yahoo.com', '13466677781164664016'),
(8, 'vinoth', 'vinothkumar572@ymail.com', '134953396688966199'),
(9, 'Salahudeen', 'salahbdm@yahoo.ie', '13514902051063828857'),
(10, 'muthu balaji', 'muthubalaji90@gmail.com', '13539086851209181008'),
(11, 'bupqjrh', 'uiqiyw@nqxmzp.com', '1358599901313801485'),
(12, 'Vijayadhithan ', 'ojsjv@yahoo.com', '135878484393156450'),
(13, 'pgsudfjkf', 'vhlhqn@pmspjt.com', '1359370274270906938'),
(14, 'pkqkvfgzr', 'kdjyrh@gfaxfx.com', '1359370849932396138'),
(15, 'hozonuxgv', 'cugdvn@hmtypj.com', '1359371039846709621'),
(16, 'Pandiyan selliyan', 'Pandiyan658@gmail.com', '13614996321083612203'),
(17, 'horny', 'dbfuzz@hotmail.com', '13623816801038026416'),
(18, 'patrik', 'normy273@hotmail.com', '1362903836723080581'),
(19, 'Molly', 'john@hotmail.com', '1363116044314399803'),
(20, 'Emma', 'unlove@gmail.com', '1363116047477808540'),
(21, 'rikky', 'john@hotmail.com', '1363116051548434083'),
(22, 'Jake', 'rikky@aol.com', '1363116053372797474'),
(23, 'Jane', 'goodboy@yahoo.com', '13631160551080204032'),
(24, 'Ashton', 'incomeppc@hotmail.com', '1363116059387386199'),
(25, 'Nathaniel', 'kidrock@msn.com', '1363116066420506916'),
(26, 'Cameron', 'coolman@msn.com', '1363116068895402158'),
(27, 'Jayden', 'kidrock@msn.com', '1363116069595597733'),
(28, 'Jenna', 'unlove@gmail.com', '1363116070330059779'),
(29, 'flyman', 'razer22@yahoo.com', '1363359065125470039'),
(30, 'Anthony', 'razer22@yahoo.com', '1363359069325046998'),
(31, 'Audrey', 'flyman@gmail.com', '1363359076332057049'),
(32, 'Brooklyn', 'incomeppc@hotmail.com', '1363359077575189672'),
(33, 'Tyler', 'crazyfrog@hotmail.com', '1363359081902382197'),
(34, 'Jose', 'dogkill@yahoo.com', '1363359083868085720'),
(35, 'Erin', 'coco888@msn.com', '1363359085856649730'),
(36, 'Carson', 'crazyfrog@hotmail.com', '1363359088431723983'),
(37, 'Elijah', 'kidrock@msn.com', '1363359091788618457'),
(38, 'kidrock', 'pitfighter@hotmail.com', '13633590981112494321'),
(39, 'Rachel', 'crazyivan@yahoo.com', '1363599462251129856'),
(40, 'Noah', 'john@hotmail.com', '13635994671225343496'),
(41, 'Steven', 'lightsoul@gmail.com', '1363599475958187060'),
(42, 'Grace', 'steep777@yahoo.com', '13635994777224085'),
(43, 'Genesis', 'quaker@yahoo.com', '13635994801089860675'),
(44, 'Cameron', 'coolman@msn.com', '136359948672198993'),
(45, 'Mishel', 'eblanned@yahoo.com', '1363599489757893422'),
(46, 'Isaac', 'unlove@gmail.com', '13635994911066486320'),
(47, 'Caleb', 'steep777@yahoo.com', '1363599493679533816'),
(48, 'Kimberly', 'cooler111@yahoo.com', '1363599495580509246'),
(49, 'Audrey', 'pitfighter@hotmail.com', '1363852909677189360'),
(50, 'Austin', 'rikky@aol.com', '1363852911406011753'),
(51, 'Eva', 'lightsoul@gmail.com', '1363852916768077552'),
(52, 'Brandon', 'coolman@msn.com', '1363852918478826541'),
(53, 'Cameron', 'quaker@yahoo.com', '13638529241160615266'),
(54, 'Cooper', 'lightsoul@gmail.com', '1363852926947128732'),
(55, 'Christian', 'pitfighter@hotmail.com', '1363852929813975080'),
(56, 'Ryan', 'freelife@yahoo.com', '1363852935362217412'),
(57, 'Sofia', 'fifa55@yahoo.com', '1363852938282879199'),
(58, 'Maria', 'dogkill@yahoo.com', '1363852941238458547'),
(59, 'Alexandra', 'kidrock@msn.com', '1364069679693548160'),
(60, 'Destiny', 'goodsam@gmail.com', '1364069686623015202'),
(61, 'Jason', 'quaker@yahoo.com', '13640696911198130555'),
(62, 'Diva', 'fifa55@yahoo.com', '136406970212209307'),
(63, 'Khloe', 'heyjew@msn.com', '1364069707576530147'),
(64, 'Brooke', 'cooler111@yahoo.com', '1364069719355234456'),
(65, 'Ella', 'goodboy@yahoo.com', '1364069725701002926'),
(66, 'Elizabeth', 'razer22@yahoo.com', '1364069729606557343'),
(67, 'Ariana', 'coco888@msn.com', '136406973899405699'),
(68, 'Layla', 'nogood87@yahoo.com', '1364069743372717465'),
(69, 'ldegngwjh', 'lfousk@wpghyx.com', '1364297756812195359'),
(70, 'Aiden', 'dirtbill@yahoo.com', '1364500205601222488'),
(71, 'Isaiah', 'nogood87@yahoo.com', '1364500209334145380'),
(72, 'Isabelle', 'crazyivan@yahoo.com', '1364500215802757026'),
(73, 'Paige', 'behappy@yahoo.com', '13645002231069698422'),
(74, 'Justin', 'lightsoul@gmail.com', '1364500230654479641'),
(75, 'Daniel', 'lightsoul@gmail.com', '1364500236223700674'),
(76, 'Michael', 'john@hotmail.com', '13645002431225592717'),
(77, 'Richard', 'friend35@hotmail.com', '13645002481149114345'),
(78, 'Josiah', 'unlove@gmail.com', '13645002561157123269'),
(79, 'Caden', 'freelife@yahoo.com', '1364500262919176461'),
(80, 'Danielle', 'behappy@yahoo.com', '136490263213920821'),
(81, 'Mike', 'crazyfrog@hotmail.com', '13649026341144518253'),
(82, 'Natalie', 'deadman@gmail.com', '1364902638821987574'),
(83, 'Amber', 'quaker@yahoo.com', '13649026475917009'),
(84, 'Aaliyah', 'cooler111@yahoo.com', '13649026501109841392');

-- --------------------------------------------------------

--
-- Table structure for table `sal_rating`
--

CREATE TABLE IF NOT EXISTS `sal_rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `total_votes` varchar(255) NOT NULL,
  `total_value` varchar(255) NOT NULL,
  `used_ips` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `sal_rating`
--

INSERT INTO `sal_rating` (`id`, `total_votes`, `total_value`, `used_ips`) VALUES
(2, '58', '168', 'a:6:{i:0;s:13:"74.105.162.32";i:1;s:14:"37.228.105.131";i:2;s:14:"182.65.190.175";i:3;s:15:"117.213.113.138";i:4;s:14:"37.228.106.210";i:5;s:14:"37.228.106.207";}');

-- --------------------------------------------------------

--
-- Table structure for table `sal_sub_category`
--

CREATE TABLE IF NOT EXISTS `sal_sub_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `sub_category` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `rand_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sub_category` (`sub_category`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=140 ;

--
-- Dumping data for table `sal_sub_category`
--

INSERT INTO `sal_sub_category` (`id`, `category`, `sub_category`, `date`, `rand_id`) VALUES
(2, 'Business', 'Mobile Shops', '24-Apr-2012', '133525400516087760'),
(3, 'Business', 'Computer Shops', '24-Apr-2012', '1335254016301508'),
(4, 'Business', 'Electronics Showrooms', '24-Apr-2012', '1335254026343643069'),
(5, 'Entertainments', 'Theatres', '24-Apr-2012', '13352540381020191342'),
(7, 'Employment', 'Recruitment Consultancy', '24-Apr-2012', '1335256761133448559'),
(8, 'Employment', 'Job Wanted', '24-Apr-2012', '1335256774697722296'),
(9, 'Employment', 'Job Offered', '24-Apr-2012', '13352567921227484799'),
(10, 'Employment', 'Other Services', '24-Apr-2012', '1335256801896048860'),
(11, 'Banks', 'Banks', '24-Apr-2012', '1335256812314218098'),
(12, 'Banks', 'ATM Centres', '24-Apr-2012', '1335256820378455710'),
(14, 'Education', 'Schools', '24-Apr-2012', '1335256949930861501'),
(16, 'Banks', 'Finance Co', '24-Apr-2012', '1335280036466127807'),
(17, 'General Services', 'Electricians - Plumbers', '24-Apr-2012', '1335280356285320591'),
(19, 'General Services', 'Mason', '24-Apr-2012', '1335280379873895360'),
(20, 'Banks', 'Money Transfer', '24-Apr-2012', '13352807261038162803'),
(22, 'Education', 'Tutorials', '24-Apr-2012', '13352808841089364513'),
(23, 'Education', 'ITI', '24-Apr-2012', '13352808901217387626'),
(24, 'Education', 'Polytechnic', '24-Apr-2012', '13352809001215918261'),
(25, 'Agriculture', 'Fertilizer - Pesticide Dealers', '24-Apr-2012', '1335280975911571380'),
(26, 'Agriculture', 'Seed Dealers', '24-Apr-2012', '1335280987848765456'),
(27, 'Building Construction', 'Civil Engineers', '24-Apr-2012', '1335281013110541539'),
(28, 'Building Construction', 'Real Estate', '24-Apr-2012', '133528102252708850'),
(29, 'Building Construction', 'Building Contractors', '24-Apr-2012', '1335281030674099432'),
(32, 'Travels', 'Tourist Buses, Vans and Cars', '24-Apr-2012', '133528106920006066'),
(39, 'Business', 'Textile and Readymades', '25-Apr-2012', '1335328863641660379'),
(40, 'Business', 'Hardware Shops', '25-Apr-2012', '1335328887363649035'),
(41, 'Education', 'Arts and Science', '26-Apr-2012', '13354497811054250464'),
(42, 'Education', 'Teacher Training', '26-Apr-2012', '1335449988301295224'),
(43, 'Automobiles', 'Motor Showrooms', '26-Apr-2012', '1335450189736905355'),
(44, 'Business', 'Maligai Stores', '26-Apr-2012', '1335450209251525202'),
(45, 'Business', 'Photo Studios', '26-Apr-2012', '1335450221952336832'),
(46, 'Business', 'Browsing Centres', '26-Apr-2012', '1335450230778311300'),
(47, 'Business', 'Service Providers', '26-Apr-2012', '1335450259694557510'),
(48, 'Hospitals and Medicals', 'Medical Stores', '26-Apr-2012', '1335450403651041708'),
(49, 'Business', 'Book Stores', '26-Apr-2012', '13354504251058281798'),
(50, 'Business', 'Sports Goods', '26-Apr-2012', '1335450440675079008'),
(51, 'Business', 'Gold Covering Stores', '26-Apr-2012', '1335450462939150225'),
(53, 'Automobiles', 'Tyre Showrooms', '26-Apr-2012', '1335450496428790872'),
(54, 'Business', 'Sweet Stalls', '26-Apr-2012', '1335450505656240999'),
(55, 'Automobiles', 'Service Stations', '26-Apr-2012', '1335450562506177415'),
(56, 'Business', 'Metals and Furnitures', '26-Apr-2012', '1335450910486284477'),
(57, 'Business', 'Battery Sellers', '26-Apr-2012', '1335451079242068522'),
(60, 'Business', 'Printing Press', '27-Apr-2012', '13355107311003011078'),
(61, 'Business', 'Marriage Halls', '27-Apr-2012', '1335510742881279860'),
(62, 'General Services', 'LIC and Insurance Agents', '27-Apr-2012', '133551076893285923'),
(63, 'Business', 'Broilers, Fish, Beef and Mutton Stalls', '27-Apr-2012', '1335511186525241481'),
(65, 'Hospitals and Medicals', 'Clinics', '27-Apr-2012', '13355119321135216228'),
(66, 'Hospitals and Medicals', 'Doctors', '27-Apr-2012', '1335511940843340109'),
(67, 'Business', 'Opticals', '27-Apr-2012', '1335527793254200200'),
(68, 'Business', 'Solar Power Systems', '29-Apr-2012', '1335672942572713265'),
(70, 'Business', 'General Merchants', '29-Apr-2012', '1335705355616006828'),
(71, 'Travels', 'Drivers', '29-Apr-2012', '1335711311135690408'),
(72, 'Travels', 'Travel Agencies', '29-Apr-2012', '1335715920862705149'),
(73, 'Business', 'Tailors', '29-Apr-2012', '1335717109257658110'),
(74, 'General Services', 'Marriage Cooks', '29-Apr-2012', '1335718021306877412'),
(75, 'Business', 'Decoration Centres', '29-Apr-2012', '1335718220629530706'),
(79, 'Business', 'Electrical Stores', '30-Apr-2012', '13357782251105982976'),
(80, 'Business', 'Other Category', '30-Apr-2012', '1335799065938434355'),
(81, 'Business', 'Spare Parts stores', '01-May-2012', '1335870431181461272'),
(82, 'Hospitals and Medicals', 'Blood Testing,E.C.G. - X-Rays Centers', '01-May-2012', '1335872962731928542'),
(83, 'Business', 'Gas Agencies', '01-May-2012', '1335891759899409703'),
(84, 'Business', 'Pets and Aquarium', '01-May-2012', '1335891925849938454'),
(85, 'Business', 'News Paper Agents', '02-May-2012', '1335976930849292920'),
(86, 'General Services', 'Others', '03-May-2012', '1336044474217202349'),
(87, 'Business', 'Coir Merchants', '03-May-2012', '1336044803523583736'),
(89, 'Business', 'Steel Company', '03-May-2012', '1336046592600555843'),
(90, 'Business', 'Shoe Marts', '03-May-2012', '1336047937844922502'),
(91, 'Business', 'Fancy Stores', '03-May-2012', '1336048260432671502'),
(92, 'Hotels, Lodges and Restaurants', 'Hotels', '03-May-2012', '133605181940727876'),
(93, 'Automobiles', 'Motor Mechanics', '03-May-2012', '1336052645481424270'),
(94, 'General Services', 'Painters', '03-May-2012', '1336053232794172904'),
(95, 'Business', 'Welding Workshops', '03-May-2012', '1336053403649911427'),
(96, 'Automobiles', 'Auto Spare Parts', '03-May-2012', '1336057076702394122'),
(98, 'Business', 'Jewellery Shops', '03-May-2012', '1336057541313200846'),
(99, 'Building Construction', 'Constuction Suppliers', '03-May-2012', '1336057936208423837'),
(100, 'Education', 'Paramedical Colleges', '03-May-2012', '1336058537107941894'),
(101, 'Business', 'Tiles and Granites', '04-May-2012', '13361081831231478457'),
(102, 'Business', 'Courier Service', '04-May-2012', '1336109471760189135'),
(103, 'Hospitals and Medicals', 'Health Services', '04-May-2012', '13361099091089063105'),
(104, 'Hotels, Lodges and Restaurants', 'Lodges', '04-May-2012', '133611214886843323'),
(106, 'Travels', 'Driving Schools', '04-May-2012', '1336112475518346769'),
(107, 'Banks', 'Private Bankers', '04-May-2012', '1336112564603645276'),
(108, 'Entertainments', 'Music Band - Orchestra', '04-May-2012', '1336116909841267928'),
(110, 'Business', 'Flex Boards and Stickers', '05-May-2012', '133619733366196865'),
(112, 'Business', 'Department Stores', '05-May-2012', '1336200323847635175'),
(113, 'General Services', 'Laundry', '05-May-2012', '1336200506288183969'),
(114, 'Building Construction', 'Cement Dealers', '05-May-2012', '13362005551211133407'),
(115, 'Business', 'Rice Suppliers ( Arisi Mandy )', '05-May-2012', '1336201082792251427'),
(116, 'Entertainments', 'Sound Services', '05-May-2012', '1336201551368848326'),
(117, 'General Services', 'Engineering Works', '05-May-2012', '1336201706621239977'),
(118, 'Business', 'Rice Mills', '05-May-2012', '1336202149623764270'),
(119, 'General Services', 'Rewinding Works', '05-May-2012', '1336202259572750941'),
(121, 'Business', 'Agencies', '05-May-2012', '1336202991266369554'),
(122, 'General Services', 'Saloons', '05-May-2012', '13362041441227899235'),
(124, 'Agriculture', 'Agri. Equipments', '05-May-2012', '1336223434552669622'),
(125, 'General Services', 'Govt. Offices', '05-May-2012', '13362234951013447335'),
(126, 'General Services', 'Beauty Parlours', '14-May-2012', '13369342101054605060'),
(127, 'Hotels, Lodges and Restaurants', 'Restaurants', '14-May-2012', '1336984832191512863'),
(131, 'Business', 'Cycle Company', '20-May-2012', '1337529429493304887'),
(132, 'Business', 'Xerox Shops', '21-May-2012', '13376041471006399304'),
(133, 'General Services', 'Auto Electrical Works', '21-May-2012', '133760444077570586'),
(134, 'Agriculture', 'Agri Clinic and Research', '21-May-2012', '1337605005554326024'),
(135, 'Business', 'Drinking Water Suppliers', '13-Oct-2012', '1350126574176020013'),
(136, 'Entertainments', 'TV and Media', '17-Nov-2012', '1353127119163936426'),
(137, 'Business', 'Imports and Exports', '17-Nov-2012', '1353128162893291544'),
(138, 'Business', 'Traders', '20-Nov-2012', '1353421845402795675'),
(139, 'Business', 'Juice Centers', '13-Dec-2012', '1355374031342990422');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
