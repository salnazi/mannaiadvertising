<?php
include("config/host.php");
$sql = mysqli_query($_Conn, "select * from $sal_add_com where id");
while($r = mysqli_fetch_object($sql))
{
//echo $r->rand_id;
echo substr($r->rand_id, 14, -1);
echo "<br>";
//for($i=1000; $i<=1500; $i++)
//{
//$id = $i;
//echo "insert into $sal_add_com (ad_id,category, sub_category, title, phone, address,otherinfo, pic, date, tags,email, website, rand_id) values ('$id','$r->category', '$r->category', '$r->title' , '$r->phone', '$r->address', '$r->otherinfo', '$r->target_path', '$r->date', '$r->tags','$r->email', '$r->website', '$r->rand_id')"."<br>";
//}
}
?>