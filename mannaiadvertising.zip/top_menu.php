   <h1>MannaiAdvertising</h1>
	<p style='color:white;font-size:18px;font-weight:bold;font-family:calibri;margin-top:0px;'>Email Us <br> mannaiadvertising@gmail.com </p>

    <ul style='margin-left:550px;position:absolute;'>
      <a href="index.php" id='top-menu'>Home</a>
	  <a href="place_your_address.php" id='top-menu'>Post Your Address</a><img src='images/new.gif' style='position:absolute;margin-left:260px;margin-top:-50px;'>
	  <a href="search_address.php" id='top-menu'>Search</a>

      <!-- <li><a href="#">About Us</a></li>
    
      <li class="#"><a href="#">Contacts</a></li> -->
	        </ul>
		
    <br class="clear" />
	
	
	
		  
	  
	  <!-- right side share tool start-->
<!-- AddThis Smart Layers BEGIN -->
<!-- Go to http://www.addthis.com/get/smart-layers to customize -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-4dd48b000226c82b"></script>
<script type="text/javascript">
  addthis.layers({
    'theme' : 'transparent',
    'share' : {
      'position' : 'left',
      'numPreferredServices' : 5
    },  
    'whatsnext' : {},  
    'recommended' : {} 
  });
</script>
<!-- AddThis Smart Layers END -->
<!-- right side share tool end-->

<!-- top slide share tool start-->
<!-- <div class="addthis_bar addthis_bar_medium" style='background:black;height:30px;'>
 <p align='right' style='position:absolute;margin-top:-5px;margin-left:-240px;font-size:40px;font-family:Palatino Linotype;color:white;'><span style='color:rgb(5, 155, 216);'>M</span>annai <span style='color:rgb(5, 155, 216);'>A</span>dvertising </p>
 <!-- <label>Share This Page:</label> -->
	
    <!--<div class="addthis_toolbox addthis_default_style addthis_32x32_style" style='background:black;margin-left:460px;position:absolute;'>
        <span><a class="addthis_button_preferred_1" style='background:black;'></a></span>
        <span><a class="addthis_button_preferred_2" style='background:black;'></a></span>
        <span><a class="addthis_button_preferred_6" style='background:black;'></a></span>
        <span><a class="addthis_button_preferred_5" style='background:black;'></a></span>
        <span><a class="addthis_button_compact" style='background:black;'></a></span>
        <span><a class="addthis_counter addthis_bubble_style" style='background:black;'></a></span>
    </div>
</div> -->
<!-- <script type="text/javascript">
var addthis_config = {
    bar_show_below : 150
}
</script>  -->

<!-- <script type="text/javascript" src="http://s7.addthis.com/js/300/addthis_widget.js#pubid=ra-4f98efb84a28bb47"></script> -->
<!-- top slide share tool end-->






