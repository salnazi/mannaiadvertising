<!--<ul id="featurednews" >-->
<?php 
/*
include("config/host.php");
$sql = mysqli_query($_Conn, "Select * from $sal_banner_updates where id");
while($r = mysqli_fetch_object($sql))
{
if($r->bannerimage != "")
{
echo "<li ><img src='webadmin/$r->bannerimage' alt='$r->bannerimage' />";
            echo "<div class='panel-overlay' style='color:white;'>";
           echo "   <h2></h2>";
              echo "<p align='right'><br />";
                echo "<a href='#' style='color:white;'> To Advertise Here... Contact: info@mannaiadvertising.com &raquo;</a></p>";
            echo "</div>";
          echo "</li>";
		  }
		  }
		  */
		  ?>
		  
<div style='margin-left:470px;'>


<?php
error_reporting(0);
    $extensions = array('jpg','jpeg');
    $images_folder_path = "images/top banners/";
    $images = array();
    srand((float) microtime() * 1000);

    if ($handle = opendir($images_folder_path)) {
        while (false !== ($file = readdir($handle))) {
            if ($file != "." && $file != "..") {
                $ext = strtolower(substr(strrchr($file, "."), 1));
                if(in_array($ext, $extensions)){
                $images[] = $file;
                }
            }
        }
    closedir($handle);
    }
    if(!empty($images)){
        $header_image = $images[array_rand($images)];
		echo "<img src='$images_folder_path/$header_image' style='width:955px;height:300px;border-radius: 5px 20px 5px;border-radius: 10px/20px; border: 1px solid #BADA55;' alt='$header_image'/>";
    } else {
        $header_image = ''; 
    }
	
?>




<?php
/*
$dir = "images/top banners";
$images = scandir($dir);
$i = rand(3, sizeof($images)-1);
*/
?>
	<!--	<img src='<?php //echo $dir; ?>/<?php // echo $images[$i]; ?>' style='width:960px;height:300px;border-radius:3px;'/>-->


		 
		  </div>
		          <!--</ul>-->
		