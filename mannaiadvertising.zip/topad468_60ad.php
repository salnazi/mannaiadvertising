<div class="fl_left"><a href="#"><img src="images/topadbanner.jpg" alt="" /></a></div>
    <div class="fl_right"><a href="#"><img src="images/topadbanner.jpg" alt="" /></a></div>
    <br class="clear" />