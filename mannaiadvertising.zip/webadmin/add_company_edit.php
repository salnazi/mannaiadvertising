<?php
error_reporting(0);
session_start();
if($_SESSION['user'])
{

?>
<br><br>
<?php
error_reporting(0);
ob_start();
session_start();
if($_POST['cancel'] == "Cancel")
header("Location:m_index.php?id=add_company"); 

include('config/host.php');

$r_rand = $_POST['rand'];
$category = $_POST['category'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$email = $_POST['email'];
$website = $_POST['website'];
$otherinfo = $_POST['otherinfo'];
$tags = $_POST['tags'];
$title = htmlspecialchars($_POST['title']);
$sub_category = $_POST['sub_category'];
$date = $_POST['date'];
$pic = "";
//include ("rand_id.php");
if($_POST['update'] == "Update")
{
$sql = mysqli_query($_Conn, "UPDATE $sal_add_com SET category = '$category' ,sub_category = '$sub_category' , title = '$title', phone = '$phone',address = '$address',otherinfo = '$otherinfo', pic = '$pic',date = '$date', tags = '$tags',email = '$email', website = '$website' WHERE rand_id = '$r_rand'");
echo "<script type='text/javascript'> alert('File has been updated'); window.location='m_index.php?id=add_company' ; </script>";
}
if($_POST['submit'] == "Update" && $title == "")
{
echo "<span id='update'>Error</span>";
}
ob_end_flush();
?>
<?php
}
else
{
header("Location:index.php");
}
?>