<html>
<head>
<script type="text/javascript">
function showHint(str)
{
  var xmlhttp;
  if (str.length==0)
  { 
    document.getElementById("txtHint").innerHTML="";
    return;
  }
  if (window.XMLHttpRequest)
  {  
     // code for IE7+, Firefox, Chrome, Opera, Safari
     xmlhttp=new XMLHttpRequest();
  }
  else
  {  
     // code for IE6, IE5
     xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function()
  {
    if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","name_suggestions.php?q="+str,true);
  xmlhttp.send();
}
</script>
</head>
<body>

<form action=""> 
Start typing: <input type="text" id="txt1" onkeyup="showHint(this.value)" />
</form>
<p style="font-size:11px;"><span id="txtHint"></span></p> 

</body>
</html>

<?php
include("config/host.php");
$sql = mysql_connect("select * from $sal_add_com");
while($r = mysqli_fetch_object($sql))
{
$a[] = $r->title;
}

//get the 'query' variable from the URL
$q = $_GET["q"];

//lookup all hints from array if length of q > 0
if (strlen($q) > 0)
{
  $hint="";
  for($i=0; $i<count($a); $i++)
  {
    if (strtolower($q)==strtolower(substr($a[$i],0,strlen($q))))
    {
      if ($hint=="")
      {
        $hint = $a[$i];
      }
      else
      {
        $hint = $hint." <br> ".$a[$i];
      }
    }
  }
}

// if there are no suggestions, set response to 'n/a'
// otherwise, output all suggestions
if ($hint == "")
{
  $response = "n/a";
}
else
{
  $response = $hint;
}

//output the response
print $response;
?>
