<head>
<script LANGUAGE="JavaScript">

function confirmDelete()
{
var agree=confirm("Are you sure you want to delete?");
if (agree)
return true ;
else
return false ;
}

</script>
</head>
<br>
<?php
error_reporting(0);
session_start();
if($_SESSION['user'])
{
?>

<?php

if(isset($_POST['edit']) || isset($_POST['edit_x']))
{
$nbannername = $_POST['nbannername'];
$nbannerimage = $_POST['nbannerimage'];
$nrand = $_POST['nrand'];

 
 ?>
 	<form action="banner_updates_edit.php" method="POST" enctype="multipart/form-data">
  <input type="hidden" name="rand" size="45" value='<?php echo $nrand; ?>' >
  <input type="hidden" name="bannername" size="45" value='<?php echo $nbannername; ?>' >
     <input type="hidden" name="bannerimage" size="45" value='<?php echo $nbannerimage; ?>' >
 <br><br><table border=0 cellpadding=10 cellspacing=10>
<tr><td colspan=2 style='text-align:center;'><h1>Banner Updates</h1></td></tr>

<tr><td>Banner</td><td><input type='text' name='bannername' value='<?php echo $nbannername; ?>'></td></tr>
<tr><td>Upload Banner</td><td><input type='file' name='uploadedfile'></td></tr>
<tr><td colspan=2 align=center><input type='submit' name='update' value="Update"> &nbsp; <input type='submit' name='clear' value="Clear"></td></tr>
</table>
</form>
<?php
}

//delete 
if(isset($_POST['delete']) || isset($_POST['delete_x']))
{
$nrand = $_POST['nrand'];
mysqli_query($_Conn, "DELETE FROM $sal_banner_updates where rand_id='$nrand'");
echo "<script type='text/javascript'> alert('1 Row has been deleted'); window.location='m_index.php?id=cinema_updates' ; </script>";
}


?>
<br><br>


<?php
// Search
$sub_id = $_GET['id'];
$al_id = strtolower(substr($sub_id, -1));
$query_sql = mysqli_query($_Conn, "select * from $sal_banner_updates where id ");
echo "<table border=0 cellpadding=10 cellspacing=10 id='show'>";
echo "<tr><td style='background:white;padding:6px;'>Title</td><td style='background:white;padding:6px;'>Banner</td><td colspan=4 align=center style='background:white;text-align:center;'>Option</td></tr>";
while($sr = mysqli_fetch_array($query_sql))
{


$s_rand_id = $sr['rand_id'];
$s_bannername = $sr['bannername'];
$s_bannerimage = $sr['bannerimage'];
echo "<form action='m_index.php?id=banner_updates' method='POST'>";
echo "<input type='hidden' name='nrand' value='$s_rand_id'>";
echo "<input type='hidden' name='nbannername' value='$s_bannername'>";
echo "<input type='hidden' name='nbannerimage' value='$s_bannerimage'>";
echo "<tr class='gradeX'><td >$s_bannername</td><td ><img src='webadmin/../$s_bannerimage' height=60 width=100></td><td><input type='image' alt='EDIT' src='images/edit.png' height='20' width='20' name='edit' value='Edit'><td></td></tr>";
echo "</form>";


}


echo "</table>";
echo "<br><br>";
?>



<?php
}
else
{
header("Location:index.php");
}
?>