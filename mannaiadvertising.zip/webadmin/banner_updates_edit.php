<?php
error_reporting(0);
session_start();
if($_SESSION['user'])
{

?>
<br><br>
<?php
error_reporting(0);
ob_start();
session_start();
if($_POST['cancel'] == "Cancel")
header("Location:m_index.php?id=banner_updates"); 

include('config/host.php');

$r_rand = $_POST['rand'];
$bannername = $_POST['bannername'];
$bannerimage = $_POST['bannerimage'];


//include ("rand_id.php");
if($_POST['update'] == "Update")
{
$randnew = rand(12,2000);

$target_path = "topbanners/".$randnew;

$target_path = $target_path . basename( $_FILES['uploadedfile']['name']); 

//if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) 
//{
move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path);
unlink($bannerimage);
$sql = mysqli_query($_Conn, "update $sal_banner_updates set bannername = '$bannername', bannerimage = '$target_path' where rand_id = '$r_rand'");

echo "<script type='text/javascript'> alert('File has been updated'); window.location='m_index.php?id=banner_updates' ; </script>";
}
//}
if($_POST['submit'] == "Update" && $bannername == "")
{
echo "<span id='update'>Error</span>";
}
ob_end_flush();
?>
<?php
}
else
{
header("Location:index.php");
}
?>