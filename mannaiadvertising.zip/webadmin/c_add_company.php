<head>
<script src="jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
function showHint(str)
{
  var xmlhttp;
  if (str.length==0)
  { 
    document.getElementById("txtHint").innerHTML="";
    return;
  }
  if (window.XMLHttpRequest)
  {  
     // code for IE7+, Firefox, Chrome, Opera, Safari
     xmlhttp=new XMLHttpRequest();
  }
  else
  {  
     // code for IE6, IE5
     xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function()
  {
    if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
	  
    }
  }
  xmlhttp.open("GET","name_suggestions.php?q="+str,true);
  xmlhttp.send();
}
</script>
</head>
<body>
<?php
error_reporting(0);
session_start();
if($_SESSION['user'])
{
?>
<?php
//error_reporting(0);
ob_start();
session_start();
include('config/host.php');
include("company_suggestion.php");
$new_category= $_POST['new_category'];
$sub_category= $_POST['sub_category'];
$title= $_POST['title'];
$email= $_POST['email'];
$website= $_POST['website'];
$otherinfo= $_POST['otherinfo'];
$tags= $_POST['tags'];
$phone= $_POST['phone'];
$address = $_POST['address'];
$date = date("d-M-Y");
include ("rand_id.php");
if($_POST['submit'] == "Save" && $title != "")
{
$sql = mysqli_query($_Conn, "insert into $sal_add_com (category, sub_category, title, phone, address,otherinfo, pic, date, tags,email, website, rand_id) values ('$new_category', '$sub_category', '$title' , '$phone', '$address', '$otherinfo', '$target_path', '$date', '$tags','$email', '$website', '$rand_id')");
$empty="";
mysqli_query($_Conn, "DELETE FROM $sal_add_com where category='$empty'");

echo "<script type='text/javascript'> alert('Successfully Added'); </script>";
}
if($_POST['submit'] == "Save" && $title == "")
{
echo "<span id='update'>Error</span>";
}
ob_end_flush();
?> 
<table border=0 cellpadding=10 cellspacing=20 id="circular">
  <tr>
    <td colspan=2 align=center><h1>Add - Company Profile</h1></td>
  </tr>
  <tr>
    <td>
	
	<form action="c_index.php?id=add_company" method="POST">
      </td>
  </tr>
  <?php
  if($_POST['fetch'] != "Fetch Sub Category")
{
session_start();
include('config/host.php');
echo "<tr><td>Category</td><td>";
echo "<select id='category' name = 'category' style='width:250px;'>";
$sql = mysqli_query($_Conn, "select * from $sal_main_cat");
while($row = mysqli_fetch_array($sql))
{
$cate = $row['category'];
echo "<option value='$cate'>$cate</option>";
}
echo "</select>";

?>

    
    <input type="submit" name="fetch" value="Fetch Sub Category" id="submit"> &nbsp;&nbsp;&nbsp; 
	<?php
	}
	?>
      </td>
  </tr>
</form>
	<form action="c_index.php?id=add_company" method="POST">
 <?php 
 if($_POST['fetch'] == 'Fetch Sub Category')
 {
 include('category_sub_list.php'); 
 ?>
  <tr>
  
    <td >Title</td>
    <td><input type="text" name="title" id="txt1" value='<?php echo $ntitle; ?>' onkeyup="showHint(this.value)" size=50>
	<br>
	<div style="font-size:13px;position:absolute;background:white;border:solid 1px skyblue;width:325px;">
	<span id="txtHint"></span></div> 
	</td>
  </tr>
     <tr>
  <td >Phone No.</td>
    <td><input type="text" name="phone" id='phone' value='<?php echo $nphone; ?>' size=40></td>
  </tr>
  
  <tr><td>Address</td><td><textarea cols=50 rows=4 name="address" id='address'></textarea></td></tr>
<script language="javascript1.2">
  generate_wysiwyg('textarea1');
</script>
  </tr>
  
   <tr><td>Other Info</td><td><textarea cols=50 rows=2 name="otherinfo" id='otherinfo'></textarea></td></tr>
<script language="javascript1.2">
  generate_wysiwyg('textarea1');
</script>
  </tr>
   <td >Tags</td>
    <td><input type="text" name="tags" id='tags' value='<?php echo $ntags; ?>' size=40></td>
  </tr>
    <tr>
	<tr><td colspan=2><b>Optional</b></td></tr>
  <td >Email</td>
    <td><input type="text" name="email" id='email' value='<?php echo $nemail; ?>' size=40></td>
  </tr>
  
    <tr>
  <td >Website</td>
    <td><input type="text" name="website" id='website' value='<?php echo $nwebsite; ?>' size=40></td>
  </tr>
  <tr>   
     <td></td>
    <td><input type="submit" name="submit" value="Save" id="submit"> &nbsp;&nbsp;&nbsp; 
      <input type="submit" name="submit" value="Clear" id="submit"> </td>
  </tr>
  <tr>
  </form>
    <td></td>
  </tr>
  <?php
  }
  ?>
</table>
<?php
}
else
{
header("Location:index.php");
}
?>