<?php
error_reporting(0);
ob_start();
session_start();
if($_SESSION['user'])
{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<?php include("title.php"); ?>
<link rel="stylesheet" type="text/css" href="style.css" />
<script language="JavaScript" type="text/javascript" src="wysiwyg.js">
</script>

</head>

<body>
   <!-- Begin Wrapper -->
   <div id="wrapper">

   
         <!-- Begin Header -->
         <div id="header">
		 
         <div class="top">
		 
		       <?php include ("header_name.php"); ?>		 
			  
		 </div>	
        <div class="headertext">
	                              
<?php
	echo "<div id='pagi' style='padding:5px;'> Create >>". " ". ucwords($_GET['id']) . "</div>"; 
	?>

                                  
                             </div>
							 	 
			   <div class="clear"></div>		   
                             <div class="headerright">
							 
                                  </div>

		 </div>
		 <!-- End Header -->
		 
		 <!-- Begin Navigation -->
		 <br>
         <div id="navigation">
		  <form action='c_index.php' method='GET'>
<input type='submit' name='id' value="Create">
<input type='submit' name='id' value="Manage">		 
</form>
<?php
if($_GET['id'] == "Create")
{
header("Location:c_index.php");
}
if($_GET['id'] == "Manage")
{
header("Location:m_index.php");
}
?>

<br><br>
<?php include ("top_status.php"); ?>


	<div class="menu">
			<ul>
				

			</ul>
	</div>		 
			   
		 </div>
			 <!-- End Navigation -->
		 
         <!-- Begin Faux Columns -->
		 <div id="faux">
		 
		       <!-- Begin Left Column -->
		       
    <div id="leftcolumn"> 
      <?php
					if($_GET['id'] == "main_category")
					{
					include("c_main_category.php");
					}
					if($_GET['id'] == "sub_category")
					{
					
					include("c_sub_category.php");
					}
					if($_GET['id'] == "add_company")
					{
					
					include("c_add_company.php");
					}
					
					if($_GET['id'] == "logout")
					{
					
					header("Location:logout.php");
					}
					?>
      <div class="clear"></div>
    </div>
		       <!-- End Left Column -->
		 
		       <!-- Begin Right Column -->
		       <div id="rightcolumn">
			 
			 <!-- Salnazi Menu Here-->
			   <?php 

			   include ("c_menu.php"); 

			   ?>

           <div class="news">


                      
               <div class="clear"></div>

           </div>		             
							
			      <div class="clear"></div>
				  
		       </div>
		       <!-- End Right Column -->
			   
         </div>	   
         <!-- End Faux Columns --> 

		 <!-- Begin Footer -->
<div id="footer">



<?php include ("footer.php"); ?>
</div>

<div class="clear"></div>

</div>
		 <!-- End Footer -->
		 
   </div>
   <!-- End Wrapper -->
</body>
</html>
<?php
}
else
{
header("Location:index.php");
}
ob_end_flush();
?>