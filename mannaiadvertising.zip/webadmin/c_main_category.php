<head>
<script src="jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
function showHint(str)
{
  var xmlhttp;
  if (str.length==0)
  { 
    document.getElementById("txtHint").innerHTML="";
    return;
  }
  if (window.XMLHttpRequest)
  {  
     // code for IE7+, Firefox, Chrome, Opera, Safari
     xmlhttp=new XMLHttpRequest();
  }
  else
  {  
     // code for IE6, IE5
     xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function()
  {
    if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
	  
    }
  }
  xmlhttp.open("GET","main_suggestion.php?q="+str,true);
  xmlhttp.send();
}
</script>
</head>
<body>
<?php
error_reporting(0);
session_start();
if($_SESSION['user'])
{
?>
<?php
//error_reporting(0);
ob_start();
session_start();
include('config/host.php');
$category= $_POST['main_category'];
$date = date("d-M-Y");
include ("rand_id.php");
if($_POST['submit'] == "Save" && $category != "")
{
$sql = mysqli_query($_Conn, "insert into $sal_main_cat (category, date, rand_id) values ('$category', '$date', '$rand_id')");
$empty="";
mysqli_query($_Conn, "DELETE FROM $sal_main_cat where category='$empty'");

echo "<script type='text/javascript'> alert('Successfully Added'); </script>";
}
if($_POST['submit'] == "Save" && $category == "")
{
echo "<span id='update'>Error</span>";
}
ob_end_flush();
?> 
<form action='c_index.php?id=main_category' method='post'>
<table border=0 cellpadding=10 cellspacing=20 id="circular">
  <tr>
    <td colspan=2 align=center><h1>Add - Main Category</h1></td>
  </tr>
  <tr>
  
    <td >Main Category</td>
    <td><input type="text" name="main_category" id='txt1' onkeyup="showHint(this.value)" size=50> <br>
	<div style="font-size:13px;position:absolute;background:white;border:solid 1px skyblue;width:325px;">
	<span id="txtHint"></span></div>
	</td>
  </tr>
   
  <tr>
    <td></td>
    <td><input type="submit" name="submit" value="Save" id="submit"> &nbsp;&nbsp;&nbsp; 
      <input type="submit" name="submit" value="Clear" id="submit"> </td>
  </tr>
  <tr>
  </form>
    <td></td>
  </tr>
</table>
<?php
}
else
{
header("Location:index.php");
}
?>