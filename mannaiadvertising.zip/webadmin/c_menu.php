<form action='c_index.php' method='GET'>
		 <ul style='line-height:30px;margin-left:80px;margin-top:30px;' ><h4 style='font-size:20px;'>Create Menu</h4>
		 <br>
		 <li><a href="c_index.php?id=add_company" >Add Company Profile</a></li>
		 	
 				<li><a href="c_index.php?id=sub_category" >Add Sub Category</a></li>
				<li><a href="c_index.php?id=main_category" id='mnews'>Add Main Category </a></li>
			
   						<li><a href="c_index.php?id=logout">Logout</a></li>
		</ul>

</form>
