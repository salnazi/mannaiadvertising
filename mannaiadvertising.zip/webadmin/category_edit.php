<?php
error_reporting(0);
session_start();
if($_SESSION['user'])
{

?>
<br><br>
<?php
error_reporting(0);
ob_start();
session_start();
if($_POST['cancel'] == "Cancel")
header("Location:m_index.php?id=main_category"); 

include('config/host.php');

$r_rand = $_POST['rand'];
$category = $_POST['category'];
$date = $_POST['date'];
$old_cat = $_SESSION['old_cat'];
//include ("rand_id.php");
if($_POST['update'] == "Update")
{
$sql = mysqli_query($_Conn, "UPDATE $sal_main_cat SET category = '$category' , date = '$date'  WHERE rand_id = '$r_rand'");
$sql1 = mysqli_query($_Conn, "UPDATE $sal_sub_cat SET category = '$category'  WHERE category = '$old_cat'");
$sql2 = mysqli_query($_Conn, "UPDATE $sal_add_com SET category = '$category'  WHERE category = '$old_cat'");
echo "<script type='text/javascript'> alert('File has been updated'); window.location='m_index.php?id=main_category' ; </script>";
}
if($_POST['submit'] == "Update" && $category == "")
{
echo "<span id='update'>Error</span>";
}
ob_end_flush();
?>
<?php
}
else
{
header("Location:index.php");
}
?>