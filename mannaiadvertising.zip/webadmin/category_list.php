<?php
ob_start();
session_start();
include('config/host.php');
echo "<tr><td>Category</td><td>";
echo "<select id='category' name = 'category' style='width:250px;'>";
$sql = mysqli_query($_Conn, "select * from $sal_main_cat where id order by category ");
while($row = mysqli_fetch_array($sql))
{
$cate = $row['category'];
echo "<option value='$cate'>$cate</option>";
}
ob_end_flush();
echo "</select>";
echo "</td></tr>";
?>

