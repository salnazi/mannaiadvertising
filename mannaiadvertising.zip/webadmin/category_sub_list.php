

<?php
if($_POST['fetch'] == "Fetch Sub Category")
{
$new_cate = $_POST['category'];
echo "<input type='hidden' name='new_category' value='$new_cate'>";
echo "<tr><td>Sub Category</td><td>";
echo "<select id='sub_category' name = 'sub_category' style='width:250px;'>";
$sql = mysqli_query($_Conn, "select * from $sal_sub_cat where category = '$new_cate' order by sub_category asc ");
while($row = mysqli_fetch_array($sql))
{
$sub_cate = $row['sub_category'];
echo "<option value='$sub_cate' class='$new_cate' >$sub_cate</option>";
}
echo "</select>";
echo "</td></tr>";
}
?>
<!--
<script src="jquery_c.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" charset="utf-8">
          $(function(){
              $("#sub_category").chained("#category"); 
			  
          });
          </script> -->
