<head>
<script LANGUAGE="JavaScript">

function confirmDelete()
{
var agree=confirm("Are you sure you want to delete?");
if (agree)
return true ;
else
return false ;
}

</script>
</head>
<br>
<?php
error_reporting(0);
session_start();
if($_SESSION['user'])
{
?>

<?php

if(isset($_POST['edit']) || isset($_POST['edit_x']))
{
$nfilmname = $_POST['nfilmname'];
$nfilmdetails = $_POST['nfilmdetails'];
$ntheatre = $_POST['ntheatre'];
$nrand = $_POST['nrand'];
$nfilmpic = $_POST['nfilmpic'];
 
 ?>
<table border=0 cellpadding=10 cellspacing=20 id="drop">
  <tr>
    <td colspan=2 align=center><h1>Edit - Cinema Updates</h1></td>
  </tr>
  <tr>
    <td>
	<form action="cinema_updates_edit.php" method="POST" enctype="multipart/form-data">
      </td>
  </tr>
  <input type="hidden" name="rand" size="45" value='<?php echo $nrand; ?>' >
  <input type="hidden" name="filmname" size="45" value='<?php echo $nfilmname; ?>' >
  <input type="hidden" name="filmdetails" size="45" value='<?php echo $nfilmdetails; ?>' >
   <input type="hidden" name="theatre" size="45" value='<?php echo $ntheatre; ?>' >
   <input type="hidden" name="filmpic" size="45" value='<?php echo $nfilmpic; ?>' >
	<?php //include('category_list.php'); ?>
  <tr>
    <td >Theatre</td>
    <td><input type="text" name='theatre' size="45" value='<?php echo $ntheatre; ?>' id='category' disabled></td>
  </tr>
     
  <tr>
    <td >Film name</td>
    <td><input type="text" name='filmname' size="45" value='<?php echo $nfilmname; ?>' id='category' ></td>
  </tr>
 
   
   <tr>
    <td >Film Details</td>
    <td>
	<textarea cols=40 rows=5 name='filmdetails'><?php echo $nfilmdetails; ?></textarea></td>
  </tr>
<tr>
    <td >Image</td>
    <td><input type="file" name="uploadedfile" size="45" id='category'></td>
  </tr>
  
    
    <td colspan=2 align=center><input type="submit" name="update" value="Update" id="submit"><input type="submit" name="cancel" value="Cancel" id="submit"> &nbsp;&nbsp;&nbsp; 
       </td>
  </tr>
  <tr>
  </form>
    <td></td>
  </tr>
</table>

<?php
}

//delete 
if(isset($_POST['delete']) || isset($_POST['delete_x']))
{
$nrand = $_POST['nrand'];
mysqli_query($_Conn, "DELETE FROM $sal_cinema_updates where rand_id='$nrand'");
echo "<script type='text/javascript'> alert('1 Row has been deleted'); window.location='m_index.php?id=cinema_updates' ; </script>";
}


?>
<br><br>


<?php
// Search
$sub_id = $_GET['id'];
$al_id = strtolower(substr($sub_id, -1));
$query_sql = mysqli_query($_Conn, "select * from $sal_cinema_updates where id ");
echo "<table border=0 cellpadding=10 cellspacing=10 id='show'>";
echo "<tr><td style='background:white;padding:6px;'>Title</td><td colspan=4 align=center style='background:white;text-align:center;'>Option</td></tr>";
while($sr = mysqli_fetch_array($query_sql))
{


$s_rand_id = $sr['rand_id'];
$s_theatre = $sr['theatre'];
$s_filmname = $sr['filmname'];
$s_filmdetails = $sr['filmdetails'];
$s_filmpic = $sr['filmpic'];

echo "<form action='m_index.php?id=cinema_updates' method='POST'>";
echo "<input type='hidden' name='nrand' value='$s_rand_id'>";
echo "<input type='hidden' name='ntheatre' value='$s_theatre'>";
echo "<input type='hidden' name='nfilmname' value='$s_filmname'>";
echo "<input type='hidden' name='nfilmdetails' value='$s_filmdetails'>";
echo "<input type='hidden' name='nfilmpic' value='$s_filmpic'>";

echo "<tr class='gradeX'><td >$s_theatre</td><td><input type='image' alt='EDIT' src='images/edit.png' height='20' width='20' name='edit' value='Edit'><td><td class='delete'><input type='image' src='images/DeleteRed.png' height='20' width='20' name='delete' value='Delete' onClick='return confirmDelete()'></td></tr>";
echo "</form>";


}


echo "</table>";
echo "<br><br>";
?>



<?php
}
else
{
header("Location:index.php");
}
?>