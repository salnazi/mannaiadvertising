<?php
error_reporting(0);
session_start();
if($_SESSION['user'])
{
?>
<br><br>
<?php
error_reporting(0);
ob_start();
session_start();
include('config/host.php');
$r_rand = $_POST['rand'];
$title = $_POST['title'];
$date = $_POST['date'];
$desc = $_POST['t_desc'];

$target_path = "events/";
include ("rand_id.php");
   //Rename
$str = $_FILES['uploadedfile']['name'];
$i = explode(".", $str);
$ext = $i[1];
$extension = strtolower($ext);
$image_name=time().'.'.$extension;
$newname="events/".$image_name;
if($ext == "")
{
$target_path = $_POST['uploads'];


}
else
{
$target_path = $target_path . basename($newname);
$uploads = $_POST['uploads'];
unlink($uploads);
}

if($_POST['update'] == "Update")
{
move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path);
$sql = mysqli_query($_Conn, "UPDATE $events SET title = '$title' , date = '$date' , t_desc = '$desc' , uploads = '$target_path' WHERE rand_id = '$r_rand'");


echo "<script type='text/javascript'> alert('File has been updated'); window.location='m_index.php?id=events' ; </script>";
}
if($_POST['submit'] == "Save" && $title == "")
{
echo "<span id='update'>Error</span>";
}
ob_end_flush();
?>
<?php
}
else
{
header("Location:index.php");
}
?>