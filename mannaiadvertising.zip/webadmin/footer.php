<br><br><br>
<div id="leftcontent">

<strong>Mannai Advertising</strong><br />
<a href="mailto:salnazi@gmail.com">Contact Us</a>

</div>


<div id="rightcontent">

Copyright &copy; 2011 <a href="http://www.salnazi.com">Mannai Advertising</a>
<br />
Design by <a href="http://www.salnazi.com" title="The Oxford School">Salnazi</a>
