<?php
error_reporting(0);
ob_start();
session_start();
$username = $_POST['username'];
$password = $_POST['password'];
include("config/host.php");
$sql = mysqli_query($_Conn, "select * from $sal_admin where id");
while ($row = mysqli_fetch_array($sql))
{
if($username == $row['username'] && $password == $row['password'])
{
$_SESSION['user'] = $row['username'];
header("Location:c_index.php");
echo "<meta http-equiv='refresh' content='0 c_index.php'>";
}

}
ob_end_flush();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<?php include("title.php"); ?>
<link rel="stylesheet" type="text/css" href="style.css" />
<script language="JavaScript" type="text/javascript" src="wysiwyg.js">
</script>

</head>

<body>
   <!-- Begin Wrapper -->
   <div id="wrapper">

   
         <!-- Begin Header -->
         <div id="header">
		 
         <div class="top">
		 
		       <?php include ("header_name.php"); ?>		 
			  
		 </div>	
        <div class="headertext">
	                              


                                  
                             </div>	 
			   <div class="clear"></div>		   
                             <div class="headerright">
                                  </div>

		 </div>
		 <!-- End Header -->
		
		 <!-- Begin Navigation -->
         <div id="navigation">
		 
		 
	<div class="menu">
			<ul>
				<br>

			</ul>
	</div>		 
			   
		 </div>
			 <!-- End Navigation -->
		 
         <!-- Begin Faux Columns -->
		 <div id="faux">
		 
		       <!-- Begin Left Column -->
		       
    <div id="leftcolumn"> 
	 <form action="index.php" method="post">

<br><br><br>
<table border=0 cellpadding=5 cellspacing=5  style='color:#8A4B08;font-size:16px;width:250px;margin-left:320px;_margin-left:50px;font-weight:bold;border:solid 1px silver;' align=center>
<tr><td colspan=2 align=center>Admin Login</td></tr>
<tr><td colspan=2 align=center><br></td></tr>
<tr><td style='color:black;'><i>Username</i></td><td><input type='text' name='username'></td></tr>
<tr><td style='color:black;'><i>Password </i></td><td><input type='password' name='password'></td></tr>
<tr><td colspan=2 align=center><input type="submit" name="submit" value="Login"></td></tr>

</table>
</form>

      <div class="clear"></div>
    </div>
		       <!-- End Left Column -->
		 
		       <!-- Begin Right Column -->
		       <div id="rightcolumn">
			  
			 <!-- Salnazi Menu Here-->
			

           <div class="news">


                      
               <div class="clear"></div>

           </div>		             
							
			      <div class="clear"></div>
				  
		       </div>
		       <!-- End Right Column -->
			   
         </div>	   
         <!-- End Faux Columns --> 

		 <!-- Begin Footer -->
<div id="footer" style='_margin-top:-200px;'>
<?php include ("footer.php"); ?>
</div>

<div class="clear"></div>

</div>
		 <!-- End Footer -->
		 
   </div>
   <!-- End Wrapper -->
</body>
</html>
