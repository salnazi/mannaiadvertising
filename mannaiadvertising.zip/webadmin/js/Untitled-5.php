<div id="events">
<table border=0 cellpadding=10 cellspacing=20>
<tr><td colspan=2 align=center><h1>Events </h1></td></tr>
<tr><td><form action="album_entry_action.php" method="post" enctype="multipart/form-data"></td></tr>
<tr><td >Heading</td><td><input type="text" name="heading" size="40"></td></tr>
<?php //include ("date.php"); ?>
<tr><td>Image</td><td><input type="file" name="uploadedfile" size=40></td></tr>
<input type="hidden" name="MAX_FILE_SIZE" value="100000" />
<tr><td></td><td><input type="submit" name="submit" value="Save" id="submit"> &nbsp;&nbsp;&nbsp; <input type="submit" name="submit" value="Clear" id="submit"> </td></tr>
<tr><td></form></td></tr>
</table></div>
