<head>
<script LANGUAGE="JavaScript">

function confirmDelete()
{
var agree=confirm("Are you sure you want to delete?");
if (agree)
return true ;
else
return false ;
}

</script>
</head>
<br>
<?php
error_reporting(0);
session_start();
if($_SESSION['user'])
{
?>
<div style='text-align:center;'>
<a id='al'><<</a>
<a href='m_index.php?id=add_companya' id='al'>A</a>
<a href='m_index.php?id=add_companyb' id='al'>B</a>
<a href='m_index.php?id=add_companyc' id='al'>C</a>
<a href='m_index.php?id=add_companyd' id='al'>D</a>
<a href='m_index.php?id=add_companye' id='al'>E</a>
<a href='m_index.php?id=add_companyf' id='al'>F</a>
<a href='m_index.php?id=add_companyg' id='al'>G</a>
<a href='m_index.php?id=add_companyh' id='al'>H</a>
<a href='m_index.php?id=add_companyi' id='al'>I</a>
<a href='m_index.php?id=add_companyj' id='al'>J</a>
<a href='m_index.php?id=add_companyk' id='al'>K</a>
<a href='m_index.php?id=add_companyl' id='al'>L</a>
<a href='m_index.php?id=add_companym' id='al'>M</a>
<a href='m_index.php?id=add_companyn' id='al'>N</a>
<a href='m_index.php?id=add_companyo' id='al'>O</a>
<a href='m_index.php?id=add_companyp' id='al'>P</a>
<a href='m_index.php?id=add_companyq' id='al'>Q</a>
<a href='m_index.php?id=add_companyr' id='al'>R</a>
<a href='m_index.php?id=add_companys' id='al'>S</a>
<a href='m_index.php?id=add_companyt' id='al'>T</a>
<a href='m_index.php?id=add_companyu' id='al'>U</a>
<a href='m_index.php?id=add_companyv' id='al'>V</a>
<a href='m_index.php?id=add_companyw' id='al'>W</a>
<a href='m_index.php?id=add_companyx' id='al'>X</a>
<a href='m_index.php?id=add_companyy' id='al'>Y</a>
<a href='m_index.php?id=add_companyz' id='al'>Z</a>
<a  id='al'>>></a>
</div>
<?php

if(isset($_POST['edit']) || isset($_POST['edit_x']))
{
$ncategory = $_POST['ncategory'];
$nsubcategory = $_POST['nsubcategory'];
$ntitle = htmlspecialchars($_POST['ntitle']);
$nphone = $_POST['nphone'];
$naddress = $_POST['naddress'];
$ntags = $_POST['ntags'];
$ndate = $_POST['ndate'];
$nrand = $_POST['nrand'];
 $notherinfo = $_POST['notherinfo'];
 $nemail = $_POST['nemail'];
 $nwebsite = $_POST['nwebsite'];
 ?><br><Br>
<table border=0 cellpadding=10 cellspacing=20 id="drop">
  <tr>
    <td colspan=2 align=center><h1>Edit - Company Profile</h1></td>
  </tr>
  <tr>
    <td>
	<form action="add_company_edit.php" method="POST" enctype="multipart/form-data">
      </td>
  </tr>
  <input type="hidden" name="rand" size="45" value='<?php echo $nrand; ?>' >
  <input type="hidden" name="category" size="45" value='<?php echo $ncategory; ?>' >
  <input type="hidden" name="sub_category" size="45" value='<?php echo $nsubcategory; ?>' >
  
	<?php //include('category_list.php'); ?>
  <tr>
    <td >Category</td>
    <td><input type="text" name='category' size="45" value='<?php echo $ncategory; ?>' id='category' disabled></td>
  </tr>
     
  <tr>
    <td >Sub Category</td>
    <td><input type="text"  size="45" name= "sub_category" value='<?php echo $nsubcategory; ?>' id='category' disabled></td>
  </tr>
   <tr>
    <td >Title</td>
    <td><input type="text" name="title" size="45" value='<?php echo $ntitle; ?>' id='category'></td>
  </tr>
   <tr>
    <td >Phone</td>
    <td><input type="text" name="phone" size="45" value='<?php echo $nphone; ?>' id='category'></td>
  </tr>
  
   <tr>
    <td >Address</td>
    <td>
	<textarea cols=40 rows=4 name='address'><?php echo $naddress; ?></textarea></td>
  </tr>
   <tr>
    <td >Other Info</td>
    <td>
	<textarea cols=40 rows=2 name='otherinfo'><?php echo $notherinfo; ?></textarea></td>
  </tr>
   <tr>
    <td >Tags</td>
    <td><input type="text" name="tags" size="45" value='<?php echo $ntags; ?>' id='category'></td>
  </tr>
    <input type="hidden" name="date" size="45" value='<?php echo $ndate; ?>' id='title'>

    
	
	 <tr><td colspan=2><b>Optional</b></td></tr>
<tr>    <td >Email</td>
    <td><input type="text" name="email" size="45" value='<?php echo $nemail; ?>' id='category'></td>
  </tr>
   <tr>
    <td >Website</td>
    <td><input type="text" name="website" size="45" value='<?php echo $nwebsite; ?>' id='category'></td>
  </tr>
    <td colspan=2 align=center><input type="submit" name="update" value="Update" id="submit"><input type="submit" name="cancel" value="Cancel" id="submit"> &nbsp;&nbsp;&nbsp; 
       </td>
  </tr>
  <tr>
  </form>
    <td></td>
  </tr>
</table>

<?php
}

//delete 
if(isset($_POST['delete']) || isset($_POST['delete_x']))
{
$nrand = $_POST['nrand'];
mysqli_query($_Conn, "DELETE FROM $sal_add_com where rand_id='$nrand'");
echo "<script type='text/javascript'> alert('1 Row has been deleted'); window.location='m_index.php?id=add_company' ; </script>";
}


?>
<br><br>
<?php
if($_GET['id'] == "add_company")
{
$query_sql = mysqli_query($_Conn, "select * from $sal_add_com where id order by title asc");
//$query_sql = mysqli_query($_Conn, "select * from $sal_add_com where id order by 'date' desc limit 100");
echo "<table border=0 cellpadding=10 cellspacing=10 id='show'>";
echo "<tr><td style='background:white;padding:6px;'>Title</td><td style='background:white;padding:6px;'>Sub Category</td><td style='background:white;padding:6px;'>Category</td><td style='background:white;text-align:center;'>Date</td><td colspan=4 align=center style='background:white;text-align:center;'>Option</td></tr>";
while($sr = mysqli_fetch_array($query_sql))
{
$s_rand_id = $sr['rand_id'];
$s_category = $sr['category'];
$s_sub_category = $sr['sub_category'];
$s_title = $sr['title'];
$s_phone = $sr['phone'];
$s_tags = $sr['tags'];
$s_address = $sr['address'];
$s_email = $sr['email'];
$s_otherinfo = $sr['otherinfo'];
$s_website = $sr['website'];
$s_date = $sr['date'];

echo "<form action='m_index.php?id=add_company' method='POST'>";
echo "<input type='hidden' name='nrand' value='$s_rand_id'>";
echo "<input type='hidden' name='ncategory' value='$s_category'>";
echo "<input type='hidden' name='nphone' value='$s_phone'>";
echo "<input type='hidden' name='nsubcategory' value='$s_sub_category'>";
echo "<input type='hidden' name='naddress' value='$s_address'>";
echo "<input type='hidden' name='notherinfo' value='$s_otherinfo'>";
echo "<input type='hidden' name='nemail' value='$s_email'>";
echo "<input type='hidden' name='nwebsite' value='$s_website'>";
echo "<input type='hidden' name='ntitle' value='$s_title'>";
echo "<input type='hidden' name='ntags' value='$s_tags'>";
echo "<input type='hidden' name='ndate' value='$s_date'>";
echo "<tr class='gradeX'><td >$s_title</td><td >$s_sub_category</td><td >$s_category</td><td >$s_date</td><td><input type='image' alt='EDIT' src='images/edit.png' height='20' width='20' name='edit' value='Edit'><td><td class='delete'><input type='image' src='images/DeleteRed.png' height='20' width='20' name='delete' value='Delete' onClick='return confirmDelete()'></td></tr>";
echo "</form>";

}
echo "</table>";
echo "<br><br>";
}

?>


<?php
// Search
$sub_id = $_GET['id'];
$al_id = strtolower(substr($sub_id, -1));
$query_sql = mysqli_query($_Conn, "select * from $sal_add_com where id order by title asc");
echo "<table border=0 cellpadding=10 cellspacing=10 id='show'>";
echo "<tr><td style='background:white;padding:6px;'>Title</td><td style='background:white;padding:6px;'>Sub Category</td><td style='background:white;padding:6px;'>Category</td><td style='background:white;text-align:center;'>Date</td><td colspan=4 align=center style='background:white;text-align:center;'>Option</td></tr>";
while($sr = mysqli_fetch_array($query_sql))
{
$start_let =  strtolower($sr['title'][0]);
if($start_let == $al_id)
{
$s_rand_id = $sr['rand_id'];
$s_category = $sr['category'];
$s_sub_category = $sr['sub_category'];
$s_title = $sr['title'];
$s_phone = $sr['phone'];
$s_tags = $sr['tags'];
$s_address = $sr['address'];
$s_date = $sr['date'];
$s_email = $sr['email'];
$s_otherinfo = $sr['otherinfo'];
$s_website = $sr['website'];

echo "<form action='m_index.php?id=add_company' method='POST'>";
echo "<input type='hidden' name='nrand' value='$s_rand_id'>";
echo "<input type='hidden' name='ncategory' value='$s_category'>";
echo "<input type='hidden' name='nphone' value='$s_phone'>";
echo "<input type='hidden' name='nsubcategory' value='$s_sub_category'>";
echo "<input type='hidden' name='naddress' value='$s_address'>";
echo "<input type='hidden' name='ntitle' value='$s_title'>";
echo "<input type='hidden' name='ndate' value='$s_date'>";
echo "<input type='hidden' name='ntags' value='$s_tags'>";
echo "<input type='hidden' name='notherinfo' value='$s_otherinfo'>";
echo "<input type='hidden' name='nemail' value='$s_email'>";
echo "<input type='hidden' name='nwebsite' value='$s_website'>";
echo "<tr class='gradeX'><td >$s_title</td><td >$s_sub_category</td><td >$s_category</td><td >$s_date</td><td><input type='image' alt='EDIT' src='images/edit.png' height='20' width='20' name='edit' value='Edit'><td><td class='delete'><input type='image' src='images/DeleteRed.png' height='20' width='20' name='delete' value='Delete' onClick='return confirmDelete()'></td></tr>";
echo "</form>";


}

}
echo "</table>";
echo "<br><br>";
?>



<?php
}
else
{
header("Location:index.php");
}
?>