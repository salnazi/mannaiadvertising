<head>
<script LANGUAGE="JavaScript">

function confirmDelete()
{
var agree=confirm("Are you sure you want to delete?");
if (agree)
return true ;
else
return false ;
}

</script>
</head>
<br>
<?php
error_reporting(0);
session_start();
if($_SESSION['user'])
{
?>
<?php

if(isset($_POST['edit']) || isset($_POST['edit_x']))
{
$ntitle = $_POST['ntitle'];
$ndesc = $_POST['ndesc'];
$ndate = $_POST['ndate'];
$nrand = $_POST['nrand'];
$nphone = $_POST['nphone'];
$naddress = $_POST['naddress'];
$nuploads = $_POST['nuploads'];
 
 ?>
<table border=0 cellpadding=10 cellspacing=20 id="drop">
  <tr>
    <td colspan=2 align=center><h1>Edit Form</h1></td>
  </tr>
  <tr>
    <td>
	<form action="category_edit.php" method="POST" enctype="multipart/form-data">
      </td>
  </tr>
  <input type="hidden" name="rand" size="45" value='<?php echo $nrand; ?>' >
    <input type="hidden" name="uploads" size="45" value='<?php echo $nuploads; ?>' >
	<?php include('category_list.php'); ?>
  <tr>
    <td >Title</td>
    <td><input type="text" name="title" size="45" value='<?php echo $ntitle; ?>' id='title'></td>
  </tr>
     
   <td >Phone</td>
    <td><input type="text" name="phone" size="45" value='<?php echo $nphone; ?>' id='title'></td>
  </tr>
  
    <input type="hidden" name="date" size="45" value='<?php echo $ndate; ?>' id='title'>
  
  <tr><td>Address</td><td><textarea cols=50 rows=5 name="address" ><?php echo $naddress; ?></textarea></td></tr>
<script language="javascript1.2">
  generate_wysiwyg('textarea1');
</script>

  <tr>
    <td>File Upload</td>
    <td><input type="file" name="uploadedfile" size=40></td>
  </tr>
  <input type="hidden" name="MAX_FILE_SIZE" value="100000" />
  <tr><td><td><img src='<?php echo $nuploads; ?>' height=75 width=75></td></td></tr>
  <tr>
    <td></td>
    <td colspan=2 align=center><input type="submit" name="update" value="Update" id="submit"> &nbsp;&nbsp;&nbsp; 
       </td>
  </tr>
  <tr>
  </form>
    <td></td>
  </tr>
</table>

<?php
}

//delete 
if(isset($_POST['delete']) || isset($_POST['delete_x']))
{
$nrand = $_POST['nrand'];
mysqli_query($_Conn, "DELETE FROM $sal_category where rand_id='$nrand'");
$uploads = $_POST['nuploads'];
unlink($uploads);
echo "<script type='text/javascript'> alert('1 Row has been deleted'); window.location='m_index.php?id=category' ; </script>";

}
?>
<br><br>
<?php
error_reporting(0);
ob_start();
session_start();
include('config/host.php');
$category = $_POST['category'];
$title = $_POST['title'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$date = date("d-M-Y");
$target_path = "adminimages/";
include ("rand_id.php");
   //Rename
$str = $_FILES['uploadedfile']['name'];
$i = explode(".", $str);
$ext = $i[1];
$extension = strtolower($ext);
$image_name=time().'.'.$extension;
$newname="adminimages/".$image_name;
if($ext == "")
{
$target_path = "";
}
else
{
$target_path = $target_path . basename($newname);
}

if($_POST['submit'] == "Save" && $category != "")
{
move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path);

$sql = mysqli_query($_Conn, "insert into $sal_category (category, title, phone, address, pic, date, rand_id) values ('$category', '$title' , '$phone','$address', '$target_path', '$date', '$rand_id')");
$empty="";
mysqli_query($_Conn, "DELETE FROM $sal_category where category='$empty'");

echo "<script type='text/javascript'> alert('File has been updated'); </script>";
}
if($_POST['submit'] == "Save" && $category == "")
{
echo "<span id='update'>Error</span>";
}
ob_end_flush();
?>
<?php
$query_sql = mysqli_query($_Conn, "select * from $sal_category where id order by 'date'");
//$query_sql = mysqli_query($_Conn, "select * from $sal_category where id order by 'date' desc limit 100");
echo "<table border=0 cellpadding=10 cellspacing=10 id='show'>";
echo "<tr><td style='background:white;padding:6px;'>Title</td><td style='background:white;padding:6px;'>Category</td><td style='background:white;text-align:center;'>Date</td><td colspan=4 align=center style='background:white;text-align:center;'>Option</td></tr>";
while($sr = mysqli_fetch_array($query_sql))
{
$s_rand_id = $sr['rand_id'];
$s_category = $sr['category'];
$s_title = $sr['title'];
$s_date = $sr['date'];
$s_address = $sr['address'];
$s_phone = $sr['phone'];
$uploads = $sr['uploads'];
echo "<form action='m_index.php?id=category' method='POST'>";
echo "<input type='hidden' name='nrand' value='$s_rand_id'>";
echo "<input type='hidden' name='ncategory' value='$s_category'>";
echo "<input type='hidden' name='ntitle' value='$s_title'>";
echo "<input type='hidden' name='nphone' value='$s_phone'>";
echo "<input type='hidden' name='ndate' value='$s_date'>";
echo "<input type='hidden' name='naddress' value='$s_address'>";
echo "<input type='hidden' name='nuploads' value='$uploads'>";
echo "<tr class='gradeX'><td style='width:700px;'>$s_title</td><td >$s_category</td><td >$s_date</td><td><input type='image' alt='EDIT' src='images/edit.png' height='20' width='20' name='edit' value='Edit'><td><td class='delete'><input type='image' src='images/DeleteRed.png' height='20' width='20' name='delete' value='Delete' onClick='return confirmDelete()'></td></tr>";
echo "</form>";

}
echo "</table>";
echo "<br><br>";
?>



<?php
}
else
{
header("Location:index.php");
}
?>