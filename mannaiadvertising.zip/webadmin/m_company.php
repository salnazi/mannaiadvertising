<?php
error_reporting(0);
session_start();
if($_SESSION['user'])
{
?>
<br><br>
<?php
error_reporting(0);
ob_start();
session_start();
include('config/host.php');
$title = $_POST['title'];
$t_desc = $_POST['t_desc'];
$date = $_POST['year']."-".$_POST['month']."-".$_POST['date'];
$target_path = "news/";
include ("rand_id.php");
   //Rename
$str = $_FILES['uploadedfile']['name'];
$i = explode(".", $str);
$ext = $i[1];
$extension = strtolower($ext);
$image_name=time().'.'.$extension;
$newname="news/".$image_name;
if($ext == "")
{
$target_path = "";
}
else
{
$target_path = $target_path . basename($newname);
}

if($_POST['submit'] == "Save" && $title != "")
{
move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path);

$sql = mysqli_query($_Conn, "insert into $news (title, date, t_desc, uploads, rand_id) values ('$title', '$date' , '$t_desc' , '$target_path', '$rand_id')");
$empty="";
mysqli_query($_Conn, "DELETE FROM $news where title='$empty'");

echo "<script type='text/javascript'> alert('File has been updated'); </script>";
}
if($_POST['submit'] == "Save" && $title == "")
{
echo "<span id='update'>Error</span>";
}
ob_end_flush();
?>
<?php
$query_sql = mysqli_query($_Conn, "select * from $news where id order by 'date'");
//$query_sql = mysqli_query($_Conn, "select * from $circulars where id order by 'date' desc limit 100");
echo "<table border=0 cellpadding=10 cellspacing=10 id='show'>";
echo "<tr><td style='background:white;padding:6px;'>Title</td><td style='background:white;text-align:center;'>Date</td><td colspan=2 align=center style='background:white;text-align:center;''>Option</td></tr>";
while($sr = mysqli_fetch_array($query_sql))
{
$s_rand_id = $sr['rand_id'];
$s_title = $sr['title'];
$s_date = $sr['date'];
$s_desc = $sr['t_desc'];
$uploads = $sr['uploads'];
echo "<form action='m_index.php?id=news' method='POST'>";
echo "<input type='hidden' name='nrand' value='$s_rand_id'>";
echo "<input type='hidden' name='ntitle' value='$s_title'>";
echo "<input type='hidden' name='ndate' value='$s_date'>";
echo "<input type='hidden' name='ndesc' value='$s_desc'>";
echo "<input type='hidden' name='nuploads' value='$uploads'>";
//echo "<tr><td style='width:700px;'>$s_title</td><td>$s_date</td><td><input type='submit' name='edit' value='Edit'><td><td class='delete'><input type='submit' name='delete' value='Delete'></td></tr>";
echo "<tr><td style='width:700px;'>$s_title</td><td >$s_date</td><td><input type='image' src='images/edit.png' height='20' width='20' name='edit' value='Edit'><td><td class='delete'><input type='image' src='images/DeleteRed.png' height='20' width='20' name='delete' value='Delete'></td></tr>";
echo "</form>";

}
echo "</table>";
echo "<br><br>";
?>
<?php
if(isset($_POST['edit']) || isset($_POST['edit_x']))
{
$ntitle = $_POST['ntitle'];
$ndesc = $_POST['ndesc'];
$ndate = $_POST['ndate'];
$nrand = $_POST['nrand'];
$nuploads = $_POST['nuploads'];
 
 ?>
<table border=0 cellpadding=10 cellspacing=20 id="drop">
  <tr>
    <td colspan=2 align=center><h1>News - Edit </h1></td>
  </tr>
  <tr>
    <td>
	<form action="news_edit.php" method="POST" enctype="multipart/form-data">
      </td>
  </tr>
  <input type="hidden" name="rand" size="45" value='<?php echo $nrand; ?>' >
    <input type="hidden" name="uploads" size="45" value='<?php echo $nuploads; ?>' >
  <tr>
    <td >Title</td>
    <td><input type="text" name="title" size="45" value='<?php echo $ntitle; ?>'></td>
  </tr>
  <tr>
    <td >Date</td>
    <td><input type="text" name="date" size="45" value='<?php echo $ndate; ?>'></td>
  </tr>
 
  <tr><td>Description</td><td><textarea cols=50 rows=16 name="t_desc" id="textarea1"><?php echo $ndesc; ?></textarea></td></tr>
<script language="javascript1.2">
  generate_wysiwyg('textarea1');
</script>

  <tr>
    <td>File Upload</td>
    <td><input type="file" name="uploadedfile" size=40></td>
  </tr>
  <input type="hidden" name="MAX_FILE_SIZE" value="100000" />
  <tr><td><td><img src='<?php echo $nuploads; ?>' height=75 width=75></td></td></tr>
  <tr>
    <td></td>
    <td colspan=2 align=center><input type="submit" name="update" value="Update" id="submit"> &nbsp;&nbsp;&nbsp; 
       </td>
  </tr>
  <tr>
  </form>
    <td></td>
  </tr>
</table>

<?php
}

//delete 
if(isset($_POST['delete']) || isset($_POST['delete_x']))
{
$nrand = $_POST['nrand'];
mysqli_query($_Conn, "DELETE FROM $news where rand_id='$nrand'");
$uploads = $_POST['nuploads'];
unlink($uploads);
echo "<script type='text/javascript'> alert('1 Row has been deleted'); window.location='m_index.php?id=news' ; </script>";

}
?>
<?php
}
else
{
header("Location:index.php");
}
?>