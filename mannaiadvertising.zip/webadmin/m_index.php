<?php
error_reporting(0);
ob_start();
session_start();
if($_SESSION['user'])
{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<?php include("title.php"); ?>
<link rel="stylesheet" type="text/css" href="style.css" /> 
<script language="JavaScript" type="text/javascript" src="wysiwyg.js">
</script>

</head>

<body>
   <!-- Begin Wrapper -->
   <div id="wrapper">

   
         <!-- Begin Header -->
         <div id="header">
		 
         <div class="top">
		 
		       <?php include ("header_name.php"); ?>		 
			  
		 </div>	
        <div class="headertext">
	                              
<?php
	echo "<div id='pagi' style='padding:5px;'> Manage >>". " ". ucwords($_GET['id']) . "</div>"; 
	?>

                                  
                             </div>	 
			   <div class="clear"></div>		   
                             <div class="headerright">
                                  </div>

		 </div>
		 <!-- End Header -->
		 
		 <!-- Begin Navigation -->
         <div id="navigation">
		 <br>
		 	  <form action='m_index.php' method='GET'>
<input type='submit' name='id' value="Create">
<input type='submit' name='id' value="Manage">		 
</form>
<?php
if($_GET['id'] == "Create")
{
header("Location:c_index.php");
}
if($_GET['id'] == "Manage")
{
header("Location:m_index.php");
}
?>

<br><br>
<?php include("top_status.php"); ?>


	<div class="menu">
			<ul>
				

			</ul>
	</div>		 
			   
		 </div>
			 <!-- End Navigation -->
		 
         <!-- Begin Faux Columns -->
		 <div id="faux">
		 
		       <!-- Begin Left Column -->
		       
    <div id="leftcolumn"> 
      
	    <?php
		if($_GET['id'] == "cinema_updates")
					{
					
					include("cinema_updates.php");
					}
						if($_GET['id'] == "banner_updates")
					{
					
					include("banner_updates.php");
					}
					if($_GET['id'] == "main_category")
					{
					include("m_main_category.php");
					}
					if($_GET['id'] == "sub_category")
					{
					include("m_sub_category.php");
					}
					if($_GET['id'] == "sub_categorya" || $_GET['id'] == "sub_categoryb" || $_GET['id'] == "sub_categoryc" || $_GET['id'] == "sub_categoryd" ||$_GET['id'] == "sub_categorye" ||$_GET['id'] == "sub_categoryf" ||$_GET['id'] == "sub_categoryg" || $_GET['id'] == "sub_categoryh" ||$_GET['id'] == "sub_categoryi" || $_GET['id'] == "sub_categoryj" ||$_GET['id'] == "sub_categoryk" || $_GET['id'] == "sub_categoryl" || $_GET['id'] == "sub_categorym" ||$_GET['id'] == "sub_categoryn" ||$_GET['id'] == "sub_categoryo" || $_GET['id'] == "sub_categoryp" ||$_GET['id'] == "sub_categoryq" ||$_GET['id'] == "sub_categoryr" ||$_GET['id'] == "sub_categorys" ||$_GET['id'] == "sub_categoryt" || $_GET['id'] == "sub_categoryu" ||$_GET['id'] == "sub_categoryv" ||$_GET['id'] == "sub_categoryw" || $_GET['id'] == "sub_categoryx" ||$_GET['id'] == "sub_categoryy" ||$_GET['id'] == "sub_categoryz" )
					{
					include("m_sub_category.php");
					}
					if($_GET['id'] == "add_company")
					{
					include("m_add_company.php");
					}
					
					if($_GET['id'] == "add_companya" || $_GET['id'] == "add_companyb" || $_GET['id'] == "add_companyc" || $_GET['id'] == "add_companyd" ||$_GET['id'] == "add_companye" ||$_GET['id'] == "add_companyf" ||$_GET['id'] == "add_companyg" || $_GET['id'] == "add_companyh" ||$_GET['id'] == "add_companyi" || $_GET['id'] == "add_companyj" ||$_GET['id'] == "add_companyk" || $_GET['id'] == "add_companyl" || $_GET['id'] == "add_companym" ||$_GET['id'] == "add_companyn" ||$_GET['id'] == "add_companyo" || $_GET['id'] == "add_companyp" ||$_GET['id'] == "add_companyq" ||$_GET['id'] == "add_companyr" ||$_GET['id'] == "add_companys" ||$_GET['id'] == "add_companyt" || $_GET['id'] == "add_companyu" ||$_GET['id'] == "add_companyv" ||$_GET['id'] == "add_companyw" || $_GET['id'] == "add_companyx" ||$_GET['id'] == "add_companyy" ||$_GET['id'] == "add_companyz" )
					{
					include("m_add_company.php");
					}
					
					if($_GET['id'] == "logout")
					{
					
					header("Location:logout.php");
					}
					?>
					
      <div class="clear"></div>
    </div>
		       <!-- End Left Column -->
		 
		       <!-- Begin Right Column -->
		       <div id="rightcolumn">
			  
			 <!-- Salnazi Menu Here-->
			   <?php 

			   include ("m_menu.php"); 

			   ?>

           <div class="news">


                      
               <div class="clear"></div>

           </div>		             
							
			      <div class="clear"></div>
				  
		       </div>
		       <!-- End Right Column -->
			   
         </div>	   
         <!-- End Faux Columns --> 

		 <!-- Begin Footer -->
<div id="footer">

<?php include("footer.php"); ?>
</div>

<div class="clear"></div>

</div>
		 <!-- End Footer -->
		 
   </div>
   <!-- End Wrapper -->
</body>
</html>
<?php
}
else
{
header("Location:index.php");
}
ob_end_flush();
?>
