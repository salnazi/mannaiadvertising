<head>
<script LANGUAGE="JavaScript">

function confirmDelete()
{
var agree=confirm("Are you sure you want to delete?");
if (agree)
return true ;
else
return false ;
}

</script>
</head>
<br>
<?php
error_reporting(0);
session_start();
if($_SESSION['user'])
{
?>
<?php

if(isset($_POST['edit']) || isset($_POST['edit_x']))
{
$ncategory = $_POST['ncategory'];
$_SESSION['old_cat'] = $_POST['ncategory'];
$ndate = $_POST['ndate'];
$nrand = $_POST['nrand'];
 
 ?>
<table border=0 cellpadding=10 cellspacing=20 id="drop">
  <tr>
    <td colspan=2 align=center><h1>Edit - Main Category</h1></td>
  </tr>
  <tr>
    <td>
	<form action="category_edit.php" method="POST" enctype="multipart/form-data">
      </td>
  </tr>
  <input type="hidden" name="rand" size="45" value='<?php echo $nrand; ?>' >
  
	<?php //include('category_list.php'); ?>
  <tr>
    <td >Category</td>
    <td><input type="text" name="category" size="45" value='<?php echo $ncategory; ?>' id='category'></td>
  </tr>
     
 
    <input type="hidden" name="date" size="45" value='<?php echo $ndate; ?>' id='title'>
   <tr>
    
    <td colspan=2 align=center><input type="submit" name="update" value="Update" id="submit"><input type="submit" name="cancel" value="Cancel" id="submit"> &nbsp;&nbsp;&nbsp; 
       </td>
  </tr>
  <tr>
  </form>
    <td></td>
  </tr>
</table>

<?php
}

//delete 
if(isset($_POST['delete']) || isset($_POST['delete_x']))
{
$nrand = $_POST['nrand'];
mysqli_query($_Conn, "DELETE FROM $sal_main_cat where rand_id='$nrand'");
echo "<script type='text/javascript'> alert('1 Row has been deleted'); window.location='m_index.php?id=main_category' ; </script>";
}


?>
<br><br>

<?php
$query_sql = mysqli_query($_Conn, "select * from $sal_main_cat where id order by category asc");
//$query_sql = mysqli_query($_Conn, "select * from $sal_main_cat where id order by 'date' desc limit 100");
echo "<table border=0 cellpadding=10 cellspacing=10 id='show'>";
echo "<tr><td style='background:white;padding:6px;'>Category</td><td style='background:white;text-align:center;'>Date</td><td colspan=4 align=center style='background:white;text-align:center;'>Option</td></tr>";
while($sr = mysqli_fetch_array($query_sql))
{
$s_rand_id = $sr['rand_id'];
$s_category = $sr['category'];
$s_date = $sr['date'];

echo "<form action='m_index.php?id=main_category' method='POST'>";
echo "<input type='hidden' name='nrand' value='$s_rand_id'>";
echo "<input type='hidden' name='ncategory' value='$s_category'>";
echo "<input type='hidden' name='ndate' value='$s_date'>";
echo "<tr class='gradeX'><td >$s_category</td><td >$s_date</td><td><input type='image' alt='EDIT' src='images/edit.png' height='20' width='20' name='edit' value='Edit'><td><td class='delete'><input type='image' src='images/DeleteRed.png' height='20' width='20' name='delete' value='Delete' onClick='return confirmDelete()'></td></tr>";
echo "</form>";

}
echo "</table>";
echo "<br><br>";
?>



<?php
}
else
{
header("Location:index.php");
}
?>