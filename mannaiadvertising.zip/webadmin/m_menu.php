<form action='m_index.php' method='GET'>
		 <ul style='line-height:30px;margin-left:80px;margin-top:30px;' ><h4 style='font-size:20px;'>Manage Menu</h4>
		 <br>
		 <li><a href="m_index.php?id=add_company" >Edit Company Profile</a></li>
		 	
 				<li><a href="m_index.php?id=sub_category" >Edit Sub Category</a></li>
				<li><a href="m_index.php?id=main_category" id='mnews'>Edit Main Category </a></li>
			<li><a href="m_index.php?id=cinema_updates" >Cinema Updates</a></li>
			<li><a href="m_index.php?id=banner_updates" >Banner Updates</a></li>
   						<li><a href="m_index.php?id=logout">Logout</a></li>
		</ul>

</form>
