<?php
error_reporting(0);
session_start();
if($_SESSION['user'])
{
?>
<br><br>
<?php
error_reporting(0);
ob_start();
session_start();
include('config/host.php');
$title = $_POST['title'];
$t_desc = $_POST['t_desc'];
$date = $_POST['year']."-".$_POST['month']."-".$_POST['date'];
$target_path = "events/";
include ("rand_id.php");
   //Rename
$str = $_FILES['uploadedfile']['name'];
$i = explode(".", $str);
$ext = $i[1];
$extension = strtolower($ext);
$image_name=time().'.'.$extension;
$newname="events/".$image_name;
if($ext == "")
{
$target_path = "";
}
else
{
$target_path = $target_path . basename($newname);
}

if($_POST['submit'] == "Save" && $title != "")
{
move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path);

$sql = mysqli_query($_Conn, "insert into $events (title, date, t_desc, uploads, rand_id) values ('$title', '$date' , '$t_desc' , '$target_path', '$rand_id')");
$empty="";
mysqli_query($_Conn, "DELETE FROM $events where title='$empty'");

echo "<script type='text/javascript'> alert('File has been updated'); </script>";
}
if($_POST['submit'] == "Save" && $title == "")
{
echo "<span id='update'>Error</span>";
}
ob_end_flush();
?> 
<table border=0 cellpadding=10 cellspacing=20 id="circular">
  <tr>
    <td colspan=2 align=center><h1>News Images</h1></td>
  </tr>
  <tr>
    <td>
	<form action="index.php?id=eventsimages" method="POST" enctype="multipart/form-data">
      </td>
  </tr>
  <tr>
    <td >Title</td>
    <td><input type="text" name="title" size="45"></td>
  </tr>
  <?php include ("date.php"); ?>
  <tr><td>Description</td><td><textarea cols=50 rows=16 name="t_desc" id="textarea1"></textarea></td></tr>
<script language="javascript1.2">
  generate_wysiwyg('textarea1');
</script>

  <tr>
    <td>File Upload</td>
    <td><input type="file" name="uploadedfile" size=40></td>
  </tr>
  <input type="hidden" name="MAX_FILE_SIZE" value="100000" />
  <tr>
    <td></td>
    <td><input type="submit" name="submit" value="Save" id="submit"> &nbsp;&nbsp;&nbsp; 
      <input type="submit" name="submit" value="Clear" id="submit"> </td>
  </tr>
  <tr>
  </form>
    <td></td>
  </tr>
</table>
<?php
}
else
{
header("Location:index.php");
}
?>