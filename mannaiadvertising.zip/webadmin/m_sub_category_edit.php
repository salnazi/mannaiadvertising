<?php
error_reporting(0);
session_start();
if($_SESSION['user'])
{

?>
<br><br>
<?php
error_reporting(0);
ob_start();
session_start();
if($_POST['cancel'] == "Cancel")
header("Location:m_index.php?id=sub_category"); 

include('config/host.php');

$r_rand = $_POST['rand'];
$category = $_POST['main_category'];
$sub_category = $_POST['sub_category'];
$old_subcat = $_SESSION['old_subcat'];
$date = $_POST['date'];

//include ("rand_id.php");
if($_POST['update'] == "Update")
{
$sql = mysqli_query($_Conn, "UPDATE $sal_sub_cat SET category = '$category' ,sub_category = '$sub_category' , date = '$date'  WHERE rand_id = '$r_rand'");
$sql1 = mysqli_query($_Conn, "UPDATE $sal_sub_cat SET category = '$category' ,sub_category = '$sub_category'  WHERE sub_category = '$old_subcat'");
$sql2 = mysqli_query($_Conn, "UPDATE $sal_add_com SET category = '$category' ,sub_category = '$sub_category'  WHERE sub_category = '$old_subcat'");
echo "<script type='text/javascript'> alert('File has been updated'); window.location='m_index.php?id=sub_category' ; </script>";
}
if($_POST['update'] == "Update" && $category == "")
{
echo "<span id='update'>Error</span>";
}
ob_end_flush();
?>
<?php
}
else
{
header("Location:index.php");
}
?>