<?php
// Fill up array with names
include("config/host.php"); 
$sql = mysqli_query($_Conn, "select * from $sal_add_com where id");
while($r = mysqli_fetch_object($sql))
{
$a[] = $r->title;
}

//get the 'query' variable from the URL
$q = strtolower($_GET["q"]);

//lookup all hints from array if length of q > 0
if (strlen($q) > 0)
{
  $hint="";
  for($i=0; $i<count($a); $i++)
  {
    if (strtolower($q)==strtolower(substr($a[$i],0,strlen($q))))
    {
      if ($hint=="")
      {
        $hint = $a[$i];
      }
      else
      {
        $hint = $hint." <br> ".$a[$i];
      }
    }
  }
}

// if there are no suggestions, set response to 'n/a'
// otherwise, output all suggestions
if ($hint == "")
{
  $response = "n/a";
}
else
{
  $response = $hint;
}

//output the response
print $response;
?>
