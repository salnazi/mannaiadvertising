<?php
//Random Id Generator
$time = time();
$rand = rand(100,1234567890);
$rand_id = $time . $rand ;
?>
