<table border=0 cellpadding=0 cellspacing=0 style='width:790px;background:none;height:20px;padding:20px;margin-left:150px;margin-top:-100px;_margin-top:-60px;'>

<?php
include("config/host.php");
$category = mysql_num_rows(mysqli_query($_Conn, "select * from $sal_main_cat"));
$sub_category = mysql_num_rows(mysqli_query($_Conn, "select * from $sal_sub_cat"));
$companies = mysql_num_rows(mysqli_query($_Conn, "select * from $sal_add_com"));

?>
<tr><td>Main Category (<?php echo  $category; ?>)</td>
<td>Sub Category (<?php echo  $sub_category; ?>)</td>
<td>Companies (<?php echo  $companies; ?>)</td>
</tr> 
</table>