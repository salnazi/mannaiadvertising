
{source}
<head>
<style type='text/css'>
#al
{
float:left;
padding-left:5px;
width:150px;
height:180px;
margin-left:15px;
text-align:Center;
}
kk
{
text-transform:capitalize;
}

</style>
</head>
<body>
<?php
error_reporting(0);
ob_start();

if($_POST['rand_id'])

{

$r_rand_id = $_POST['rand_id'];
$n_title = $_POST['get_title'];
include ("webadmin/config/host.php");

$sql = mysqli_query($_Conn, "select * from $album where rand_id = '$r_rand_id' ");
echo "<div style='background:#61380B;display:block;padding:10px;margin-left:20px;margin-top:-30px;color:white;font-weight:bold;'>$n_title</div>";
echo "<br>";
while ($r = mysqli_fetch_array($sql))
{
$r_title = $r['title'];
$sqlnew = mysqli_query($_Conn, "select * from $album where sub_title = '$r_title' ");
while ($r = mysqli_fetch_array($sqlnew))

{
$r_rand_id = $r['rand_id'];
$r_date = $r['date'];
$r_uploads = $r['uploads'];
$r_t_desc = $r['t_desc'];

echo "<div id='al'><a href='webadmin/$r_uploads'><img src='webadmin/$r_uploads' height=150 width=150 /><br>$r_t_desc</a><br><br></div>";


}
}

}
ob_end_flush();
?>
</body>
{/source}


